"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraSasaran extends Model {
    static associate(models) {
      RenstraSasaran.belongsTo(models.RenstraOPD, {
        foreignKey: "renstra_id",
        as: "renstra_opd",
      });

      RenstraSasaran.belongsTo(models.Sasaran, {
        foreignKey: "rpjmd_sasaran_id",
        as: "sasaran_rpjmd",
      });

      RenstraSasaran.belongsTo(models.RenstraTujuan, {
        foreignKey: "tujuan_opd_id",
        as: "tujuan_opd",
      });

      RenstraSasaran.hasMany(models.RenstraSasaran, {
        foreignKey: "sasaran_opd_id", // sesuaikan jika nama FK juga akan diganti
        as: "sasaran_opd",
      });

      RenstraSasaran.belongsTo(models.RenstraStrategi, {
        foreignKey: "strategi_opd_id",
        as: "strategi_opd",
      });

      RenstraSasaran.belongsTo(models.RenstraKebijakan, {
        foreignKey: "kebijakan_opd_id",
        as: "kebijakan_opd",
      });

      RenstraSasaran.belongsTo(models.RenstraProgram, {
        foreignKey: "program_opd_id",
        as: "program_opd",
      });

      RenstraSasaran.belongsTo(models.RenstraKegiatan, {
        foreignKey: "kegiatan_opd_id",
        as: "kegiatan_opd",
      });

      RenstraSasaran.belongsTo(models.RenstraSubkegiatan, {
        foreignKey: "subkegiatan_opd_id",
        as: "subkegiatan_opd",
      });
    }
  }

  RenstraSasaran.init(
    {
      renstra_id: DataTypes.INTEGER,
      rpjmd_sasaran_id: DataTypes.UUID,
      misi_id: DataTypes.INTEGER,
      no_sasaran: DataTypes.STRING,
      isi_sasaran: DataTypes.TEXT,
      no_rpjmd: DataTypes.STRING,
      isi_sasaran_rpjmd: DataTypes.TEXT,
    },
    {
      sequelize,
      modelName: "RenstraSasaran",
      tableName: "renstra_sasaran",
      underscored: true,
      timestamps: false,
    }
  );

  return RenstraSasaran;
};
