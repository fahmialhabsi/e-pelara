"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraOPD extends Model {
    static associate(models) {
      RenstraOPD.hasMany(models.RenstraTujuan, {
        foreignKey: "renstra_id",
        as: "renstra_tujuan",
      });

      // Tambahan relasi ke RenstraSasaran
      RenstraOPD.hasMany(models.RenstraSasaran, {
        foreignKey: "renstra_id",
        as: "renstra_sasaran",
      });
    }
  }

  RenstraOPD.init(
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      opd_id: DataTypes.INTEGER,
      rpjmd_id: DataTypes.INTEGER,
      bidang_opd: DataTypes.STRING,
      sub_bidang_opd: DataTypes.STRING,
      tahun_mulai: DataTypes.INTEGER,
      tahun_akhir: DataTypes.INTEGER,
      keterangan: DataTypes.TEXT,
      is_aktif: DataTypes.BOOLEAN,
    },
    {
      sequelize,
      modelName: "RenstraOPD",
      tableName: "renstra_opd",
      underscored: true,
      timestamps: true,
    }
  );

  return RenstraOPD;
};
