"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraSubkegiatan extends Model {
    static associate(models) {
      RenstraSubkegiatan.belongsTo(models.RenstraOPD, {
        foreignKey: "renstra_id",
        as: "renstra_opd",
      });
      RenstraSubkegiatan.hasMany(models.RenstraSasaran, {
        foreignKey: "subkegiatan_opd_id", // sesuaikan jika nama FK juga akan diganti
        as: "sasaran_opd",
      });
      RenstraSubkegiatan.belongsTo(models.SubKegiatan, {
        foreignKey: "rpjmd_subkegiatan_id",
        as: "subkegiatan_rpjmd",
      });
    }
  }

  RenstraSubkegiatan.init(
    {
      renstra_id: DataTypes.INTEGER,
      rpjmd_subkegiatan_id: DataTypes.UUID,
      misi_id: DataTypes.INTEGER,
      no_subkegiatan: DataTypes.STRING,
      isi_subkegiatan: DataTypes.TEXT,
      no_rpjmd: DataTypes.STRING,
      isi_subkegiatan_rpjmd: DataTypes.TEXT,
    },
    {
      sequelize,
      modelName: "RenstraSubkegiatan",
      tableName: "renstra_subkegiatan",
      underscored: true,
      timestamps: false,
    }
  );

  return RenstraSubkegiatan;
};
