// models/IndikatorTujuan.js
"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class IndikatorTujuan extends Model {
    static associate(models) {
      // Relasi ke IndikatorMisi
      this.belongsTo(models.IndikatorMisi, {
        foreignKey: "misi_id",
        as: "indikatorMisi",
      });
      // Relasi ke IndikatorSasaran
      this.hasMany(models.IndikatorSasaran, {
        foreignKey: "tujuan_id",
        as: "sasarans",
      });
    }
  }

  IndikatorTujuan.init(
    {
      id: {
        type: DataTypes.INTEGER.UNSIGNED,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
      },
      misi_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
      },
      tujuan_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
      },
      kode_indikator: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      nama_indikator: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      tipe_indikator: {
        type: DataTypes.ENUM("Impact"),
        allowNull: false,
      },
      jenis: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      tolok_ukur_kinerja: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      target_kinerja: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      jenis_indikator: {
        type: DataTypes.ENUM("Kuantitatif", "Kualitatif"),
        allowNull: false,
      },
      kriteria_kuantitatif: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      kriteria_kualitatif: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      satuan: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      definisi_operasional: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      metode_penghitungan: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      baseline: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      target_tahun_1: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      target_tahun_2: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      target_tahun_3: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      target_tahun_4: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      target_tahun_5: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      sumber_data: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      penanggung_jawab: {
        type: DataTypes.STRING(255),
        allowNull: true,
      },
      keterangan: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      jenisDokumen: {
        type: DataTypes.STRING,
        allowNull: false,
        field: "jenis_dokumen",
      },
      tahun: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    },
    {
      sequelize,
      modelName: "IndikatorTujuan",
      tableName: "indikatortujuans",
      underscored: true,
      timestamps: false,
    }
  );

  return IndikatorTujuan;
};
