"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class SubKegiatan extends Model {
    static associate(models) {
      SubKegiatan.belongsTo(models.Kegiatan, {
        foreignKey: "kegiatan_id",
        as: "kegiatan",
      });

      SubKegiatan.belongsTo(models.PeriodeRpjmd, {
        foreignKey: "periode_id",
        as: "periode",
      });
    }
  }

  SubKegiatan.init(
    {
      kegiatan_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      periode_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "periode_rpjmds",
          key: "id",
        },
      },
      nama_sub_kegiatan: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: { notEmpty: { msg: "Nama Sub Kegiatan tidak boleh kosong" } },
      },
      kode_sub_kegiatan: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: { msg: "Kode Sub Kegiatan harus unik" },
        validate: { notEmpty: { msg: "Kode Sub Kegiatan tidak boleh kosong" } },
      },
      anggaran_sub_kegiatan: {
        type: DataTypes.DECIMAL,
        allowNull: false,
        validate: { min: 0, isDecimal: true },
      },
      anggaran_kegiatan: {
        type: DataTypes.DECIMAL,
        allowNull: false,
        defaultValue: 0,
      },
      pagu_anggaran: {
        type: DataTypes.DECIMAL,
        allowNull: false,
        validate: { min: 0, isDecimal: true },
      },
      waktu_pelaksanaan: {
        type: DataTypes.DATE,
        allowNull: false,
        validate: { isDate: true },
      },
      nama_opd: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: { notEmpty: { msg: "Nama OPD tidak boleh kosong" } },
      },
      nama_bidang_opd: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: { notEmpty: { msg: "Nama Bidang OPD tidak boleh kosong" } },
      },
      sumber_daya_pendukung: {
        type: DataTypes.TEXT,
        allowNull: false,
        validate: {
          notEmpty: { msg: "Sumber Daya Pendukung tidak boleh kosong" },
          len: { args: [5, 1000], msg: "Minimal 5 karakter" },
        },
      },
      rencana_lokasi_desa: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notEmpty: { msg: "Nama Desa tidak boleh kosong" },
          len: { args: [3, 100], msg: "Nama Desa 3-100 karakter" },
        },
      },
      rencana_lokasi_kecamatan: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notEmpty: { msg: "Nama Kecamatan tidak boleh kosong" },
          len: { args: [3, 100], msg: "Nama Kecamatan 3-100 karakter" },
        },
      },
      rencana_lokasi_kabupaten: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          notEmpty: { msg: "Nama Kabupaten tidak boleh kosong" },
          len: { args: [3, 100], msg: "Nama Kabupaten 3-100 karakter" },
        },
      },
      deskripsi: {
        type: DataTypes.TEXT,
        allowNull: false,
        validate: {
          notEmpty: { msg: "Deskripsi tidak boleh kosong" },
          len: { args: [10, 1000], msg: "10-1000 karakter" },
        },
      },
      kerangka_pelaksanaan: {
        type: DataTypes.TEXT,
        allowNull: false,
        validate: {
          notEmpty: { msg: "Kerangka Pelaksanaan tidak boleh kosong" },
          len: { args: [10, 1000], msg: "10-1000 karakter" },
        },
      },
      output: {
        type: DataTypes.TEXT,
        allowNull: false,
        validate: {
          notEmpty: { msg: "Output tidak boleh kosong" },
          len: { args: [5, 1000], msg: "5-1000 karakter" },
        },
      },
      pihak_terlibat: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: { notEmpty: { msg: "Pihak Terlibat tidak boleh kosong" } },
      },
      rpjmd_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      target_awal: {
        type: DataTypes.DECIMAL(20, 2),
        allowNull: true,
      },
      target_akhir: {
        type: DataTypes.DECIMAL(20, 2),
        allowNull: true,
      },
      satuan: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      status_monitoring: {
        type: DataTypes.ENUM("on-track", "delay", "complete"),
        allowNull: false,
        defaultValue: "on-track",
      },
      tanggal_laporan: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      catatan: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
    },
    {
      sequelize,
      modelName: "SubKegiatan",
      tableName: "sub_kegiatan",
      underscored: true,
    }
  );

  return SubKegiatan;
};
