// models/arahKebijakan.js
"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class ArahKebijakan extends Model {
    static associate(models) {
      // 1:Many ke Strategi
      ArahKebijakan.belongsTo(models.Strategi, {
        foreignKey: "strategi_id",
        as: "Strategi",
      });

      ArahKebijakan.belongsTo(models.PeriodeRpjmd, {
        foreignKey: "periode_id",
        as: "periode",
      });

      // Many:Many ke Program — harus sama `through` dengan ProgramModel
      ArahKebijakan.belongsToMany(models.Program, {
        through: "program_arah_kebijakan", // <<< harus sama
        foreignKey: "arah_kebijakan_id",
        otherKey: "program_id",
        as: "Programs",
      });
    }
  }
  ArahKebijakan.init(
    {
      strategi_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      periode_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "periode_rpjmds",
          key: "id",
        },
      },
      kode_arah: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      deskripsi: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      prioritas: {
        type: DataTypes.ENUM("Tinggi", "Sedang", "Rendah"),
        allowNull: true,
      },
      jenisDokumen: {
        type: DataTypes.STRING,
        allowNull: false,
        field: "jenisDokumen",
      },
      tahun: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    },
    {
      sequelize,
      modelName: "ArahKebijakan",
      tableName: "arah_kebijakan",
      underscored: true,
      timestamps: true,
    }
  );
  return ArahKebijakan;
};
