"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraStrategi extends Model {
    static associate(models) {
      RenstraStrategi.belongsTo(models.RenstraOPD, {
        foreignKey: "renstra_id",
        as: "renstra_opd",
      });
      RenstraStrategi.hasMany(models.RenstraSasaran, {
        foreignKey: "strategi_opd_id", // sesuaikan jika nama FK juga akan diganti
        as: "sasaran_opd",
      });
      RenstraStrategi.belongsTo(models.Strategi, {
        foreignKey: "rpjmd_strategi_id",
        as: "strategi_rpjmd",
      });
    }
  }

  RenstraStrategi.init(
    {
      renstra_id: DataTypes.INTEGER,
      rpjmd_strategi_id: DataTypes.UUID,
      misi_id: DataTypes.INTEGER,
      no_strategi: DataTypes.STRING,
      isi_strategi: DataTypes.TEXT,
      no_rpjmd: DataTypes.STRING,
      isi_strategi_rpjmd: DataTypes.TEXT,
    },
    {
      sequelize,
      modelName: "RenstraStrategi",
      tableName: "renstra_strategi",
      underscored: true,
      timestamps: false,
    }
  );

  return RenstraStrategi;
};
