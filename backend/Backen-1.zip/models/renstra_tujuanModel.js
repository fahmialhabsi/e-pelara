"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraTujuan extends Model {
    static associate(models) {
      RenstraTujuan.belongsTo(models.RenstraOPD, {
        foreignKey: "renstra_id",
        as: "renstra_opd",
      });
      RenstraTujuan.hasMany(models.RenstraSasaran, {
        foreignKey: "tujuan_opd_id", // sesuaikan jika nama FK juga akan diganti
        as: "sasaran_opd",
      });
      RenstraTujuan.belongsTo(models.Tujuan, {
        foreignKey: "rpjmd_tujuan_id",
        as: "tujuan_rpjmd",
      });
    }
  }

  RenstraTujuan.init(
    {
      renstra_id: DataTypes.INTEGER,
      rpjmd_tujuan_id: DataTypes.UUID,
      misi_id: DataTypes.INTEGER,
      no_tujuan: DataTypes.STRING,
      isi_tujuan: DataTypes.TEXT,
      no_rpjmd: DataTypes.STRING,
      isi_tujuan_rpjmd: DataTypes.TEXT,
    },
    {
      sequelize,
      modelName: "RenstraTujuan",
      tableName: "renstra_tujuan",
      underscored: true,
      timestamps: false,
    }
  );

  return RenstraTujuan;
};
