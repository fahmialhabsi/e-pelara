"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class PrioritasGubernur extends Model {
  }

  PrioritasGubernur.init(
    {
      kode_priogub: {
        type: DataTypes.STRING,
        allowNull: false,
        field: "kode_priogub",
      },
      nama_priogub: {
        type: DataTypes.STRING,
        allowNull: false,
        field: "nama_priogub",
      },
      uraian_priogub: {
        type: DataTypes.TEXT,
        allowNull: false,
        field: "uraian_priogub",
      },
      opd_tujuan: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: "opd_tujuan",
      },
      standar_layanan_opd: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: "standar_layanan_opd",
      },
    },
    {
      sequelize,
      modelName: "PrioritasGubernur",
      
      tableName: "prioritas_kepala_daerah",
      timestamps: false,
    
    }
  );

  return PrioritasGubernur;
};
