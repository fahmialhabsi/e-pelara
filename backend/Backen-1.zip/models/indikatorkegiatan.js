// models/IndikatorKegiatan.js
"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class IndikatorKegiatan extends Model {
    static associate(models) {
      // Relasi ke IndikatorProgram
      this.belongsTo(models.IndikatorProgram, {
        foreignKey: "program_id",
        as: "program",
      });
      // Relasi ke prioritas (jika digunakan)
      this.belongsTo(models.PrioritasNasional, {
        foreignKey: "prioritas_nasional_id",
        as: "prioritasNasional",
      });
      this.belongsTo(models.PrioritasDaerah, {
        foreignKey: "prioritas_daerah_id",
        as: "prioritasDaerah",
      });
      this.belongsTo(models.PrioritasGubernur, {
        foreignKey: "prioritas_gubernur_id",
        as: "prioritasGubernur",
      });
    }
  }

  IndikatorKegiatan.init(
    {
      id: {
        type: DataTypes.INTEGER.UNSIGNED,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
      },
      kode_indikator: {
        type: DataTypes.STRING(100),
        allowNull: false,
      },
      nama_indikator: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      tipe_indikator: {
        type: DataTypes.ENUM("Proses"),
        allowNull: false,
      },
      jenis: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      tolok_ukur_kinerja: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      target_kinerja: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      jenis_indikator: {
        type: DataTypes.ENUM("Kuantitatif", "Kualitatif"),
        allowNull: false,
      },
      kriteria_kuantitatif: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      kriteria_kualitatif: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      satuan: {
        type: DataTypes.STRING(50),
        allowNull: true,
      },
      definisi_operasional: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      metode_penghitungan: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      baseline: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      target_tahun_1: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      target_tahun_2: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      target_tahun_3: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      target_tahun_4: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      target_tahun_5: {
        type: DataTypes.STRING(100),
        allowNull: true,
      },
      sumber_data: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      penanggung_jawab: {
        type: DataTypes.STRING(255),
        allowNull: true,
      },
      keterangan: {
        type: DataTypes.TEXT,
        allowNull: true,
      },
      jenisDokumen: {
        type: DataTypes.STRING,
        allowNull: false,
        field: "jenis_dokumen",
      },
      tahun: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    },
    {
      sequelize,
      modelName: "IndikatorKegiatan",
      tableName: "indikatorkegiatans",
      underscored: true,
      timestamps: false,
      createdAt: "created_at",
      updatedAt: "updated_at",
    }
  );

  return IndikatorKegiatan;
};
