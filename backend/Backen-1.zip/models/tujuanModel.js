"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class Tujuan extends Model {
    static associate(models) {
      Tujuan.belongsTo(models.RPJMD, {
        foreignKey: "rpjmd_id",
        as: "Rpjmd",
      });

      Tujuan.belongsTo(models.Misi, {
        foreignKey: "misi_id",
        as: "Misi",
      });

      Tujuan.belongsTo(models.PeriodeRpjmd, {
        foreignKey: "periode_id",
        as: "periode",
      });

      Tujuan.hasMany(models.Sasaran, {
        foreignKey: "tujuan_id",
        as: "Sasarans",
      });
    }
  }

  Tujuan.init(
    {
      rpjmd_id: {
        type: DataTypes.UUID,
        allowNull: true,
      },
      misi_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      periode_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "periode_rpjmds",
          key: "id",
        },
      },
      no_tujuan: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      isi_tujuan: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      indikator: {
        type: DataTypes.STRING,
        allowNull: true,
      },
    },
    {
      sequelize,
      modelName: "Tujuan",
      tableName: "tujuan",
      underscored: true,
      timestamps: false,
    }
  );

  return Tujuan;
};
