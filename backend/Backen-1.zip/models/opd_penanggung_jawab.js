"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class OpdPenanggungJawab extends Model {
    static associate(models) {
      // Contoh relasi (jika diperlukan)
      // this.belongsTo(models.User, { foreignKey: 'user_id' });
    }
  }

  OpdPenanggungJawab.init(
    {
      nama_opd: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      nama_bidang_opd: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      // Field baru:
      nama: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      nip: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      jabatan: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    },
    {
      sequelize,
      modelName: "OpdPenanggungJawab",
      tableName: "opd_penanggung_jawab",
      underscored: true, // konsisten dengan snake_case kolom
      timestamps: true, // atau true jika Anda pakai createdAt/updatedAt
    }
  );

  return OpdPenanggungJawab;
};
