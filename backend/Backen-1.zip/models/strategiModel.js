// models/strategi.js
"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Strategi extends Model {
    static associate(models) {
      Strategi.belongsTo(models.Sasaran, {
        foreignKey: "sasaran_id",
        as: "Sasaran",
      });

      Strategi.hasMany(models.ArahKebijakan, {
        foreignKey: "strategi_id",
        as: "ArahKebijakan",
      });

      Strategi.belongsTo(models.PeriodeRpjmd, {
        foreignKey: "periode_id",
        as: "periode",
      });

      Strategi.belongsToMany(models.Program, {
        through: "program_strategi",
        foreignKey: "strategi_id",
        otherKey: "program_id",
        as: "Program",
      });
    }
  }
  Strategi.init(
    {
      sasaran_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      periode_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "periode_rpjmds",
          key: "id",
        },
      },
      kode_strategi: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      deskripsi: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
      jenisDokumen: {
        type: DataTypes.STRING,
        allowNull: false,
        field: "jenisDokumen",
      },
      tahun: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    },
    {
      sequelize,
      modelName: "Strategi",
      tableName: "strategi",
      underscored: true,
      timestamps: true,
    }
  );
  return Strategi;
};
