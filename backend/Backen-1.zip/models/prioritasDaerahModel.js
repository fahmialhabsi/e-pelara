"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class PrioritasDaerah extends Model {
  }

  PrioritasDaerah.init(
    {
      kode_prioda: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      uraian_prioda: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      nama_prioda: {
        // ← field baru
        type: DataTypes.STRING,
        allowNull: true, // sesuaikan requirement
      },
      opd_tujuan: {
        type: DataTypes.STRING,
        allowNull: true,
      },
    },
    {
      sequelize,
      modelName: "PrioritasDaerah",
      
      tableName: "prioritas_daerah",
      timestamps: false,
    
    }
  );

  return PrioritasDaerah;
};
