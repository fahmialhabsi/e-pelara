"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraIndikator extends Model {
    static associate(models) {
      RenstraIndikator.belongsTo(models.RenstraOPD, {
        foreignKey: "renstra_id",
        as: "renstra_opd",
      });
      RenstraIndikator.hasMany(models.RenstraSasaran, {
        foreignKey: "indikator_opd_id", // sesuaikan jika nama FK juga akan diganti
        as: "sasaran_opd",
      });
      RenstraIndikator.belongsTo(models.Indikator, {
        foreignKey: "rpjmd_indikator_id",
        as: "indikator_rpjmd",
      });
    }
  }

  RenstraIndikator.init(
    {
      renstra_id: DataTypes.INTEGER,
      rpjmd_indikator_id: DataTypes.UUID,
      misi_id: DataTypes.INTEGER,
      no_indikator: DataTypes.STRING,
      isi_indikator: DataTypes.TEXT,
      no_rpjmd: DataTypes.STRING,
      isi_indikator_rpjmd: DataTypes.TEXT,
    },
    {
      sequelize,
      modelName: "RenstraIndikator",
      tableName: "renstra_indikator",
      underscored: true,
      timestamps: false,
    }
  );

  return RenstraIndikator;
};
