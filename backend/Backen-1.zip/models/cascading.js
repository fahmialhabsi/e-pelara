"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Cascading extends Model {
    static associate(models) {
      Cascading.belongsTo(models.Misi, {
        foreignKey: "misi_id",
        as: "misi",
      });
      Cascading.belongsTo(models.PrioritasNasional, {
        foreignKey: "prior_nas_id",
        as: "priorNasional",
      });
      Cascading.belongsTo(models.PrioritasDaerah, {
        foreignKey: "prior_daerah_id",
        as: "priorDaerah",
      });
      // Correct model name: PrioritasGubernur
      Cascading.belongsTo(models.PrioritasGubernur, {
        foreignKey: "prior_kepda_id",
        as: "priorKepda",
      });
      Cascading.belongsTo(models.Tujuan, {
        foreignKey: "tujuan_id",
        as: "tujuan",
      });
      Cascading.belongsTo(models.Sasaran, {
        foreignKey: "sasaran_id",
        as: "sasaran",
      });
      Cascading.belongsTo(models.Program, {
        foreignKey: "program_id",
        as: "program",
      });
      Cascading.belongsTo(models.Kegiatan, {
        foreignKey: "kegiatan_id",
        as: "kegiatan",
      });
      Cascading.belongsTo(models.Strategi, {
        foreignKey: "strategi_id",
        as: "strategi",
      });
      Cascading.belongsTo(models.ArahKebijakan, {
        foreignKey: "arah_kebijakan_id",
        as: "arahKebijakan",
      });
    }
  }
  Cascading.init(
    {
      misi_id: DataTypes.INTEGER,
      prior_nas_id: DataTypes.BIGINT.UNSIGNED,
      prior_daerah_id: DataTypes.BIGINT.UNSIGNED,
      prior_kepda_id: DataTypes.BIGINT.UNSIGNED,
      tujuan_id: DataTypes.INTEGER,
      sasaran_id: DataTypes.INTEGER,
      program_id: DataTypes.INTEGER,
      kegiatan_id: DataTypes.INTEGER,
      strategi_id: DataTypes.INTEGER,
      arah_kebijakan_id: DataTypes.INTEGER,
      jenisDokumen: DataTypes.STRING,
      tahun: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "Cascading",
      tableName: "cascading",
      freezeTableName: true,
      timestamps: true,
    }
  );
  return Cascading;
};
