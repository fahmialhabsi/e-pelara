"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraKegiatan extends Model {
    static associate(models) {
      RenstraKegiatan.belongsTo(models.RenstraOPD, {
        foreignKey: "renstra_id",
        as: "renstra_opd",
      });
      RenstraKegiatan.hasMany(models.RenstraSasaran, {
        foreignKey: "kegiatan_opd_id", // sesuaikan jika nama FK juga akan diganti
        as: "sasaran_opd",
      });
      RenstraKegiatan.belongsTo(models.Kegiatan, {
        foreignKey: "rpjmd_kegiatan_id",
        as: "kegiatan_rpjmd",
      });
    }
  }

  RenstraKegiatan.init(
    {
      renstra_id: DataTypes.INTEGER,
      rpjmd_kegiatan_id: DataTypes.UUID,
      misi_id: DataTypes.INTEGER,
      no_kegiatan: DataTypes.STRING,
      isi_kegiatan: DataTypes.TEXT,
      no_rpjmd: DataTypes.STRING,
      isi_kegiatan_rpjmd: DataTypes.TEXT,
    },
    {
      sequelize,
      modelName: "RenstraKegiatan",
      tableName: "renstra_kegiatan",
      underscored: true,
      timestamps: false,
    }
  );

  return RenstraKegiatan;
};
