"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class Sasaran extends Model {
    static associate(models) {
      // Relasi ke Tujuan
      Sasaran.belongsTo(models.Tujuan, {
        foreignKey: "tujuan_id",
        as: "Tujuan",
      });

      Sasaran.belongsTo(models.PeriodeRpjmd, {
        foreignKey: "periode_id",
        as: "periode",
      });

      Sasaran.hasMany(models.Program, {
        foreignKey: "sasaran_id",
        as: "Program",
      });

      Sasaran.hasMany(models.Indikator, {
        foreignKey: "sasaran_id",
        as: "Indikator", // alias yang akan kamu pakai di controller
      });
    }
  }

  Sasaran.init(
    {
      rpjmd_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      periode_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "periode_rpjmds",
          key: "id",
        },
      },
      tujuan_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      nomor: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      isi_sasaran: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
    },
    {
      sequelize,
      modelName: "Sasaran",
      tableName: "sasaran",
      underscored: true,
      timestamps: true,
    }
  );

  return Sasaran;
};
