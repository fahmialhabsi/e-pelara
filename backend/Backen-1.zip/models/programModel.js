"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class Program extends Model {
    static associate(models) {
      // Relasi ke Sasaran (Many-to-One)
      Program.belongsTo(models.Sasaran, {
        foreignKey: "sasaran_id",
        as: "sasaran",
      });

      Program.belongsTo(models.PeriodeRpjmd, {
        foreignKey: "periode_id",
        as: "periode",
      });

      // Relasi ke Kegiatan (One-to-Many)
      Program.hasMany(models.Kegiatan, {
        foreignKey: "program_id",
        as: "Kegiatan",
      });

      // Relasi ke OPD Penanggung Jawab (Many-to-One)
      Program.belongsTo(models.OpdPenanggungJawab, {
        foreignKey: "opd_penanggung_jawab",
        as: "penanggungJawabOpd",
      });

      // Relasi ke Strategi
      Program.belongsToMany(models.Strategi, {
        through: models.program_strategi,
        foreignKey: "program_id",
        otherKey: "strategi_id",
        as: "Strategi",
      });

      // Relasi Many-to-Many ke ArahKebijakan
      Program.belongsToMany(models.ArahKebijakan, {
        through: models.program_arah_kebijakan,
        foreignKey: "program_id",
        otherKey: "arah_kebijakan_id",
        as: "ArahKebijakan",
      });
    }
  }
  Program.init(
    {
      sasaran_id: DataTypes.INTEGER,
      periode_id: DataTypes.INTEGER,
      nama_program: DataTypes.STRING,
      kode_program: DataTypes.STRING,
      rpjmd_id: DataTypes.INTEGER,
      prioritas: DataTypes.STRING,
      opd_penanggung_jawab: DataTypes.STRING,
      bidang_opd_penanggung_jawab: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "Program",
      tableName: "program",
      underscored: true,
    }
  );
  return Program;
};
