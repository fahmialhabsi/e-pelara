"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraProgram extends Model {
    static associate(models) {
      RenstraProgram.belongsTo(models.RenstraOPD, {
        foreignKey: "renstra_id",
        as: "renstra_opd",
      });
      RenstraProgram.hasMany(models.RenstraSasaran, {
        foreignKey: "program_opd_id", // sesuaikan jika nama FK juga akan diganti
        as: "sasaran_opd",
      });
      RenstraProgram.belongsTo(models.Program, {
        foreignKey: "rpjmd_program_id",
        as: "program_rpjmd",
      });
    }
  }

  RenstraProgram.init(
    {
      renstra_id: DataTypes.INTEGER,
      rpjmd_program_id: DataTypes.UUID,
      misi_id: DataTypes.INTEGER,
      no_program: DataTypes.STRING,
      isi_program: DataTypes.TEXT,
      no_rpjmd: DataTypes.STRING,
      isi_program_rpjmd: DataTypes.TEXT,
    },
    {
      sequelize,
      modelName: "RenstraProgram",
      tableName: "renstra_program",
      underscored: true,
      timestamps: false,
    }
  );

  return RenstraProgram;
};
