// models/kegiatanModel.js
"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Kegiatan extends Model {
    static associate(models) {
      Kegiatan.belongsTo(models.Program, {
        foreignKey: "program_id",
        as: "program", // lowercase alias
      });

      Kegiatan.belongsTo(models.RPJMD, {
        foreignKey: "rpjmd_id",
        as: "rpjmd", // lowercase alias
      });

      Kegiatan.belongsTo(models.PeriodeRpjmd, {
        foreignKey: "periode_id",
        as: "periode",
      });

      Kegiatan.hasMany(models.SubKegiatan, {
        foreignKey: "kegiatan_id",
        as: "sub_kegiatan",
      });
    }
  }
  Kegiatan.init(
    {
      program_id: DataTypes.INTEGER,
      rpjmd_id: DataTypes.INTEGER,
      periode_id: DataTypes.INTEGER,
      nama_kegiatan: DataTypes.STRING,
      kode_kegiatan: DataTypes.STRING,
      jenisDokumen: {
        type: DataTypes.STRING,
        field: "jenisDokumen", // tambahkan ini
      },
      tahun: DataTypes.STRING,
      anggaran: {
        type: DataTypes.DECIMAL,
        allowNull: false,
        validate: { min: 0 },
      },
    },
    {
      sequelize,
      modelName: "Kegiatan",
      tableName: "kegiatan",
      underscored: true,
    }
  );

  return Kegiatan;
};
