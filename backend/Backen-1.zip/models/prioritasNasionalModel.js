"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class PrioritasNasional extends Model {
  }

  PrioritasNasional.init(
    {
      kode_prionas: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      nama_prionas: {
        // ← field baru
        type: DataTypes.STRING,
        allowNull: true, // sesuaikan requirement
      },
      uraian_prionas: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      sumber: {
        type: DataTypes.STRING,
        allowNull: true,
      },
    },
    {
      sequelize,
      modelName: "PrioritasNasional",
      
      tableName: "prioritas_nasional",
      timestamps: false,
    
    }
  );

  return PrioritasNasional;
};
