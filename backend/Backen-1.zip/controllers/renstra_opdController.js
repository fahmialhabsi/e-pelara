const { RenstraOPD } = require("../models");

exports.create = async (req, res) => {
  try {
    const renstra = await RenstraOPD.create(req.body);
    res.status(201).json(renstra);
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal membuat data" });
  }
};

exports.setAktif = async (req, res) => {
  const id = req.params.id;

  try {
    // Nonaktifkan semua renstra_opd
    await RenstraOPD.update({ is_aktif: false }, { where: {} });

    // Aktifkan satu berdasarkan id
    const [updated] = await RenstraOPD.update(
      { is_aktif: true },
      { where: { id } }
    );

    if (!updated) {
      return res.status(404).json({ message: "Renstra tidak ditemukan" });
    }

    res.json({ message: "Renstra berhasil di-set aktif" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.findAll = async (req, res) => {
  try {
    const data = await RenstraOPD.findAll();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.findOne = async (req, res) => {
  try {
    const data = await RenstraOPD.findByPk(req.params.id);
    if (!data) return res.status(404).json({ message: "Data tidak ditemukan" });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.update = async (req, res) => {
  try {
    const [updated] = await RenstraOPD.update(req.body, {
      where: { id: req.params.id },
    });
    if (!updated)
      return res.status(404).json({ message: "Data tidak ditemukan" });
    const data = await RenstraOPD.findByPk(req.params.id);
    res.json(data);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.delete = async (req, res) => {
  try {
    const deleted = await RenstraOPD.destroy({ where: { id: req.params.id } });
    if (!deleted)
      return res.status(404).json({ message: "Data tidak ditemukan" });
    res.json({ message: "Berhasil dihapus" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
