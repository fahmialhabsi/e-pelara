// controllers/prioritasGubernurController.js
const { PrioritasGubernur } = require("../models");
const { Op } = require("sequelize");

// Create
exports.create = async (req, res) => {
  console.log(">>> CREATE BODY:", req.body);
  try {
    const data = await PrioritasGubernur.create(req.body);
    return res.status(201).json({ message: "Data berhasil ditambahkan", data });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Gagal menambahkan data", error: error.message });
  }
};

// Get All (tanpa join)
exports.getAll = async (req, res) => {
  try {
    const { page = 1, limit, search = "" } = req.query;
    const offset = (page - 1) * (limit || 20); // Default 20 jika limit tidak ada
    const where = {
      [Op.or]: [
        { kode_priogub: { [Op.like]: `%${search}%` } },
        { uraian_priogub: { [Op.like]: `%${search}%` } },
        { standar_layanan_opd: { [Op.like]: `%${search}%` } },
      ],
    };

    const options = {
      where,
      order: [["id", "ASC"]],
    };

    // Jika ada parameter limit, lakukan paginasi
    if (limit) {
      options.limit = parseInt(limit, 10);
      options.offset = offset;
    }

    const { rows, count } = await PrioritasGubernur.findAndCountAll(options);

    return res.json({
      data: rows,
      meta: {
        total: count,
        page: +page,
        limit: limit ? +limit : null,
        totalPages: limit ? Math.ceil(count / limit) : 1,
      },
    });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Gagal mengambil data", error: error.message });
  }
};

// Get By ID
exports.getById = async (req, res) => {
  try {
    const data = await PrioritasGubernur.findByPk(req.params.id);
    if (!data) return res.status(404).json({ message: "Data tidak ditemukan" });
    return res.status(200).json({ data });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Gagal mengambil data", error: error.message });
  }
};

// Update
exports.update = async (req, res) => {
  console.log(">>> UPDATE BODY:", req.body);
  try {
    const id = req.params.id;
    const [updated] = await PrioritasGubernur.update(req.body, {
      where: { id },
    });
    if (!updated)
      return res.status(404).json({ message: "Data tidak ditemukan" });
    const data = await PrioritasGubernur.findByPk(id);
    return res.status(200).json({ message: "Data berhasil diperbarui", data });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Gagal memperbarui data", error: error.message });
  }
};

// Delete
exports.remove = async (req, res) => {
  try {
    const deleted = await PrioritasGubernur.destroy({
      where: { id: req.params.id },
    });
    if (!deleted)
      return res.status(404).json({ message: "Data tidak ditemukan" });
    return res.status(200).json({ message: "Data berhasil dihapus" });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Gagal menghapus data", error: error.message });
  }
};
