// controllers/indikatorProgramController.js
const { IndikatorProgram } = require("../models");

const defaultDokumen = {
  jenisDokumen: "RPJMD",
  tahun: "2025",
};

exports.create = async (req, res) => {
  try {
    const rows = Array.isArray(req.body) ? req.body : [req.body];

    const allowedFields = [
      "kode_indikator",
      "nama_indikator",
      "tipe_indikator",
      "jenis",
      "tolok_ukur_kinerja",
      "target_kinerja",
      "jenis_indikator",
      "kriteria_kuantitatif",
      "kriteria_kualitatif",
      "satuan",
      "definisi_operasional",
      "metode_penghitungan",
      "baseline",
      "target_tahun_1",
      "target_tahun_2",
      "target_tahun_3",
      "target_tahun_4",
      "target_tahun_5",
      "sumber_data",
      "penanggung_jawab",
      "keterangan",
      "sasaran_id",
    ];

    const sanitized = rows.map((r) => {
      const obj = Object.fromEntries(
        Object.entries(r).filter(([key]) => allowedFields.includes(key))
      );
      obj.jenisDokumen = r.jenisDokumen || defaultDokumen.jenisDokumen;
      obj.tahun = r.tahun || defaultDokumen.tahun;
      return obj;
    });

    const created = await IndikatorProgram.bulkCreate(sanitized);
    return res.status(201).json(created);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
};

exports.findAll = async (req, res) => {
  try {
    const indikatorProgram = await IndikatorProgram.findAll({
      include: ["kegiatans"],
    });
    return res.status(200).json(indikatorProgram);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
};

exports.findOne = async (req, res) => {
  try {
    const indikatorProgram = await IndikatorProgram.findByPk(req.params.id, {
      include: ["kegiatans"],
    });
    if (!indikatorProgram) {
      return res.status(404).json({ message: "Indikator Program not found" });
    }
    return res.status(200).json(indikatorProgram);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
};

exports.update = async (req, res) => {
  try {
    const indikatorProgram = await IndikatorProgram.findByPk(req.params.id);
    if (!indikatorProgram) {
      return res.status(404).json({ message: "Indikator Program not found" });
    }

    const updateData = {
      ...req.body,
      jenisDokumen: req.body.jenisDokumen || defaultDokumen.jenisDokumen,
      tahun: req.body.tahun || defaultDokumen.tahun,
    };

    await indikatorProgram.update(updateData);
    return res.status(200).json(indikatorProgram);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
};

exports.delete = async (req, res) => {
  try {
    const indikatorProgram = await IndikatorProgram.findByPk(req.params.id);
    if (!indikatorProgram) {
      return res.status(404).json({ message: "Indikator Program not found" });
    }
    await indikatorProgram.destroy();
    return res.status(204).json();
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: error.message });
  }
};
