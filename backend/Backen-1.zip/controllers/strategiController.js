const { Strategi, Sasaran, ArahKebijakan, Program } = require("../models");

const strategiController = {
  // GET /api/strategi
  async getAll(req, res) {
    try {
      const { sasaran_id, jenisDokumen, tahun, periode_id } = req.query;
      const where = {};
      if (sasaran_id) where.sasaran_id = sasaran_id;
      if (jenisDokumen) where.jenisDokumen = jenisDokumen;
      if (tahun) where.tahun = tahun;
      if (periode_id) where.periode_id = periode_id;

      const strategis = await Strategi.findAll({
        where,
        attributes: [
          "id",
          "sasaran_id",
          "kode_strategi",
          "deskripsi",
          "periode_id",
        ],
        include: [
          {
            model: Sasaran,
            as: "Sasaran",
            attributes: ["id", "nomor", "isi_sasaran"],
          },
          {
            model: ArahKebijakan,
            as: "ArahKebijakan",
            attributes: [
              "id",
              "kode_arah",
              "deskripsi",
              "prioritas",
              "strategi_id",
            ],
          },
        ],
        order: [["kode_strategi", "ASC"]],
      });

      return res.json(strategis);
    } catch (error) {
      console.error("Error fetching strategi:", error);
      return res
        .status(500)
        .json({ message: "Error fetching strategi", error: error.message });
    }
  },

  // GET /api/strategi/by-sasaran/:sasaranId
  async bySasaran(req, res) {
    const sasaranId = req.params.sasaranId;
    try {
      const list = await Strategi.findAll({
        include: [
          {
            model: Program,
            as: "Program",
            where: { sasaran_id: sasaranId },
            attributes: [],
          },
        ],
        group: ["Strategi.id"],
      });
      res.json(list);
    } catch (err) {
      res.status(500).json({ message: "Gagal memuat strategi." });
    }
  },

  // GET /api/strategi/:id
  async getById(req, res) {
    try {
      const { id } = req.params;
      const strategi = await Strategi.findByPk(id, {
        attributes: [
          "id",
          "sasaran_id",
          "kode_strategi",
          "deskripsi",
          "periode_id",
        ],
        include: [
          {
            model: Sasaran,
            as: "Sasaran",
            attributes: ["id", "nomor", "isi_sasaran"],
          },
          {
            model: ArahKebijakan,
            as: "ArahKebijakan",
            attributes: [
              "id",
              "kode_arah",
              "deskripsi",
              "prioritas",
              "strategi_id",
            ],
          },
        ],
      });
      if (!strategi)
        return res.status(404).json({ error: "Strategi not found" });
      return res.json(strategi);
    } catch (error) {
      console.error("Error fetching strategi by id:", error);
      return res.status(500).json({ error: error.message });
    }
  },

  // POST /api/strategi
  async create(req, res) {
    try {
      const {
        sasaran_id,
        kode_strategi,
        deskripsi,
        jenisDokumen,
        tahun,
        periode_id,
      } = req.body;

      if (!periode_id) {
        return res.status(400).json({ message: "periode_id wajib diisi" });
      }

      const newStrategi = await Strategi.create({
        sasaran_id,
        kode_strategi,
        deskripsi,
        jenisDokumen,
        tahun,
        periode_id,
      });
      const strategiWithRelation = await Strategi.findByPk(newStrategi.id, {
        attributes: ["id", "sasaran_id", "kode_strategi", "deskripsi"],
        include: [
          {
            model: Sasaran,
            as: "Sasaran",
            attributes: ["id", "nomor", "isi_sasaran"],
          },
          {
            model: ArahKebijakan,
            as: "ArahKebijakan",
            attributes: [
              "id",
              "kode_arah",
              "deskripsi",
              "prioritas",
              "strategi_id",
            ],
          },
        ],
      });
      return res.status(201).json(strategiWithRelation);
    } catch (error) {
      console.error("Error creating strategi:", error);
      return res.status(400).json({ error: error.message });
    }
  },

  // PUT /api/strategi/:id
  async update(req, res) {
    try {
      const { id } = req.params;
      const { sasaran_id, kode_strategi, deskripsi, periode_id } = req.body;
      const [updated] = await Strategi.update(
        { sasaran_id, kode_strategi, deskripsi, periode_id },
        { where: { id } }
      );

      if (!updated)
        return res.status(404).json({ error: "Strategi not found" });

      const updatedStrategi = await Strategi.findByPk(id, {
        attributes: ["id", "sasaran_id", "kode_strategi", "deskripsi"],
        include: [
          {
            model: Sasaran,
            as: "Sasaran",
            attributes: ["id", "nomor", "isi_sasaran"],
          },
          {
            model: ArahKebijakan,
            as: "ArahKebijakan",
            attributes: [
              "id",
              "kode_arah",
              "deskripsi",
              "prioritas",
              "strategi_id",
            ],
          },
        ],
      });
      return res.json(updatedStrategi);
    } catch (error) {
      console.error("Error updating strategi:", error);
      return res.status(400).json({ error: error.message });
    }
  },

  // DELETE /api/strategi/:id
  async delete(req, res) {
    try {
      const { id } = req.params;
      const deleted = await Strategi.destroy({ where: { id } });
      if (!deleted)
        return res.status(404).json({ error: "Strategi not found" });
      return res.status(204).send();
    } catch (error) {
      console.error("Error deleting strategi:", error);
      return res.status(500).json({ error: error.message });
    }
  },
};

module.exports = strategiController;
