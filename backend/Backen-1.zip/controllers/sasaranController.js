const { Sasaran, Tujuan, Indikator } = require("../models");

module.exports = {
  // Create new sasaran
  async createSasaran(req, res) {
    try {
      const { nomor, isi_sasaran, tujuan_id, rpjmd_id, periode_id } = req.body;

      if (!nomor || !isi_sasaran || !tujuan_id || !rpjmd_id || !periode_id) {
        return res.status(400).json({ message: "Semua field wajib diisi" });
      }

      const newSasaran = await Sasaran.create({
        nomor,
        isi_sasaran,
        tujuan_id,
        rpjmd_id,
        periode_id,
      });

      res
        .status(201)
        .json({ message: "Sasaran berhasil ditambahkan", data: newSasaran });
    } catch (error) {
      console.error("Gagal menambahkan sasaran:", error);
      res
        .status(500)
        .json({ message: "Terjadi kesalahan server", error: error.message });
    }
  },

  // Get all sasaran
  async getAllSasaran(req, res) {
    try {
      const { tujuan_id, jenisDokumen, tahun, periode_id } = req.query;

      const indikatorWhere = {};
      if (jenisDokumen) indikatorWhere.jenisDokumen = jenisDokumen;
      if (tahun) indikatorWhere.tahun = tahun;

      const whereCondition = {};
      if (tujuan_id) whereCondition.tujuan_id = tujuan_id;
      if (periode_id) whereCondition.periode_id = periode_id;

      const sasaran = await Sasaran.findAll({
        where: whereCondition,
        include: [
          {
            model: Tujuan,
            as: "Tujuan",
            attributes: ["no_tujuan", "isi_tujuan"],
          },
          {
            model: Indikator,
            as: "Indikator",
            where: indikatorWhere,
            required: false,
            attributes: [
              "id",
              "kode_indikator",
              "nama_indikator",
              ["jenis_dokumen", "jenisDokumen"],
              "tahun",
            ],
          },
        ],
        order: [["nomor", "ASC"]],
        limit: 20,
      });

      res.status(200).json(sasaran);
    } catch (error) {
      console.error("Gagal mengambil data sasaran:", error);
      res.status(500).json({ message: "Terjadi kesalahan server" });
    }
  },

  // Get sasaran by ID
  async getSasaranById(req, res) {
    try {
      const { id } = req.params;
      const sasaran = await Sasaran.findByPk(id, {
        include: [
          { model: Tujuan, as: "Tujuan" },
          { model: Indikator, as: "Indikator" },
        ],
      });

      if (!sasaran) {
        return res.status(404).json({ message: "Sasaran tidak ditemukan" });
      }

      res.status(200).json(sasaran);
    } catch (error) {
      console.error("Gagal mengambil sasaran:", error);
      res.status(500).json({ message: "Terjadi kesalahan server" });
    }
  },

  // Ambil semua Tujuan untuk periode tertentu
  async getByPeriode(req, res) {
    try {
      const { periode_id } = req.params;
      const data = await Sasaran.findAll({
        where: { periode_id },
        include: [
          { model: Tujuan, as: "Tujuan" },
          { model: Indikator, as: "Indikator" },
        ],
      });
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  },

  // Update sasaran (hanya nomor & isi_sasaran)
  async updateSasaran(req, res) {
    try {
      const { id } = req.params;
      const { nomor, isi_sasaran } = req.body;

      const sasaran = await Sasaran.findByPk(id);
      if (!sasaran) {
        return res.status(404).json({ message: "Sasaran tidak ditemukan" });
      }

      const updates = {};
      if (nomor !== undefined) {
        updates.nomor = nomor; // langsung pakai string apapun
      }
      if (isi_sasaran !== undefined) {
        updates.isi_sasaran = isi_sasaran;
      }

      if (Object.keys(updates).length === 0) {
        return res
          .status(200)
          .json({ message: "Tidak ada perubahan", data: sasaran });
      }

      await sasaran.update(updates);

      return res
        .status(200)
        .json({ message: "Sasaran berhasil diperbarui", data: sasaran });
    } catch (error) {
      console.error("Gagal memperbarui sasaran:", error);
      return res
        .status(500)
        .json({ message: "Terjadi kesalahan server", error: error.message });
    }
  },

  // Delete sasaran
  async deleteSasaran(req, res) {
    try {
      const { id } = req.params;
      const sasaran = await Sasaran.findByPk(id);

      if (!sasaran) {
        return res.status(404).json({ message: "Sasaran tidak ditemukan" });
      }

      await sasaran.destroy();
      res.status(200).json({ message: "Sasaran berhasil dihapus" });
    } catch (error) {
      console.error("Gagal menghapus sasaran:", error);
      res.status(500).json({ message: "Terjadi kesalahan server" });
    }
  },

  async getNextNomor(req, res) {
    try {
      const { tujuan_id } = req.query;
      if (!tujuan_id) {
        return res.status(400).json({ message: "tujuan_id wajib diisi" });
      }

      const { Sasaran, Tujuan } = require("../models");

      // Cari nomor terbesar yang sudah ada untuk tujuan ini
      const lastSasaran = await Sasaran.findOne({
        where: { tujuan_id },
        order: [["nomor", "DESC"]],
      });

      // Ambil data no_tujuan dari tabel Tujuan
      const tujuan = await Tujuan.findByPk(tujuan_id);
      if (!tujuan) {
        return res.status(404).json({ message: "Tujuan tidak ditemukan" });
      }

      let nextNomor;

      if (!lastSasaran) {
        nextNomor = `${tujuan.no_tujuan}.1`;
      } else {
        // lastSasaran.nomor = contoh: "2.2.3"
        const parts = lastSasaran.nomor.split(".");
        const lastNumber = parseInt(parts[parts.length - 1], 10);
        const baseNomor = parts.slice(0, parts.length - 1).join(".");
        nextNomor = `${baseNomor}.${lastNumber + 1}`;
      }

      res.status(200).json({ nextNomor });
    } catch (error) {
      console.error("Gagal mengambil nomor sasaran berikutnya:", error);
      res.status(500).json({ message: "Terjadi kesalahan server" });
    }
  },
};
