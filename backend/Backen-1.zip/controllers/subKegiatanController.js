const { SubKegiatan, Kegiatan } = require("../models");

// Create a new sub-kegiatan
exports.createSubKegiatan = async (req, res) => {
  try {
    const {
      kegiatan_id,
      nama_sub_kegiatan,
      kode_sub_kegiatan,
      anggaran_sub_kegiatan,
      anggaran_kegiatan,
      pagu_anggaran,
      waktu_pelaksanaan,
      nama_opd,
      nama_bidang_opd,
      sumber_daya_pendukung,
      rencana_lokasi_desa,
      rencana_lokasi_kecamatan,
      rencana_lokasi_kabupaten,
      deskripsi,
      kerangka_pelaksanaan,
      output,
      pihak_terlibat,
      rpjmd_id,
      periode_id,
      target_awal,
      target_akhir,
      satuan,
      realisasi_awal,
      realisasi_akhir,
      status_monitoring,
      tanggal_laporan,
      catatan,
    } = req.body;

    // Validasi manual
    if (
      !kegiatan_id ||
      !nama_sub_kegiatan ||
      !kode_sub_kegiatan ||
      !anggaran_sub_kegiatan ||
      !anggaran_kegiatan ||
      !pagu_anggaran ||
      !waktu_pelaksanaan ||
      !nama_opd ||
      !nama_bidang_opd ||
      !sumber_daya_pendukung ||
      !rencana_lokasi_desa ||
      !rencana_lokasi_kecamatan ||
      !rencana_lokasi_kabupaten ||
      !deskripsi ||
      !periode_id
    ) {
      return res
        .status(400)
        .json({ message: "Field wajib diisi tidak lengkap" });
    }

    const newSub = await SubKegiatan.create({
      kegiatan_id,
      nama_sub_kegiatan,
      kode_sub_kegiatan,
      anggaran_sub_kegiatan,
      anggaran_kegiatan,
      pagu_anggaran,
      waktu_pelaksanaan,
      nama_opd,
      nama_bidang_opd,
      sumber_daya_pendukung,
      rencana_lokasi_desa,
      rencana_lokasi_kecamatan,
      rencana_lokasi_kabupaten,
      deskripsi,
      kerangka_pelaksanaan,
      output,
      pihak_terlibat,
      rpjmd_id,
      periode_id,
      target_awal,
      target_akhir,
      satuan,
      status_monitoring,
      tanggal_laporan,
      catatan,
    });

    res.status(201).json(newSub);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Gagal membuat SubKegiatan", error });
  }
};

// Get max kode_sub_kegiatan for a given kegiatan_id
exports.getNextKodeSubKegiatan = async (req, res) => {
  try {
    const { kegiatan_id } = req.params;
    const kegiatan = await Kegiatan.findByPk(kegiatan_id);
    if (!kegiatan)
      return res.status(404).json({ message: "Kegiatan tidak ditemukan" });

    const prefix = kegiatan.kode_kegiatan;
    const subs = await SubKegiatan.findAll({
      where: { kegiatan_id },
      attributes: ["kode_sub_kegiatan"],
    });

    const lastNumber =
      subs
        .map((s) => s.kode_sub_kegiatan)
        .filter((kode) => kode.startsWith(prefix))
        .map((kode) => parseInt(kode.split(".").pop()))
        .filter((num) => !isNaN(num))
        .sort((a, b) => b - a)[0] || 0;

    const nextNumber = String(lastNumber + 1).padStart(4, "0");
    const nextKode = `${prefix}.${nextNumber}`;

    res.status(200).json({ nextKode });
  } catch (err) {
    console.error("Error generate kode sub kegiatan:", err);
    res.status(500).json({ message: "Gagal generate kode sub kegiatan" });
  }
};

// Get all sub-kegiatan
exports.getAllSubKegiatan = async (req, res) => {
  try {
    const { periode_id, page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);

    const where = {};
    if (periode_id) where.periode_id = periode_id;

    const { count, rows } = await SubKegiatan.findAndCountAll({
      where,
      include: [
        {
          model: Kegiatan,
          as: "kegiatan",
          attributes: ["id", "nama_kegiatan"],
        },
      ],
      limit: parseInt(limit, 10),
      offset,
    });

    res.status(200).json({
      data: rows,
      meta: {
        total: count,
        totalPages: Math.ceil(count / limit),
        currentPage: parseInt(page, 10),
        pageSize: parseInt(limit, 10),
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error retrieving sub-kegiatan", error });
  }
};

// Get sub-kegiatan by ID
exports.getSubKegiatanById = async (req, res) => {
  try {
    const subKegiatan = await SubKegiatan.findByPk(req.params.id, {
      include: [
        {
          model: Kegiatan,
          as: "kegiatan",
        },
      ],
    });

    if (subKegiatan) {
      res.status(200).json(subKegiatan);
    } else {
      res.status(404).json({ message: "Sub-kegiatan tidak ditemukan" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error retrieving sub-kegiatan", error });
  }
};

// Update sub-kegiatan
exports.updateSubKegiatan = async (req, res) => {
  try {
    const {
      kegiatan_id,
      nama_sub_kegiatan,
      kode_sub_kegiatan,
      anggaran_sub_kegiatan,
      anggaran_kegiatan,
      pagu_anggaran,
      waktu_pelaksanaan,
      nama_opd,
      nama_bidang_opd,
      sumber_daya_pendukung,
      rencana_lokasi_desa,
      rencana_lokasi_kecamatan,
      rencana_lokasi_kabupaten,
      deskripsi,
      kerangka_pelaksanaan,
      output,
      pihak_terlibat,
      rpjmd_id,
      periode_id,
      target_awal,
      target_akhir,
      satuan,
      realisasi_awal,
      realisasi_akhir,
      status_monitoring,
      tanggal_laporan,
      catatan,
    } = req.body;

    const sub = await SubKegiatan.findByPk(req.params.id);
    if (!sub) {
      return res.status(404).json({ message: "Sub-kegiatan tidak ditemukan" });
    }

    await sub.update({
      kegiatan_id,
      nama_sub_kegiatan,
      kode_sub_kegiatan,
      anggaran_sub_kegiatan,
      anggaran_kegiatan,
      pagu_anggaran,
      waktu_pelaksanaan,
      nama_opd,
      nama_bidang_opd,
      sumber_daya_pendukung,
      rencana_lokasi_desa,
      rencana_lokasi_kecamatan,
      rencana_lokasi_kabupaten,
      deskripsi,
      kerangka_pelaksanaan,
      output,
      pihak_terlibat,
      rpjmd_id,
      periode_id,
      target_awal,
      target_akhir,
      satuan,
      realisasi_awal,
      realisasi_akhir,
      status_monitoring,
      tanggal_laporan,
      catatan,
    });

    res.json(sub);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Gagal mengupdate SubKegiatan", error });
  }
};

// Delete sub-kegiatan
exports.deleteSubKegiatan = async (req, res) => {
  try {
    const subKegiatan = await SubKegiatan.findByPk(req.params.id);
    if (subKegiatan) {
      await subKegiatan.destroy();
      res.status(200).json({ message: "Sub-kegiatan berhasil dihapus" });
    } else {
      res.status(404).json({ message: "Sub-kegiatan tidak ditemukan" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error deleting sub-kegiatan", error });
  }
};
