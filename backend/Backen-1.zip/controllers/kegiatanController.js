// controllers/kegiatanController.js
const { Kegiatan, Program, RPJMD, SubKegiatan } = require("../models");
const { Op } = require("sequelize");

const defaultDokumen = {
  jenisDokumen: "RPJMD",
  tahun: "2025",
};

// Create a new kegiatan
exports.createKegiatan = async (req, res) => {
  try {
    const {
      program_id,
      rpjmd_id,
      periode_id,
      nama_kegiatan,
      kode_kegiatan,
      anggaran,
      jenisDokumen = defaultDokumen.jenisDokumen,
      tahun = defaultDokumen.tahun,
    } = req.body;

    if (
      !program_id ||
      !rpjmd_id ||
      !periode_id ||
      !nama_kegiatan ||
      !kode_kegiatan ||
      !anggaran
    ) {
      return res.status(400).json({ message: "Semua field wajib diisi." });
    }

    const newKegiatan = await Kegiatan.create({
      program_id,
      rpjmd_id,
      periode_id,
      nama_kegiatan,
      kode_kegiatan,
      anggaran,
      jenisDokumen,
      tahun,
    });

    res
      .status(201)
      .json({ message: "Kegiatan berhasil dibuat", data: newKegiatan });
  } catch (error) {
    console.error("Create Kegiatan Error:", error);
    res
      .status(500)
      .json({ message: "Gagal membuat kegiatan", error: error.message });
  }
};

// Get all kegiatan
exports.getKegiatans = async (req, res) => {
  try {
    const { program_id, periode_id, page = 1, limit, search } = req.query;

    const where = {};
    if (program_id) where.program_id = program_id;
    if (periode_id) where.periode_id = periode_id;
    if (search) where.nama_kegiatan = { [Op.like]: `%${search}%` };

    const pageNum = parseInt(page, 10);
    const limitNum = limit ? parseInt(limit, 10) : 20;
    const offset = (pageNum - 1) * limitNum;

    const { rows, count } = await Kegiatan.findAndCountAll({
      where,
      include: [
        {
          model: Program,
          as: "program",
          attributes: ["id", "kode_program", "nama_program"],
        },
      ],
      distinct: true,
      order: [
        [{ model: Program, as: "program" }, "kode_program", "ASC"],
        ["kode_kegiatan", "ASC"],
      ],
      limit: limitNum,
      offset,
    });

    res.json({
      data: rows,
      meta: {
        total: count,
        totalPages: Math.ceil(count / limitNum),
        currentPage: pageNum,
        pageSize: limitNum,
      },
    });
  } catch (error) {
    console.error("Get Kegiatans Error:", error);
    res
      .status(500)
      .json({ message: "Gagal mengambil kegiatan", error: error.message });
  }
};

// Hitung jumlah Kegiatan per Program
exports.countByProgram = async (req, res) => {
  try {
    const { program_id } = req.query;
    if (!program_id) {
      return res.status(400).json({ message: "program_id wajib diberikan" });
    }
    const count = await Kegiatan.count({ where: { program_id } });
    res.status(200).json({ count });
  } catch (error) {
    console.error("Count By Program Error:", error);
    res
      .status(500)
      .json({ message: "Gagal menghitung kegiatan", error: error.message });
  }
};

// Get kegiatan by ID
exports.getKegiatanById = async (req, res) => {
  try {
    const kegiatan = await Kegiatan.findByPk(req.params.id, {
      include: [
        { model: Program, as: "program" },
        { model: RPJMD, as: "rpjmd" },
        { model: SubKegiatan, as: "sub_kegiatan" },
      ],
    });

    if (!kegiatan) {
      return res.status(404).json({ message: "Kegiatan tidak ditemukan" });
    }

    res.status(200).json({ data: kegiatan });
  } catch (error) {
    console.error("Get Kegiatan By ID Error:", error);
    res
      .status(500)
      .json({ message: "Gagal mengambil kegiatan", error: error.message });
  }
};

// Update kegiatan
exports.updateKegiatan = async (req, res) => {
  try {
    const kegiatan = await Kegiatan.findByPk(req.params.id);
    if (!kegiatan) {
      return res.status(404).json({ message: "Kegiatan tidak ditemukan" });
    }

    const {
      program_id,
      rpjmd_id,
      periode_id,
      nama_kegiatan,
      kode_kegiatan,
      anggaran,
      jenisDokumen = defaultDokumen.jenisDokumen,
      tahun = defaultDokumen.tahun,
    } = req.body;

    await kegiatan.update({
      program_id,
      rpjmd_id,
      periode_id,
      nama_kegiatan,
      kode_kegiatan,
      anggaran,
      jenisDokumen,
      tahun,
    });

    res
      .status(200)
      .json({ message: "Kegiatan berhasil diperbarui", data: kegiatan });
  } catch (error) {
    console.error("Update Kegiatan Error:", error);
    res
      .status(500)
      .json({ message: "Gagal memperbarui kegiatan", error: error.message });
  }
};

// Delete kegiatan
exports.deleteKegiatan = async (req, res) => {
  try {
    const kegiatan = await Kegiatan.findByPk(req.params.id);

    if (!kegiatan) {
      return res.status(404).json({ message: "Kegiatan tidak ditemukan" });
    }

    await kegiatan.destroy();

    res.status(200).json({ message: "Kegiatan berhasil dihapus" });
  } catch (error) {
    console.error("Delete Kegiatan Error:", error);
    res
      .status(500)
      .json({ message: "Gagal menghapus kegiatan", error: error.message });
  }
};
