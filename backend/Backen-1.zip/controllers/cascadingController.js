const { Cascading } = require("../models");

exports.list = async (req, res) => {
  const { jenisDokumen, tahun } = req.query;

  const where = {};
  if (jenisDokumen) where.jenisDokumen = jenisDokumen;
  if (tahun) where.tahun = tahun;

  try {
    const items = await Cascading.findAll({
      where,
      include: [
        "misi",
        "priorNasional",
        "priorDaerah",
        "priorKepda",
        "tujuan",
        "sasaran",
        "program",
        "kegiatan",
        "strategi",
        "arahKebijakan",
      ],
    });
    res.json(items);
  } catch (err) {
    console.error("Gagal mengambil cascading:", err);
    res.status(500).json({ message: "Server error" });
  }
};

exports.get = async (req, res) => {
  try {
    const it = await Cascading.findByPk(req.params.id, {
      include: Object.values(Cascading.associations),
    });
    if (!it) return res.status(404).json({ message: "Not found" });
    res.json(it);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};

exports.create = async (req, res) => {
  const { jenisDokumen, tahun, ...data } = req.body;

  if (!jenisDokumen || !tahun) {
    return res
      .status(400)
      .json({ message: "jenisDokumen dan tahun wajib diisi." });
  }

  try {
    const it = await Cascading.create({ ...data, jenisDokumen, tahun });
    res.status(201).json(it);
  } catch (err) {
    console.error("Gagal membuat cascading:", err);
    res.status(500).json({ message: "Server error" });
  }
};

exports.update = async (req, res) => {
  const { jenisDokumen, tahun, ...data } = req.body;

  try {
    const [n] = await Cascading.update(
      { ...data, jenisDokumen, tahun },
      { where: { id: req.params.id } }
    );
    if (!n) return res.status(404).json({ message: "Not found" });
    res.json({ message: "Updated" });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};

exports.remove = async (req, res) => {
  try {
    const n = await Cascading.destroy({ where: { id: req.params.id } });
    if (!n) return res.status(404).json({ message: "Not found" });
    res.json({ message: "Deleted" });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};
