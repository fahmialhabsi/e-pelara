const { Op } = require("sequelize");
const { Tujuan, IndikatorTujuan } = require("../models");

const defaultDokumen = {
  jenisDokumen: "RPJMD",
  tahun: "2025",
};

async function create(req, res) {
  try {
    const entries = Array.isArray(req.body) ? req.body : [req.body];
    const created = await Promise.all(
      entries.map((data) =>
        IndikatorTujuan.create({
          ...data,
          jenisDokumen: data.jenisDokumen || defaultDokumen.jenisDokumen,
          tahun: data.tahun || defaultDokumen.tahun,
        })
      )
    );
    return res.status(201).json(created);
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}

async function findAll(req, res) {
  try {
    const indikatorTujuan = await IndikatorTujuan.findAll({
      attributes: {
        exclude: ["createdAt", "updatedAt"],
      },
      include: [
        {
          association: "sasarans",
          attributes: {
            exclude: ["createdAt", "updatedAt"],
          },
        },
      ],
    });
    return res.status(200).json(indikatorTujuan);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
}

async function findOne(req, res) {
  try {
    const indikatorTujuan = await IndikatorTujuan.findByPk(req.params.id, {
      attributes: {
        exclude: ["createdAt", "updatedAt"],
      },
      include: [
        {
          association: "sasarans",
          attributes: {
            exclude: ["createdAt", "updatedAt"],
          },
        },
      ],
    });
    if (!indikatorTujuan) {
      return res.status(404).json({ message: "Indikator Tujuan not found" });
    }
    return res.status(200).json(indikatorTujuan);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
}

async function bulkCreateDetail(req, res) {
  try {
    const { indikatorId } = req.params;
    const rows = req.body.rows;
    if (!Array.isArray(rows) || rows.length === 0) {
      return res
        .status(400)
        .json({ message: "rows harus berupa array tidak kosong" });
    }

    const toInsert = rows.map((r) => ({
      ...r,
      id: undefined,
      indikator_id: indikatorId,
      jenisDokumen: r.jenisDokumen || defaultDokumen.jenisDokumen,
      tahun: r.tahun || defaultDokumen.tahun,
    }));

    const created = await IndikatorTujuan.bulkCreate(toInsert);
    return res.status(201).json(created);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
}

async function update(req, res) {
  try {
    const indikatorTujuan = await IndikatorTujuan.findByPk(req.params.id);
    if (!indikatorTujuan) {
      return res.status(404).json({ message: "Indikator Tujuan not found" });
    }

    const updateData = {
      ...req.body,
      jenisDokumen: req.body.jenisDokumen || defaultDokumen.jenisDokumen,
      tahun: req.body.tahun || defaultDokumen.tahun,
    };

    await indikatorTujuan.update(updateData);
    return res.status(200).json(indikatorTujuan);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
}

async function remove(req, res) {
  try {
    const indikatorTujuan = await IndikatorTujuan.findByPk(req.params.id);
    if (!indikatorTujuan) {
      return res.status(404).json({ message: "Indikator Tujuan not found" });
    }
    await indikatorTujuan.destroy();
    return res.status(204).json();
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
}

async function listByTujuan(req, res) {
  try {
    const { tujuan_id } = req.query;
    if (!tujuan_id) {
      return res.status(400).json({ message: "tujuan_id required" });
    }
    const data = await IndikatorTujuan.findAll({
      where: { tujuan_id },
    });
    return res.json({ data });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Server error" });
  }
}

async function getNextKodeIndikator(req, res) {
  try {
    const tujuanId = req.params.tujuanId;
    if (!tujuanId) {
      return res.status(400).json({ message: "tujuanId is required" });
    }

    const tujuan = await Tujuan.findByPk(tujuanId);
    if (!tujuan) {
      return res.status(404).json({ message: "Tujuan tidak ditemukan" });
    }

    const prefix = `${tujuan.no_tujuan}`;
    const existing = await IndikatorTujuan.findAll({
      attributes: ["kode_indikator"],
      where: {
        kode_indikator: {
          [Op.like]: `${prefix}-%`,
        },
      },
      order: [["kode_indikator", "DESC"]],
    });

    const suffix = String(existing.length + 1).padStart(2, "0");
    const newKode = `${prefix}-${suffix}`;

    return res.json({ kode: newKode });
  } catch (err) {
    console.error("Error in getNextKodeIndikator:", err);
    return res.status(500).json({
      message: "Gagal mengambil kode indikator berikutnya",
      error: err.message,
    });
  }
}

module.exports = {
  create,
  findAll,
  findOne,
  bulkCreateDetail,
  update,
  remove,
  listByTujuan,
  getNextKodeIndikator,
};
