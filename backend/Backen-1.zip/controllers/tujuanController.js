"use strict";
const { Tujuan, Misi, Sasaran } = require("../models");

// Get all Tujuan
exports.getAllTujuan = async (req, res) => {
  try {
    const { periode_id } = req.query;
    const whereClause = periode_id ? { periode_id } : {};

    const tujuans = await Tujuan.findAll({
      where: whereClause,
      include: [
        {
          model: Misi,
          as: "Misi",
          attributes: ["no_misi", "isi_misi"],
        },
      ],
      order: [["no_tujuan", "ASC"]],
    });

    return res.json(tujuans);
  } catch (err) {
    console.error("Error fetching all Tujuan:", err);
    return res
      .status(500)
      .json({ message: "Failed to fetch Tujuan", error: err.message });
  }
};

// Get Tujuan by Misi
exports.getTujuanByMisi = async (req, res) => {
  try {
    const { misi_id, periode_id } = req.query;
    if (!misi_id || !periode_id) {
      return res
        .status(400)
        .json({ message: "misi_id dan periode_id wajib diisi" });
    }

    const tujuans = await Tujuan.findAll({
      where: { misi_id, periode_id },
      order: [["no_tujuan", "ASC"]],
    });

    return res.json(tujuans);
  } catch (err) {
    console.error("Error fetching Tujuan by Misi:", err);
    return res
      .status(500)
      .json({ message: "Gagal mengambil Tujuan", error: err.message });
  }
};

// Get Tujuan by ID
exports.getTujuanById = async (req, res) => {
  try {
    const tujuan = await Tujuan.findByPk(req.params.id, {
      include: [{ model: Misi, as: "Misi" }],
    });
    if (!tujuan)
      return res.status(404).json({ message: "Tujuan tidak ditemukan" });

    return res.json(tujuan);
  } catch (err) {
    console.error("Error fetching Tujuan by ID:", err);
    return res
      .status(500)
      .json({ message: "Gagal mengambil Tujuan", error: err.message });
  }
};

// Get Tujuan by Periode (tanpa misi_id)
exports.getByPeriode = async (req, res) => {
  try {
    const { periode_id } = req.query;

    if (!periode_id) {
      return res.status(400).json({ message: "periode_id wajib diisi" });
    }

    const tujuans = await Tujuan.findAll({
      where: { periode_id },
      include: [
        {
          model: Misi,
          as: "Misi",
          attributes: ["no_misi", "isi_misi"],
        },
      ],
      order: [["no_tujuan", "ASC"]],
    });

    return res.json(tujuans);
  } catch (err) {
    console.error("Error fetching Tujuan by periode:", err);
    return res
      .status(500)
      .json({ message: "Gagal mengambil Tujuan", error: err.message });
  }
};

// Create Tujuan
exports.createTujuan = async (req, res) => {
  try {
    const { periode_id, misi_id, no_tujuan, isi_tujuan } = req.body;
    if (!periode_id || !misi_id || !no_tujuan || !isi_tujuan) {
      return res
        .status(400)
        .json({ message: "Field wajib diisi tidak lengkap" });
    }

    const newTujuan = await Tujuan.create(req.body);
    return res.status(201).json(newTujuan);
  } catch (err) {
    console.error("Error creating Tujuan:", err);
    return res
      .status(500)
      .json({ message: "Gagal membuat Tujuan", error: err.message });
  }
};

// Update Tujuan
exports.updateTujuan = async (req, res) => {
  try {
    const [updated] = await Tujuan.update(req.body, {
      where: { id: req.params.id },
    });

    if (!updated)
      return res.status(404).json({ message: "Tujuan tidak ditemukan" });

    const updatedTujuan = await Tujuan.findByPk(req.params.id);
    return res.json(updatedTujuan);
  } catch (err) {
    console.error("Error updating Tujuan:", err);
    return res
      .status(500)
      .json({ message: "Gagal memperbarui Tujuan", error: err.message });
  }
};

// Delete Tujuan
exports.deleteTujuan = async (req, res) => {
  try {
    const deleted = await Tujuan.destroy({ where: { id: req.params.id } });

    if (!deleted)
      return res.status(404).json({ message: "Tujuan tidak ditemukan" });

    return res.json({ message: "Tujuan berhasil dihapus" });
  } catch (err) {
    console.error("Error deleting Tujuan:", err);
    return res
      .status(500)
      .json({ message: "Gagal menghapus Tujuan", error: err.message });
  }
};
