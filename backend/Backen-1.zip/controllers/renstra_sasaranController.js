const {
  RenstraSasaran,
  RenstraOPD,
  Sasaran,
  RenstraTujuan,
  RenstraStrategi,
  RenstraKebijakan,
  RenstraProgram,
  RenstraKegiatan,
  RenstraSubkegiatan,
} = require("../models");

exports.create = async (req, res) => {
  try {
    const data = await RenstraSasaran.create(req.body);
    res.status(201).json(data);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.findAll = async (req, res) => {
  try {
    const data = await RenstraSasaran.findAll({
      include: [
        {
          model: RenstraOPD,
          as: "renstra_opd",
          attributes: ["id", "bidang_opd", "sub_bidang_opd"],
        },
        {
          model: Sasaran,
          as: "sasaran_rpjmd",
          attributes: ["id", "kode", "uraian"], // sesuaikan dengan field kamu
        },
        {
          model: RenstraTujuan,
          as: "tujuan_opd",
          attributes: ["id", "isi_tujuan"],
        },
        {
          model: RenstraStrategi,
          as: "strategi_opd",
          attributes: ["id", "isi_strategi"],
        },
        {
          model: RenstraKebijakan,
          as: "kebijakan_opd",
          attributes: ["id", "isi_kebijakan"],
        },
        {
          model: RenstraProgram,
          as: "program_opd",
          attributes: ["id", "isi_program"],
        },
        {
          model: RenstraKegiatan,
          as: "kegiatan_opd",
          attributes: ["id", "isi_kegiatan"],
        },
        {
          model: RenstraSubkegiatan,
          as: "subkegiatan_opd",
          attributes: ["id", "isi_subkegiatan"],
        },
      ],
    });

    res.json(data);
  } catch (err) {
    console.error("ERROR:", err);
    res.status(500).json({ error: err.message });
  }
};

exports.findOne = async (req, res) => {
  try {
    const data = await RenstraSasaran.findByPk(req.params.id, {
      include: [
        {
          model: RenstraOPD,
          as: "renstra_opd",
          attributes: ["id", "bidang_opd", "sub_bidang_opd"],
        },
        {
          model: Sasaran,
          as: "sasaran_rpjmd",
          attributes: ["id", "kode", "uraian"], // sesuaikan field-nya
        },
        {
          model: RenstraTujuan,
          as: "tujuan_opd",
          attributes: ["id", "isi_tujuan"],
        },
        {
          model: RenstraStrategi,
          as: "strategi_opd",
          attributes: ["id", "isi_strategi"],
        },
        {
          model: RenstraKebijakan,
          as: "kebijakan_opd",
          attributes: ["id", "isi_kebijakan"],
        },
        {
          model: RenstraProgram,
          as: "program_opd",
          attributes: ["id", "isi_program"],
        },
        {
          model: RenstraKegiatan,
          as: "kegiatan_opd",
          attributes: ["id", "isi_kegiatan"],
        },
        {
          model: RenstraSubkegiatan,
          as: "subkegiatan_opd",
          attributes: ["id", "isi_subkegiatan"],
        },
      ],
    });

    if (!data) {
      return res.status(404).json({ message: "Data not found" });
    }

    res.json(data);
  } catch (err) {
    console.error("ERROR:", err);
    res.status(500).json({ error: err.message });
  }
};

exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const [updated] = await RenstraSasaran.update(req.body, { where: { id } });
    if (!updated) return res.status(404).json({ message: "Data not found" });
    const updatedData = await RenstraSasaran.findByPk(id);
    res.json(updatedData);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.delete = async (req, res) => {
  try {
    const id = req.params.id;
    const deleted = await RenstraSasaran.destroy({ where: { id } });
    if (!deleted) return res.status(404).json({ message: "Data not found" });
    res.json({ message: "Deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
