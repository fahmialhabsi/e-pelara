const {
  Indikator,
  Sasaran,
  Tujuan,
  Misi,
  IndikatorDetail,
} = require("../models");

// Helper: Bersihkan payload dari string kosong
const cleanPayload = (payload) => {
  const result = {};
  for (const key in payload) {
    result[key] = payload[key] === "" ? null : payload[key];
  }
  return result;
};

// Relasi untuk include
const withRelations = [
  { model: Sasaran, as: "sasaran" },
  { model: Tujuan, as: "tujuan" },
  { model: Misi, as: "misi" },
  { model: IndikatorDetail, as: "details" },
];

// Create new Indikator
exports.createIndikator = async (req, res, next) => {
  try {
    const cleaned = cleanPayload(req.body);

    // Default fallback jika null (setelah dibersihkan)
    if (!cleaned.jenisDokumen) cleaned.jenisDokumen = "RPJMD";
    if (!cleaned.tahun) cleaned.tahun = "2025";
    if (!cleaned.level_dokumen) cleaned.level_dokumen = "RPJMD";
    if (!cleaned.jenis_iku) cleaned.jenis_iku = "IKU";

    // Validasi manual untuk field ENUM (jika ingin lebih eksplisit)
    if (!cleaned.jenis_indikator) {
      return res.status(400).json({
        status: "error",
        message: "Jenis indikator wajib diisi",
      });
    }

    if (!cleaned.tipe_indikator) {
      return res.status(400).json({
        status: "error",
        message: "Tipe indikator wajib diisi",
      });
    }

    const newIndikator = await Indikator.create(cleaned);

    return res.status(201).json({ status: "success", data: newIndikator });
  } catch (error) {
    if (error.name === "SequelizeValidationError") {
      return res.status(400).json({
        status: "error",
        message: error.message,
        detail: error.errors,
      });
    }
    next(error);
  }
};

// Get all Indikators
exports.getIndikators = async (req, res, next) => {
  try {
    const where = {};
    if (req.query.level_dokumen) {
      where.level_dokumen = req.query.level_dokumen;
    }
    if (req.query.jenis_iku) {
      where.jenis_iku = req.query.jenis_iku;
    }

    const list = await Indikator.findAll({ where, include: withRelations });
    return res.json({ status: "success", data: list });
  } catch (error) {
    next(error);
  }
};

// Get Indikator by ID
exports.getIndikatorById = async (req, res, next) => {
  try {
    const indikator = await Indikator.findByPk(req.params.id, {
      include: withRelations,
    });

    if (!indikator) {
      return res
        .status(404)
        .json({ status: "error", message: "Indikator tidak ditemukan" });
    }

    return res.json({ status: "success", data: indikator });
  } catch (error) {
    next(error);
  }
};

// Update Indikator
exports.updateIndikator = async (req, res, next) => {
  try {
    const indikator = await Indikator.findByPk(req.params.id);
    if (!indikator) {
      return res
        .status(404)
        .json({ status: "error", message: "Indikator tidak ditemukan" });
    }

    const allowedFields = [
      "sasaran_id",
      "tujuan_id",
      "misi_id",
      "kode_indikator",
      "nama_indikator",
      "definisi_operasional",
      "satuan",
      "metode_penghitungan",
      "baseline",
      "target_tahun_1",
      "target_tahun_2",
      "target_tahun_3",
      "target_tahun_4",
      "target_tahun_5",
      "sumber_data",
      "penanggung_jawab",
      "keterangan",
      "jenis_indikator",
      "tipe_indikator",
      "kriteria_kuantitatif",
      "kriteria_kualitatif",
      "jenisDokumen",
      "tahun",
      "level_dokumen",
      "jenis_iku",
    ];

    const rawPayload = {};
    for (const key of allowedFields) {
      if (req.body[key] !== undefined) {
        rawPayload[key] = req.body[key];
      }
    }

    const cleanedPayload = cleanPayload(rawPayload);

    await indikator.update(cleanedPayload);
    return res.json({ status: "success", data: indikator });
  } catch (error) {
    console.error("[UPDATE] Error:", error);
    return res.status(500).json({
      status: "error",
      message: error.message,
      detail: error.errors || null,
    });
  }
};

// Delete Indikator
exports.deleteIndikator = async (req, res, next) => {
  try {
    const indikator = await Indikator.findByPk(req.params.id);
    if (!indikator) {
      return res
        .status(404)
        .json({ status: "error", message: "Indikator tidak ditemukan" });
    }

    await indikator.destroy();
    return res.json({
      status: "success",
      message: "Indikator berhasil dihapus",
    });
  } catch (error) {
    next(error);
  }
};
