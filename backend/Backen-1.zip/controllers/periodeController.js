// controllers/periodeController.js
const { Op } = require("sequelize");
const { PeriodeRpjmd } = require("../models");

// GET /api/periode-rpjmd/active
const getActivePeriode = async (req, res) => {
  try {
    const currentYear = new Date().getFullYear();

    const periode = await PeriodeRpjmd.findOne({
      where: {
        tahun_awal: { [Op.lte]: currentYear },
        tahun_akhir: { [Op.gte]: currentYear },
      },
    });

    if (!periode) {
      return res.status(404).json({
        message: `Periode aktif untuk tahun ${currentYear} tidak ditemukan.`,
      });
    }

    res.json(periode);
  } catch (error) {
    console.error("[PeriodeController.getActivePeriode]", error);
    res.status(500).json({ message: "Gagal mengambil periode aktif." });
  }
};

module.exports = {
  getActivePeriode,
};
