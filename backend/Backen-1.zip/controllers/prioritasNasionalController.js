// controllers/prioritasNasionalController.js
const { PrioritasNasional } = require("../models");
const { Op, DatabaseError } = require("sequelize");

exports.create = async (req, res) => {
  try {
    const data = await PrioritasNasional.create(req.body);
    return res.status(201).json({ message: "Data berhasil dibuat", data });
  } catch (error) {
    console.error(error);
    if (
      error instanceof DatabaseError &&
      error.parent &&
      error.parent.code === "ER_DATA_TOO_LONG"
    ) {
      return res
        .status(400)
        .json({ message: "Nilai salah satu field terlalu panjang." });
    }
    return res
      .status(500)
      .json({ message: "Gagal membuat data", error: error.message });
  }
};

exports.getAll = async (req, res) => {
  try {
    const { page, limit, search = "" } = req.query;

    const where = {
      [Op.or]: [
        { kode_prionas: { [Op.like]: `%${search}%` } },
        { uraian_prionas: { [Op.like]: `%${search}%` } },
      ],
    };

    // Jika tidak ada parameter page dan limit, kirim semua data (misal untuk dropdown)
    if (!page && !limit) {
      const data = await PrioritasNasional.findAll({
        where,
        order: [["id", "ASC"]],
      });
      return res.json({ data });
    }

    // Default paginasi jika page dan limit tersedia
    const currentPage = parseInt(page, 10) || 1;
    const pageSize = parseInt(limit, 10) || 10;
    const offset = (currentPage - 1) * pageSize;

    const { rows, count } = await PrioritasNasional.findAndCountAll({
      where,
      limit: pageSize,
      offset,
      order: [["id", "ASC"]],
    });

    return res.json({
      data: rows,
      meta: {
        total: count,
        page: currentPage,
        limit: pageSize,
        totalPages: Math.ceil(count / pageSize),
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message: "Gagal mengambil data",
      error: error.message,
    });
  }
};

exports.getById = async (req, res) => {
  try {
    const data = await PrioritasNasional.findByPk(req.params.id);
    if (!data) return res.status(404).json({ message: "Data tidak ditemukan" });
    return res.status(200).json({ data });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Gagal mengambil data", error: error.message });
  }
};

exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const [updated] = await PrioritasNasional.update(req.body, {
      where: { id },
    });
    if (!updated)
      return res.status(404).json({ message: "Data tidak ditemukan" });
    const data = await PrioritasNasional.findByPk(id);
    return res.status(200).json({ message: "Data berhasil diperbarui", data });
  } catch (error) {
    console.error(error);
    if (
      error instanceof DatabaseError &&
      error.parent &&
      error.parent.code === "ER_DATA_TOO_LONG"
    ) {
      return res
        .status(400)
        .json({ message: "Nilai salah satu field terlalu panjang." });
    }
    return res
      .status(500)
      .json({ message: "Gagal memperbarui data", error: error.message });
  }
};

exports.remove = async (req, res) => {
  try {
    const deleted = await PrioritasNasional.destroy({
      where: { id: req.params.id },
    });
    if (!deleted)
      return res.status(404).json({ message: "Data tidak ditemukan" });
    return res.status(200).json({ message: "Data berhasil dihapus" });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Gagal menghapus data", error: error.message });
  }
};
