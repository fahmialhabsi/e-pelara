// controllers/indikatorKegiatanController.js
const { IndikatorKegiatan } = require("../models");

const defaultDokumen = {
  jenisDokumen: "RPJMD",
  tahun: "2025",
};

exports.getAll = async (req, res) => {
  try {
    const kegiatan = await IndikatorKegiatan.findAll({ include: ["program"] });
    return res.status(200).json(kegiatan);
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Error fetching indikator kegiatan" });
  }
};

exports.getById = async (req, res) => {
  try {
    const kegiatan = await IndikatorKegiatan.findByPk(req.params.id, {
      include: ["program"],
    });
    if (!kegiatan) {
      return res.status(404).json({ message: "Indikator Kegiatan not found" });
    }
    return res.status(200).json(kegiatan);
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Error fetching indikator kegiatan" });
  }
};

exports.create = async (req, res) => {
  try {
    const rows = Array.isArray(req.body) ? req.body : [req.body];

    const allowedFields = [
      "kegiatan_id",
      "kode_indikator",
      "nama_indikator",
      "jenis",
      "tolok_ukur_kinerja",
      "target_kinerja",
      "jenis_indikator",
      "kriteria_kuantitatif",
      "kriteria_kualitatif",
      "satuan",
      "definisi_operasional",
      "metode_penghitungan",
      "baseline",
      "target_tahun_1",
      "target_tahun_2",
      "target_tahun_3",
      "target_tahun_4",
      "target_tahun_5",
      "sumber_data",
      "penanggung_jawab",
      "keterangan",
    ];

    const sanitized = rows.map((r) => {
      const obj = Object.fromEntries(
        Object.entries(r).filter(([key]) => allowedFields.includes(key))
      );
      obj.tipe_indikator = "Proses";
      obj.jenisDokumen = r.jenisDokumen || defaultDokumen.jenisDokumen;
      obj.tahun = r.tahun || defaultDokumen.tahun;
      return obj;
    });

    const created = await IndikatorKegiatan.bulkCreate(sanitized);
    return res.status(201).json(created);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
};

exports.update = async (req, res) => {
  try {
    const kegiatan = await IndikatorKegiatan.findByPk(req.params.id);
    if (!kegiatan) {
      return res.status(404).json({ message: "Indikator Kegiatan not found" });
    }

    const updateData = {
      ...req.body,
      jenisDokumen: req.body.jenisDokumen || defaultDokumen.jenisDokumen,
      tahun: req.body.tahun || defaultDokumen.tahun,
    };

    await kegiatan.update(updateData);
    return res.status(200).json(kegiatan);
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Error updating indikator kegiatan" });
  }
};

exports.delete = async (req, res) => {
  try {
    const kegiatan = await IndikatorKegiatan.findByPk(req.params.id);
    if (!kegiatan) {
      return res.status(404).json({ message: "Indikator Kegiatan not found" });
    }
    await kegiatan.destroy();
    return res.status(204).json();
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Error deleting indikator kegiatan" });
  }
};
