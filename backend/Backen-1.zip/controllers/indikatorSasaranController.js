// controllers/indikatorSasaranController.js
const { IndikatorSasaran } = require("../models");

const defaultDokumen = {
  jenisDokumen: "RPJMD",
  tahun: "2025",
};

exports.create = async (req, res) => {
  try {
    const rows = Array.isArray(req.body) ? req.body : [req.body];

    if (!rows.every((r) => r.indikator_id)) {
      return res
        .status(400)
        .json({ message: "Semua data harus memiliki indikator_id" });
    }

    const withDokumen = rows.map((r) => ({
      ...r,
      jenisDokumen: r.jenisDokumen || defaultDokumen.jenisDokumen,
      tahun: r.tahun || defaultDokumen.tahun,
    }));

    const created = await IndikatorSasaran.bulkCreate(withDokumen);
    return res.status(201).json(created);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
};

exports.bulkCreateDetail = async (req, res) => {
  try {
    const { indikatorId } = req.params;
    const rows = req.body.rows;
    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ message: "rows harus array tidak kosong" });
    }

    const toInsert = rows.map((r, i) => {
      if (!indikatorId) {
        throw new Error(`indikator_id tidak tersedia untuk item ke-${i + 1}`);
      }
      return {
        ...r,
        indikator_id: indikatorId,
        jenisDokumen: r.jenisDokumen || defaultDokumen.jenisDokumen,
        tahun: r.tahun || defaultDokumen.tahun,
      };
    });

    const missingFields = toInsert.filter(
      (r) =>
        !r.nama_indikator ||
        !r.tipe_indikator ||
        !r.tolok_ukur_kinerja ||
        !r.target_kinerja
    );
    if (missingFields.length > 0) {
      return res.status(400).json({
        message:
          "Beberapa entri memiliki kolom wajib yang kosong. Pastikan 'nama_indikator', 'tipe_indikator', 'tolok_ukur_kinerja', dan 'target_kinerja' diisi.",
      });
    }

    const created = await IndikatorSasaran.bulkCreate(toInsert);
    return res.status(201).json(created);
  } catch (err) {
    console.error("Error bulkCreateDetail:", err);
    return res.status(500).json({
      message: "Terjadi kesalahan saat menyimpan data indikator sasaran.",
      error: err.message,
    });
  }
};

exports.findAll = async (req, res) => {
  try {
    const indikatorSasaran = await IndikatorSasaran.findAll({
      include: ["programs"],
    });
    return res.status(200).json(indikatorSasaran);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
};

exports.findOne = async (req, res) => {
  try {
    const indikatorSasaran = await IndikatorSasaran.findByPk(req.params.id, {
      include: ["programs"],
    });
    if (!indikatorSasaran) {
      return res.status(404).json({ message: "Indikator Sasaran not found" });
    }
    return res.status(200).json(indikatorSasaran);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
};

exports.update = async (req, res) => {
  try {
    const indikatorSasaran = await IndikatorSasaran.findByPk(req.params.id);
    if (!indikatorSasaran) {
      return res.status(404).json({ message: "Indikator Sasaran not found" });
    }

    const updateData = {
      ...req.body,
      jenisDokumen: req.body.jenisDokumen || defaultDokumen.jenisDokumen,
      tahun: req.body.tahun || defaultDokumen.tahun,
    };

    await indikatorSasaran.update(updateData);
    return res.status(200).json(indikatorSasaran);
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      message: "Terjadi kesalahan saat menyimpan data indikator sasaran.",
      error: err.message,
    });
  }
};

exports.delete = async (req, res) => {
  try {
    const indikatorSasaran = await IndikatorSasaran.findByPk(req.params.id);
    if (!indikatorSasaran) {
      return res.status(404).json({ message: "Indikator Sasaran not found" });
    }
    await indikatorSasaran.destroy();
    return res.status(204).json();
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
};
