// controllers/arahKebijakanController.js
const { ArahKebijakan, Strategi, Program } = require("../models");

module.exports = {
  // Create a new ArahKebijakan
  async create(req, res) {
    try {
      const {
        strategi_id,
        kode_arah,
        deskripsi,
        prioritas,
        jenisDokumen,
        tahun,
        periode_id,
      } = req.body;

      if (!periode_id) {
        return res.status(400).json({ message: "periode_id wajib diisi" });
      }

      const newArah = await ArahKebijakan.create({
        strategi_id,
        kode_arah,
        deskripsi,
        prioritas,
        jenisDokumen,
        tahun,
        periode_id,
      });
      return res.status(201).json(newArah);
    } catch (error) {
      return res.status(400).json({ error: error.message });
    }
  },

  // Get all ArahKebijakan
  async getAll(req, res) {
    try {
      const { jenisDokumen, tahun, periode_id } = req.query;
      const where = {};
      if (jenisDokumen) where.jenisDokumen = jenisDokumen;
      if (tahun) where.tahun = tahun;
      if (periode_id) where.periode_id = periode_id;

      const arahs = await ArahKebijakan.findAll({
        where,
        include: [
          {
            model: Strategi,
            as: "Strategi", // <<< sesuai belongsTo di model
            attributes: ["id", "kode_strategi", "deskripsi"],
          },
        ],
      });

      return res.json(arahs);
    } catch (error) {
      console.error("Error fetching arah-kebijakan:", error);
      return res.status(500).json({
        message: "Terjadi kesalahan saat mengambil data arah kebijakan.",
        error: error.message,
      });
    }
  },

  async byProgram(req, res) {
    const programId = req.params.programId;
    try {
      const list = await ArahKebijakan.findAll({
        include: [
          {
            model: Program,
            as: "Program",
            where: { id: programId },
            attributes: [],
          },
        ],
        group: ["ArahKebijakan.id"],
      });
      res.json(list);
    } catch (err) {
      res.status(500).json({ message: "Gagal memuat arah kebijakan." });
    }
  },

  // Get one ArahKebijakan by ID
  async getById(req, res) {
    try {
      const { id } = req.params;
      const arah = await ArahKebijakan.findByPk(id, {
        include: [{ model: Strategi, as: "Strategi" }],
      });
      if (!arah)
        return res.status(404).json({ error: "ArahKebijakan not found" });
      return res.json(arah);
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  },

  // Update an ArahKebijakan
  async update(req, res) {
    try {
      const { id } = req.params;
      const { strategi_id, kode_arah, deskripsi, prioritas, periode_id } =
        req.body;

      const [updated] = await ArahKebijakan.update(
        { strategi_id, kode_arah, deskripsi, prioritas, periode_id },
        { where: { id } }
      );

      if (!updated)
        return res.status(404).json({ error: "ArahKebijakan not found" });

      const updatedArah = await ArahKebijakan.findByPk(id);

      return res.json(updatedArah);
    } catch (error) {
      return res.status(400).json({ error: error.message });
    }
  },

  // Delete an ArahKebijakan
  async delete(req, res) {
    try {
      const { id } = req.params;
      const deleted = await ArahKebijakan.destroy({ where: { id } });
      if (!deleted)
        return res.status(404).json({ error: "ArahKebijakan not found" });
      return res.status(204).send();
    } catch (error) {
      return res.status(500).json({ error: error.message });
    }
  },
};
