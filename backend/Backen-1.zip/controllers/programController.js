const {
  Program,
  Sasaran,
  Strategi,
  ArahKebijakan,
  OpdPenanggungJawab,
} = require("../models");
const { Op } = require("sequelize");

module.exports = {
  async getPrograms(req, res) {
    try {
      const {
        page = 1,
        limit,
        search = "",
        sasaran_id,
        periode_id,
      } = req.query;

      const where = {};
      if (sasaran_id) where.sasaran_id = sasaran_id;
      if (periode_id) where.periode_id = periode_id;
      if (search) {
        where[Op.or] = [
          { nama_program: { [Op.like]: `%${search}%` } },
          { kode_program: { [Op.like]: `%${search}%` } },
        ];
      }

      const offset = (Number(page) - 1) * (Number(limit) || 20);

      const { rows, count } = await Program.findAndCountAll({
        where,
        include: [
          {
            model: Sasaran,
            as: "sasaran",
            attributes: ["nomor", "isi_sasaran"],
          },
          {
            model: Strategi,
            as: "Strategi",
            attributes: ["kode_strategi", "deskripsi"],
            through: { attributes: [] },
          },
          {
            model: ArahKebijakan,
            as: "ArahKebijakan",
            attributes: ["kode_arah", "deskripsi"],
            through: { attributes: [] },
          },
          { model: OpdPenanggungJawab, as: "penanggungJawabOpd" },
        ],
        order: [["createdAt", "DESC"]],
        limit: limit ? Number(limit) : 20,
        offset,
      });

      return res.json({
        data: rows,
        meta: {
          total: count,
          totalPages: limit ? Math.ceil(count / limit) : 1,
          currentPage: Number(page),
          pageSize: limit ? Number(limit) : 20,
        },
      });
    } catch (error) {
      console.error("Error fetching programs:", error);
      return res
        .status(500)
        .json({ message: "Error fetching programs", error });
    }
  },

  async getProgramById(req, res) {
    try {
      const program = await Program.findByPk(req.params.id, {
        include: [
          { model: Sasaran, as: "sasaran" },
          {
            model: Strategi,
            as: "Strategi",
            attributes: ["id", "kode_strategi", "deskripsi"],
            through: { attributes: [] },
          },
          {
            model: ArahKebijakan,
            as: "ArahKebijakan",
            attributes: ["id", "kode_arah", "deskripsi"],
            through: { attributes: [] },
          },
          { model: OpdPenanggungJawab, as: "penanggungJawabOpd" },
        ],
      });
      if (!program)
        return res.status(404).json({ message: "Program tidak ditemukan" });
      res.json({ data: program });
    } catch (error) {
      console.error("Error fetching program by id:", error);
      res.status(500).json({ message: "Error fetching program", error });
    }
  },

  async createProgram(req, res) {
    try {
      const {
        sasaran_id,
        nama_program,
        kode_program,
        rpjmd_id,
        prioritas,
        opd_penanggung_jawab,
        bidang_opd_penanggung_jawab,
        strategi_ids,
        arah_ids,
        periode_id,
      } = req.body;

      if (!periode_id) {
        return res.status(400).json({ message: "periode_id wajib diisi" });
      }

      const newProgram = await Program.create({
        sasaran_id,
        nama_program,
        kode_program,
        rpjmd_id,
        prioritas,
        opd_penanggung_jawab,
        bidang_opd_penanggung_jawab,
        periode_id,
      });

      if (Array.isArray(strategi_ids)) {
        await newProgram.setStrategi(strategi_ids);
      }
      if (Array.isArray(arah_ids)) {
        await newProgram.setArahKebijakan(arah_ids);
      }

      return res.status(201).json({ data: newProgram });
    } catch (error) {
      console.error("Error creating program:", error);
      return res.status(500).json({ message: "Gagal menambah program", error });
    }
  },

  async updateProgram(req, res) {
    try {
      const program = await Program.findByPk(req.params.id);
      if (!program)
        return res.status(404).json({ message: "Program tidak ditemukan" });

      const {
        sasaran_id,
        nama_program,
        kode_program,
        rpjmd_id,
        prioritas,
        opd_penanggung_jawab,
        bidang_opd_penanggung_jawab,
        strategi_ids,
        arah_ids,
        periode_id,
      } = req.body;

      if (!periode_id) {
        return res.status(400).json({ message: "periode_id wajib diisi" });
      }

      await program.update({
        sasaran_id,
        nama_program,
        kode_program,
        rpjmd_id,
        prioritas,
        opd_penanggung_jawab,
        bidang_opd_penanggung_jawab,
        periode_id,
      });

      if (Array.isArray(strategi_ids)) {
        await program.setStrategi(strategi_ids);
      }
      if (Array.isArray(arah_ids)) {
        await program.setArahKebijakan(arah_ids);
      }

      return res.json({ data: program });
    } catch (error) {
      console.error("Error updating program:", error);
      return res
        .status(500)
        .json({ message: "Gagal memperbarui program", error });
    }
  },

  async deleteProgram(req, res) {
    try {
      const program = await Program.findByPk(req.params.id);
      if (!program)
        return res.status(404).json({ message: "Program tidak ditemukan" });
      await program.destroy();
      return res.json({ message: "Program berhasil dihapus" });
    } catch (error) {
      console.error("Error deleting program:", error);
      return res
        .status(500)
        .json({ message: "Gagal menghapus program", error });
    }
  },
};
