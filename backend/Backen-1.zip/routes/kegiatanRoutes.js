// routes/kegiatanRoutes.js
const express = require("express");
const router = express.Router();
const kegiatanController = require("../controllers/kegiatanController");
const verifyToken = require("../middlewares/verifyToken");
const allowRoles = require("../middlewares/allowRoles"); // Import middleware allowRoles

// Routes untuk operasi CRUD kegiatan
router.post(
  "/",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  kegiatanController.createKegiatan
);
// Hanya SUPER_ADMIN dan ADMINISTRATOR yang bisa membuat kegiatan baru

router.get(
  "/",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  kegiatanController.getKegiatans
);

// Ambil satu kegiatan berdasarkan ID
router.get(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  kegiatanController.getKegiatanById
);

// Semua peran bisa melihat kegiatan berdasarkan ID
router.put(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  kegiatanController.updateKegiatan
);
// Hanya SUPER_ADMIN dan ADMINISTRATOR yang bisa memperbarui kegiatan

router.delete(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  kegiatanController.deleteKegiatan
);
// Hanya SUPER_ADMIN dan ADMINISTRATOR yang bisa menghapus kegiatan

// Endpoint hitung Kegiatan per Program
router.get(
  "/count-by-program",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  kegiatanController.countByProgram
);

module.exports = router;
