const express = require("express");
const router = express.Router();
const programController = require("../controllers/programController");
const verifyToken = require("../middlewares/verifyToken");
const allowRoles = require("../middlewares/allowRoles");

// Route untuk mengambil semua program dengan paginasi dan pencarian
router.get(
  "/programs",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  programController.getPrograms
);

// Route untuk mengambil semua program (alternatif tanpa 'programs')
router.get(
  "/",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  programController.getPrograms
);

// Route untuk mengambil program berdasarkan ID
router.get(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  programController.getProgramById
);

// Route untuk membuat program baru
router.post(
  "/",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  programController.createProgram
);

// Route untuk memperbarui program berdasarkan ID
router.put(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  programController.updateProgram
);

// Route untuk menghapus program berdasarkan ID
router.delete(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  programController.deleteProgram
);

module.exports = router;
