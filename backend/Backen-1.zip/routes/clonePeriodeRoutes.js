// routes/clonePeriodeRoutes.js
const express = require("express");
const router = express.Router();
const clonePeriodeController = require("../controllers/clonePeriodeController");
const verifyToken = require("../middlewares/verifyToken");
const allowRoles = require("../middlewares/allowRoles");

// POST /api/clone-periode
router.post(
  "/",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  clonePeriodeController.clone
);

module.exports = router;
