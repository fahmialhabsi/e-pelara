const express = require("express");
const router = express.Router();
const indikatorTujuanController = require("../controllers/indikatorTujuanController");
const verifyToken = require("../middlewares/verifyToken");
const allowRoles = require("../middlewares/allowRoles");

// List semua
router.get(
  "/",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  indikatorTujuanController.findAll
);

// List by query
router.get(
  "/by-tujuan",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  indikatorTujuanController.listByTujuan
);

// Next Kode
router.get(
  "/next-kode/:tujuanId",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  indikatorTujuanController.getNextKodeIndikator
);

// Get one by ID
router.get(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  indikatorTujuanController.findOne
);

// Create
router.post(
  "/",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  indikatorTujuanController.create
);

// Bulk detail
router.post(
  "/wizard/:indikatorId/detail",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  indikatorTujuanController.bulkCreateDetail
);

// Update
router.put(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  indikatorTujuanController.update
);

// Remove
router.delete(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  indikatorTujuanController.remove
);

module.exports = router;
