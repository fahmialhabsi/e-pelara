const express = require("express");
const router = express.Router();
const tujuanController = require("../controllers/tujuanController");
const verifyToken = require("../middlewares/verifyToken");
const allowRoles = require("../middlewares/allowRoles");

router.get(
  "/",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  async (req, res, next) => {
    try {
      if (req.query.misi_id) {
        // jika ada filter misi_id
        req.params.misi_id = req.query.misi_id;
        return await tujuanController.getTujuanByMisi(req, res, next);
      }

      if (req.query.periode_id) {
        // jika ada filter periode_id
        return await tujuanController.getByPeriode(req, res, next);
      }

      // tanpa filter, load semua
      return await tujuanController.getAllTujuan(req, res, next);
    } catch (err) {
      next(err);
    }
  }
);

router.get(
  "/by-periode",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  tujuanController.getByPeriode
);

router.get(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  tujuanController.getTujuanById
);

router.post(
  "/",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  tujuanController.createTujuan
);

router.put(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  tujuanController.updateTujuan
);

router.delete(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  tujuanController.deleteTujuan
);

router.get(
  "/misi/:misi_id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  tujuanController.getTujuanByMisi
);

module.exports = router;
