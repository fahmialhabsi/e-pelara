// routes/subKegiatanRoutes.js
const express = require("express");
const router = express.Router();
const subKegiatanController = require("../controllers/subKegiatanController");
const verifyToken = require("../middlewares/verifyToken");
const allowRoles = require("../middlewares/allowRoles");

// GET semua sub kegiatan (support filter seperti kegiatan_id, periode_id, dll)
router.get(
  "/",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  subKegiatanController.getAllSubKegiatan
);

// GET detail sub kegiatan berdasarkan ID
router.get(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  subKegiatanController.getSubKegiatanById
);

// GET kode sub kegiatan berikutnya berdasarkan kegiatan_id
router.get(
  "/next-kode/:kegiatan_id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  subKegiatanController.getNextKodeSubKegiatan
);

// POST buat sub kegiatan baru
router.post(
  "/",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  subKegiatanController.createSubKegiatan
);

// PUT perbarui sub kegiatan
router.put(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  subKegiatanController.updateSubKegiatan
);

// DELETE sub kegiatan
router.delete(
  "/:id",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR"]),
  subKegiatanController.deleteSubKegiatan
);

module.exports = router;
