// routes/periodeRoutes.js
const express = require("express");
const router = express.Router();
const { PeriodeRpjmd } = require("../models");
const { getActivePeriode } = require("../controllers/periodeController");
const verifyToken = require("../middlewares/verifyToken");
const allowRoles = require("../middlewares/allowRoles");

// GET /api/periode-rpjmd
router.get("/", verifyToken, allowRoles(["SUPER_ADMIN"]), async (req, res) => {
  try {
    const data = await PeriodeRpjmd.findAll({ order: [["tahun_awal", "ASC"]] });
    res.json(data);
  } catch (err) {
    console.error("Gagal ambil data periode:", err);
    res.status(500).json({ message: "Gagal mengambil data periode." });
  }
});

router.get(
  "/active",
  verifyToken,
  allowRoles(["SUPER_ADMIN", "ADMINISTRATOR", "PENGAWAS", "PELAKSANA"]),
  getActivePeriode
);

module.exports = router;
