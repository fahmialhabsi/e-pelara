import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import api from "../../../../services/api";
import { message } from "antd";

const schema = Yup.object().shape({
  rpjmd_id: Yup.number().required("RPJMD wajib dipilih"),
  kegiatan_rpjmd_id: Yup.number().required("Kegiatan RPJMD wajib dipilih"),
  no_kegiatan: Yup.string().required("Nomor Kegiatan wajib diisi"),
  isi_kegiatan: Yup.string().required("Isi Kegiatan wajib diisi"),
  renstra_id: Yup.number().required("Renstra ID tidak ditemukan"),
});

export const useKegiatanRenstraForm = (
  initialData = null,
  renstraAktif,
  onSuccess
) => {
  const queryClient = useQueryClient();
  const [kegiatanPreview, setKegiatanPreview] = useState("");

  const form = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      rpjmd_id: "",
      kegiatan_rpjmd_id: "",
      no_kegiatan: "",
      isi_kegiatan: "",
      renstra_id: renstraAktif?.id || "",
    },
  });

  const { setValue, watch } = form;

  useEffect(() => {
    if (initialData) {
      setValue("rpjmd_id", initialData.rpjmd_id);
      setValue("kegiatan_rpjmd_id", initialData.kegiatan_rpjmd_id);
      setValue("no_kegiatan", initialData.no_kegiatan);
      setValue("isi_kegiatan", initialData.isi_kegiatan);
      setValue("renstra_id", initialData.renstra_id);
    } else if (renstraAktif) {
      setValue("renstra_id", renstraAktif.id);
    }
  }, [initialData, renstraAktif, setValue]);

  const {
    data: rpjmdOptions,
    isLoading: isLoadingRpjmd,
    isError: isErrorRpjmd,
    error: errorRpjmd,
  } = useQuery({
    queryKey: ["rpjmd-list"],
    queryFn: async () => {
      const res = await api.get("/rpjmd");
      return res.data;
    },
    retry: 1,
  });

  const {
    data: kegiatanOptions,
    isLoading: isLoadingKegiatan,
    isError: isErrorKegiatan,
    error: errorKegiatan,
  } = useQuery({
    queryKey: ["kegiatan-rpjmd"],
    queryFn: async () => {
      const res = await api.get("/kegiatan");
      return res.data;
    },
    retry: 1,
  });

  const mutation = useMutation({
    mutationFn: async (formData) => {
      if (initialData?.id) {
        return await api.put(`/renstra-kegiatan/${initialData.id}`, formData);
      } else {
        return await api.post("/renstra-kegiatan", formData);
      }
    },
    onSuccess: () => {
      message.success("Kegiatan Renstra berhasil disimpan");
      queryClient.invalidateQueries({ queryKey: ["renstra-kegiatan"] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      message.error(error?.response?.data?.message || "Gagal menyimpan data");
    },
  });

  const onSubmit = (formData) => {
    const payload = {
      rpjmd_id: formData.rpjmd_id,
      rpjmd_kegiatan_id: formData.kegiatan_rpjmd_id,
      no_kegiatan: formData.no_kegiatan,
      isi_kegiatan: formData.isi_kegiatan,
      renstra_id: formData.renstra_id,
    };
    mutation.mutate(payload);
  };

  // Auto generate nomor kegiatan
  const kegiatanId = watch("kegiatan_rpjmd_id");
  useEffect(() => {
    if (kegiatanId && kegiatanOptions) {
      const selected = kegiatanOptions.find((t) => t.id === kegiatanId);
      if (selected) {
        setKegiatanPreview(selected.isi_kegiatan);
        const match = selected.no_kegiatan.match(/^T(\d+)-(\d{2})$/);
        if (match) {
          const autoNoKegiatan = `TR.${match[1]}-${match[2]}`;
          setValue("no_kegiatan", autoNoKegiatan);
        }
      }
    }
  }, [kegiatanId, kegiatanOptions, setValue]);

  return {
    form,
    rpjmdOptions,
    kegiatanOptions,
    onSubmit,
    kegiatanPreview,
    isLoading: isLoadingRpjmd || isLoadingKegiatan,
    isError: isErrorRpjmd || isErrorKegiatan,
    error: errorRpjmd || errorKegiatan,
    isSubmitting: mutation.isLoading,
  };
};
