import api from "../../../../services/api";

export const fetchKegiatanRenstra = () => api.get("/kegiatan-renstra");
export const fetchKegiatanRenstraById = (id) =>
  api.get(`/kegiatan-renstra/${id}`);
export const createKegiatanRenstra = (data) =>
  api.post("/kegiatan-renstra", data);
export const updateKegiatanRenstra = (id, data) =>
  api.put(`/kegiatan-renstra/${id}`, data);
export const deleteKegiatanRenstra = (id) =>
  api.delete(`/kegiatan-renstra/${id}`);
