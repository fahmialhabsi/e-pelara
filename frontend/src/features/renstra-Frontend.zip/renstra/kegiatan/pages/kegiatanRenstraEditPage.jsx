import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { fetchKegiatanRenstraById } from "../api/kegiatanRenstraApi";
import KegiatanRenstraForm from "../components/KegiatanRenstraForm";

const KegiatanRenstraEditPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const { data, isLoading } = useQuery(["kegiatan-renstra", id], async () => {
    const res = await fetchKegiatanRenstraById(id);
    return res.data;
  });

  if (isLoading) return <div>Loading...</div>;

  return (
    <KegiatanRenstraForm
      initialData={data}
      onSuccess={() => navigate("/kegiatan")}
    />
  );
};

export default KegiatanRenstraEditPage;
