import React from "react";
import { Table, Button, Popconfirm, message } from "antd";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  fetchKegiatanRenstra,
  deleteKegiatanRenstra,
} from "../api/kegiatanRenstraApi";
import { useNavigate } from "react-router-dom";

const KegiatanRenstraListPage = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data, isLoading } = useQuery(["kegiatan-renstra"], async () => {
    const res = await fetchKegiatanRenstra();
    return res.data;
  });

  const deleteMutation = useMutation(deleteKegiatanRenstra, {
    onSuccess: () => {
      message.success("Data berhasil dihapus");
      queryClient.invalidateQueries(["kegiatan-renstra"]);
    },
    onError: () => {
      message.error("Gagal menghapus data");
    },
  });

  const handleDelete = (id) => deleteMutation.mutate(id);

  const columns = [
    { title: "Kode Kegiatan", dataIndex: "kode_kegiatan", key: "kode" },
    { title: "Nama Kegiatan", dataIndex: "nama_kegiatan", key: "nama" },
    {
      title: "Aksi",
      render: (_, record) => (
        <>
          <Button
            type="link"
            onClick={() => navigate(`/kegiatan/edit/${record.id}`)}
          >
            Edit
          </Button>
          <Popconfirm
            title="Yakin hapus?"
            onConfirm={() => handleDelete(record.id)}
          >
            <Button type="link" danger>
              Hapus
            </Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        marginBottom: 16,
      }}
    >
      <Button onClick={() => navigate("/dashboard-renstra")}>
        🔙 Kembali ke Dashboard Renstra
      </Button>
      <Button type="primary" onClick={() => navigate("/kegiatan/add")}>
        ➕ Tambah Kegiatan
      </Button>
    </div>
  );
};

export default KegiatanRenstraListPage;
