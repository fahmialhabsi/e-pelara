import React from "react";
import {
  Form,
  Input,
  Button,
  Card,
  Select,
  Alert,
  Spin,
  Popconfirm,
  message,
} from "antd";
import { useNavigate } from "react-router-dom";
import { useKegiatanRenstraForm } from "../hooks/useKegiatanRenstraForm";

const { Option } = Select;

const KegiatanRenstraForm = ({ initialData = null, onSuccess, renstraAktif }) => {
  const navigate = useNavigate();
  const {
    form,
    rpjmdOptions,
    kegiatanOptions,
    onSubmit,
    kegiatanPreview,
    isLoading,
    isError,
    error,
    isSubmitting,
  } = useKegiatanRenstraForm(initialData, renstraAktif, onSuccess);

  const {
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = form;

  if (isLoading) {
    return <Spin tip="Memuat data..." size="large" fullscreen />;
  }

  if (isError) {
    return (
      <Alert
        type="error"
        message="Gagal memuat data referensi"
        description={error?.response?.data?.message || "Silakan coba lagi."}
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  return (
    <Card title={initialData ? "Edit Kegiatan Renstra" : "Tambah Kegiatan Renstra"}>
      {/* Navigasi Buttons */}
      <div style={{ marginBottom: 16, display: "flex", gap: 8 }}>
        <Button onClick={() => navigate("/dashboard-renstra")}>
          🔙 Kembali ke Dashboard Renstra
        </Button>
        <Button onClick={() => navigate("/renstra/kegiatan")}>
          📄 Lihat Daftar Kegiatan Renstra
        </Button>
      </div>

      {/* Form Start */}
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="RPJMD"
          validateStatus={errors.rpjmd_id ? "error" : ""}
          help={errors.rpjmd_id?.message}
        >
          <Select
            value={watch("rpjmd_id")}
            onChange={(val) => setValue("rpjmd_id", val)}
          >
            {rpjmdOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.nama_rpjmd}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Kegiatan RPJMD"
          validateStatus={errors.kegiatan_rpjmd_id ? "error" : ""}
          help={errors.kegiatan_rpjmd_id?.message}
        >
          <Select
            value={watch("kegiatan_rpjmd_id")}
            onChange={(val) => setValue("kegiatan_rpjmd_id", val)}
          >
            {kegiatanOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                [{item.no_kegiatan}] {item.isi_kegiatan.substring(0, 50)}...
              </Option>
            ))}
          </Select>
          {kegiatanPreview && (
            <div style={{ marginTop: 8, color: "#888" }}>{kegiatanPreview}</div>
          )}
        </Form.Item>

        <Form.Item
          label="Nomor Kegiatan"
          validateStatus={errors.no_kegiatan ? "error" : ""}
          help={errors.no_kegiatan?.message}
        >
          <Input value={watch("no_kegiatan")} disabled />
        </Form.Item>

        <Form.Item
          label="Isi Kegiatan"
          validateStatus={errors.isi_kegiatan ? "error" : ""}
          help={errors.isi_kegiatan?.message}
        >
          <Input.TextArea
            rows={4}
            value={watch("isi_kegiatan")}
            onChange={(e) => setValue("isi_kegiatan", e.target.value)}
          />
        </Form.Item>

        {/* Hidden field */}
        <Form.Item style={{ display: "none" }}>
          <Input value={watch("renstra_id")} />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={isSubmitting}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default KegiatanRenstraForm;
