import React, { useEffect, useState } from "react";
import { Form, Input, Button, Card, Select, message } from "antd";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm, useWatch } from "react-hook-form";
import api from "../../../../services/api";
import { generateKode } from "@/utils/kodeUtils";

const { Option } = Select;

const schema = Yup.object().shape({
  program_renstra_id: Yup.number().required("Program Renstra wajib dipilih"),
  kegiatan_rpjmd_id: Yup.number().required("Kegiatan RPJMD wajib dipilih"),
  no_kegiatan: Yup.string().required("Nomor Kegiatan wajib diisi"),
  isi_kegiatan: Yup.string().required("Isi Kegiatan wajib diisi"),
});

const KegiatanRenstraForm = ({ initialData = null, onSuccess }) => {
  const queryClient = useQueryClient();
  const [previewKegiatan, setPreviewKegiatan] = useState("");
  const [existingList, setExistingList] = useState([]);

  const {
    handleSubmit,
    setValue,
    watch,
    control,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      program_renstra_id: "",
      kegiatan_rpjmd_id: "",
      no_kegiatan: "",
      isi_kegiatan: "",
    },
  });

  const selectedKegiatanId = useWatch({ control, name: "kegiatan_rpjmd_id" });

  const { data: programRenstraOptions } = useQuery({
    queryKey: ["program-renstra"],
    queryFn: async () => {
      const res = await api.get("/program-renstra");
      return res.data;
    },
  });

  const { data: kegiatanRpjmdOptions } = useQuery({
    queryKey: ["kegiatan-rpjmd"],
    queryFn: async () => {
      const res = await api.get("/kegiatan-rpjmd");
      return res.data;
    },
  });

  useEffect(() => {
    const fetchExisting = async () => {
      const res = await api.get("/kegiatan-renstra");
      setExistingList(res.data);
    };
    fetchExisting();
  }, []);

  useEffect(() => {
    if (selectedKegiatanId && kegiatanRpjmdOptions) {
      const found = kegiatanRpjmdOptions.find(
        (k) => k.id === selectedKegiatanId
      );
      if (found) {
        setPreviewKegiatan(found.nama_kegiatan);
        const prefix = `KG${found.kode_kegiatan}`;
        const kode = generateKode({
          prefix,
          dataList: existingList,
          field: "no_kegiatan",
          padding: 2,
        });
        setValue("no_kegiatan", kode);
      }
    }
  }, [selectedKegiatanId, kegiatanRpjmdOptions, existingList, setValue]);

  const mutation = useMutation({
    mutationFn: async (formData) => {
      if (initialData?.id) {
        return await api.put(`/kegiatan-renstra/${initialData.id}`, formData);
      } else {
        return await api.post("/kegiatan-renstra", formData);
      }
    },
    onSuccess: () => {
      message.success("Kegiatan Renstra berhasil disimpan");
      queryClient.invalidateQueries({ queryKey: ["kegiatan-renstra"] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      message.error(error?.response?.data?.message || "Gagal menyimpan data");
    },
  });

  const onSubmit = (data) => mutation.mutate(data);

  return (
    <Card
      title={initialData ? "Edit Kegiatan Renstra" : "Tambah Kegiatan Renstra"}
    >
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="Program Renstra"
          validateStatus={errors.program_renstra_id ? "error" : ""}
          help={errors.program_renstra_id?.message}
        >
          <Select
            value={watch("program_renstra_id")}
            onChange={(value) => setValue("program_renstra_id", value)}
          >
            {programRenstraOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.no_program} - {item.isi_program.substring(0, 50)}...
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Kegiatan RPJMD"
          validateStatus={errors.kegiatan_rpjmd_id ? "error" : ""}
          help={errors.kegiatan_rpjmd_id?.message}
        >
          <Select
            value={watch("kegiatan_rpjmd_id")}
            onChange={(value) => setValue("kegiatan_rpjmd_id", value)}
          >
            {kegiatanRpjmdOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.kode_kegiatan} - {item.nama_kegiatan.substring(0, 50)}...
              </Option>
            ))}
          </Select>
          {previewKegiatan && (
            <div style={{ marginTop: 8, color: "#888" }}>{previewKegiatan}</div>
          )}
        </Form.Item>

        <Form.Item
          label="Nomor Kegiatan"
          validateStatus={errors.no_kegiatan ? "error" : ""}
          help={errors.no_kegiatan?.message}
        >
          <Input
            value={watch("no_kegiatan")}
            onChange={(e) => setValue("no_kegiatan", e.target.value)}
          />
        </Form.Item>

        <Form.Item
          label="Isi Kegiatan"
          validateStatus={errors.isi_kegiatan ? "error" : ""}
          help={errors.isi_kegiatan?.message}
        >
          <Input.TextArea
            rows={4}
            value={watch("isi_kegiatan")}
            onChange={(e) => setValue("isi_kegiatan", e.target.value)}
          />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={mutation.isLoading}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default KegiatanRenstraForm;
