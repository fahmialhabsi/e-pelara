import React, { useEffect, useState } from "react";
import { Form, Input, Button, Card, Select, message } from "antd";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm, useWatch } from "react-hook-form";
import api from "../../../../services/api";
import { generateKode } from "@/utils/kodeUtils";

const { Option } = Select;

const schema = Yup.object().shape({
  kebijakan_renstra_id: Yup.number().required(
    "Kebijakan Renstra wajib dipilih"
  ),
  program_rpjmd_id: Yup.number().required("Program RPJMD wajib dipilih"),
  no_program: Yup.string().required("Nomor Program wajib diisi"),
  isi_program: Yup.string().required("Isi Program wajib diisi"),
});

const ProgramRenstraForm = ({ initialData = null, onSuccess }) => {
  const queryClient = useQueryClient();
  const [previewProgram, setPreviewProgram] = useState("");
  const [existingList, setExistingList] = useState([]);

  const {
    handleSubmit,
    setValue,
    watch,
    control,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      kebijakan_renstra_id: "",
      program_rpjmd_id: "",
      no_program: "",
      isi_program: "",
    },
  });

  useEffect(() => {
    if (initialData) {
      setValue("kebijakan_renstra_id", initialData.kebijakan_renstra_id);
      setValue("program_rpjmd_id", initialData.program_rpjmd_id);
      setValue("no_program", initialData.no_program);
      setValue("isi_program", initialData.isi_program);
    }
  }, [initialData, setValue]);

  const { data: kebijakanRenstraOptions } = useQuery({
    queryKey: ["kebijakan-renstra"],
    queryFn: async () => {
      const res = await api.get("/kebijakan-renstra");
      return res.data;
    },
  });

  const { data: programRpjmdOptions } = useQuery({
    queryKey: ["program-rpjmd"],
    queryFn: async () => {
      const res = await api.get("/program-rpjmd");
      return res.data;
    },
  });

  useEffect(() => {
    const fetchExisting = async () => {
      const res = await api.get("/program-renstra");
      setExistingList(res.data);
    };
    fetchExisting();
  }, []);

  const selectedProgramId = useWatch({ control, name: "program_rpjmd_id" });

  useEffect(() => {
    if (selectedProgramId && programRpjmdOptions) {
      const found = programRpjmdOptions.find((p) => p.id === selectedProgramId);
      if (found) {
        setPreviewProgram(found.nama_program);

        const prefix = `PR${found.kode_program}`;
        const kode = generateKode({
          prefix,
          dataList: existingList,
          field: "no_program",
          padding: 2,
        });

        setValue("no_program", kode);
      }
    }
  }, [selectedProgramId, programRpjmdOptions, existingList, setValue]);

  const mutation = useMutation({
    mutationFn: async (formData) => {
      if (initialData?.id) {
        return await api.put(`/program-renstra/${initialData.id}`, formData);
      } else {
        return await api.post("/program-renstra", formData);
      }
    },
    onSuccess: () => {
      message.success("Program Renstra berhasil disimpan");
      queryClient.invalidateQueries({ queryKey: ["program-renstra"] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      message.error(error?.response?.data?.message || "Gagal menyimpan data");
    },
  });

  const onSubmit = (data) => mutation.mutate(data);

  return (
    <Card
      title={initialData ? "Edit Program Renstra" : "Tambah Program Renstra"}
    >
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="Kebijakan Renstra"
          validateStatus={errors.kebijakan_renstra_id ? "error" : ""}
          help={errors.kebijakan_renstra_id?.message}
        >
          <Select
            value={watch("kebijakan_renstra_id")}
            onChange={(value) => setValue("kebijakan_renstra_id", value)}
          >
            {kebijakanRenstraOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.no_kebijakan} - {item.isi_kebijakan.substring(0, 50)}...
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Program RPJMD"
          validateStatus={errors.program_rpjmd_id ? "error" : ""}
          help={errors.program_rpjmd_id?.message}
        >
          <Select
            value={watch("program_rpjmd_id")}
            onChange={(value) => setValue("program_rpjmd_id", value)}
          >
            {programRpjmdOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.kode_program} - {item.nama_program.substring(0, 50)}...
              </Option>
            ))}
          </Select>
          {previewProgram && (
            <div style={{ marginTop: 8, color: "#888" }}>{previewProgram}</div>
          )}
        </Form.Item>

        <Form.Item label="Nomor Program">
          <div
            style={{
              padding: "8px 12px",
              background: "#f5f5f5",
              borderRadius: 4,
            }}
          >
            {watch("no_program") || "-"}
          </div>
        </Form.Item>

        <Form.Item
          label="Isi Program"
          validateStatus={errors.isi_program ? "error" : ""}
          help={errors.isi_program?.message}
        >
          <Input.TextArea
            rows={4}
            value={watch("isi_program")}
            onChange={(e) => setValue("isi_program", e.target.value)}
          />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={mutation.isLoading}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default ProgramRenstraForm;
