import React from "react";
import {
  Form,
  Input,
  Button,
  Card,
  Select,
  Alert,
  Spin,
  Popconfirm,
  message,
} from "antd";
import { useNavigate } from "react-router-dom";
import { useProgramRenstraForm } from "../hooks/useProgramRenstraForm";

const { Option } = Select;

const ProgramRenstraForm = ({ initialData = null, onSuccess, renstraAktif }) => {
  const navigate = useNavigate();
  const {
    form,
    rpjmdOptions,
    programOptions,
    onSubmit,
    programPreview,
    isLoading,
    isError,
    error,
    isSubmitting,
  } = useProgramRenstraForm(initialData, renstraAktif, onSuccess);

  const {
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = form;

  if (isLoading) {
    return <Spin tip="Memuat data..." size="large" fullscreen />;
  }

  if (isError) {
    return (
      <Alert
        type="error"
        message="Gagal memuat data referensi"
        description={error?.response?.data?.message || "Silakan coba lagi."}
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  return (
    <Card title={initialData ? "Edit Program Renstra" : "Tambah Program Renstra"}>
      {/* Navigasi Buttons */}
      <div style={{ marginBottom: 16, display: "flex", gap: 8 }}>
        <Button onClick={() => navigate("/dashboard-renstra")}>
          🔙 Kembali ke Dashboard Renstra
        </Button>
        <Button onClick={() => navigate("/renstra/program")}>
          📄 Lihat Daftar Program Renstra
        </Button>
      </div>

      {/* Form Start */}
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="RPJMD"
          validateStatus={errors.rpjmd_id ? "error" : ""}
          help={errors.rpjmd_id?.message}
        >
          <Select
            value={watch("rpjmd_id")}
            onChange={(val) => setValue("rpjmd_id", val)}
          >
            {rpjmdOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.nama_rpjmd}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Program RPJMD"
          validateStatus={errors.program_rpjmd_id ? "error" : ""}
          help={errors.program_rpjmd_id?.message}
        >
          <Select
            value={watch("program_rpjmd_id")}
            onChange={(val) => setValue("program_rpjmd_id", val)}
          >
            {programOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                [{item.no_program}] {item.isi_program.substring(0, 50)}...
              </Option>
            ))}
          </Select>
          {programPreview && (
            <div style={{ marginTop: 8, color: "#888" }}>{programPreview}</div>
          )}
        </Form.Item>

        <Form.Item
          label="Nomor Program"
          validateStatus={errors.no_program ? "error" : ""}
          help={errors.no_program?.message}
        >
          <Input value={watch("no_program")} disabled />
        </Form.Item>

        <Form.Item
          label="Isi Program"
          validateStatus={errors.isi_program ? "error" : ""}
          help={errors.isi_program?.message}
        >
          <Input.TextArea
            rows={4}
            value={watch("isi_program")}
            onChange={(e) => setValue("isi_program", e.target.value)}
          />
        </Form.Item>

        {/* Hidden field */}
        <Form.Item style={{ display: "none" }}>
          <Input value={watch("renstra_id")} />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={isSubmitting}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default ProgramRenstraForm;
