import api from "../../../../services/api";

export const fetchProgramRenstra = () => api.get("/program-renstra");
export const fetchProgramRenstraById = (id) =>
  api.get(`/program-renstra/${id}`);
export const createProgramRenstra = (data) =>
  api.post("/program-renstra", data);
export const updateProgramRenstra = (id, data) =>
  api.put(`/program-renstra/${id}`, data);
export const deleteProgramRenstra = (id) =>
  api.delete(`/program-renstra/${id}`);
