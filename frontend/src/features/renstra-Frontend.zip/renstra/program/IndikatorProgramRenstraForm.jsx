import React, { useEffect } from "react";
import { Form, Input, Button, Card, Select, message } from "antd";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import axios from "axios";

const { Option } = Select;

const schema = Yup.object().shape({
  program_renstra_id: Yup.number().required("Program Renstra wajib dipilih"),
  kode_indikator: Yup.string().required("Kode indikator wajib diisi"),
  nama_indikator: Yup.string().required("Nama indikator wajib diisi"),
  satuan: Yup.string().required("Satuan wajib diisi"),
  target_tahun_1: Yup.string().required("Target tahun 1 wajib diisi"),
});

const IndikatorProgramRenstraForm = ({ initialData = null, onSuccess }) => {
  const queryClient = useQueryClient();

  const {
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      program_renstra_id: "",
      kode_indikator: "",
      nama_indikator: "",
      satuan: "",
      target_tahun_1: "",
    },
  });

  useEffect(() => {
    if (initialData) {
      setValue("program_renstra_id", initialData.program_renstra_id);
      setValue("kode_indikator", initialData.kode_indikator);
      setValue("nama_indikator", initialData.nama_indikator);
      setValue("satuan", initialData.satuan);
      setValue("target_tahun_1", initialData.target_tahun_1);
    }
  }, [initialData, setValue]);

  const { data: programRenstraOptions } = useQuery(
    ["program-renstra"],
    async () => {
      const res = await axios.get("/api/program-renstra");
      return res.data;
    }
  );

  const mutation = useMutation(
    async (formData) => {
      if (initialData?.id) {
        return await axios.put(
          `/api/indikator-program-renstra/${initialData.id}`,
          formData
        );
      } else {
        return await axios.post("/api/indikator-program-renstra", formData);
      }
    },
    {
      onSuccess: () => {
        message.success("Indikator Program Renstra berhasil disimpan");
        queryClient.invalidateQueries(["indikator-program-renstra"]);
        if (onSuccess) onSuccess();
      },
      onError: (error) => {
        message.error(error?.response?.data?.message || "Gagal menyimpan data");
      },
    }
  );

  const onSubmit = (data) => mutation.mutate(data);

  return (
    <Card
      title={
        initialData
          ? "Edit Indikator Program Renstra"
          : "Tambah Indikator Program Renstra"
      }
    >
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="Program Renstra"
          validateStatus={errors.program_renstra_id ? "error" : ""}
          help={errors.program_renstra_id?.message}
        >
          <Select
            value={watch("program_renstra_id")}
            onChange={(value) => setValue("program_renstra_id", value)}
          >
            {programRenstraOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.kode_program} - {item.nama_program}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Kode Indikator"
          validateStatus={errors.kode_indikator ? "error" : ""}
          help={errors.kode_indikator?.message}
        >
          <Input
            value={watch("kode_indikator")}
            onChange={(e) => setValue("kode_indikator", e.target.value)}
          />
        </Form.Item>

        <Form.Item
          label="Nama Indikator"
          validateStatus={errors.nama_indikator ? "error" : ""}
          help={errors.nama_indikator?.message}
        >
          <Input.TextArea
            rows={3}
            value={watch("nama_indikator")}
            onChange={(e) => setValue("nama_indikator", e.target.value)}
          />
        </Form.Item>

        <Form.Item
          label="Satuan"
          validateStatus={errors.satuan ? "error" : ""}
          help={errors.satuan?.message}
        >
          <Input
            value={watch("satuan")}
            onChange={(e) => setValue("satuan", e.target.value)}
          />
        </Form.Item>

        <Form.Item
          label="Target Tahun 1"
          validateStatus={errors.target_tahun_1 ? "error" : ""}
          help={errors.target_tahun_1?.message}
        >
          <Input
            value={watch("target_tahun_1")}
            onChange={(e) => setValue("target_tahun_1", e.target.value)}
          />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={mutation.isLoading}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default IndikatorProgramRenstraForm;
