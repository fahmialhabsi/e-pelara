import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { fetchProgramRenstraById } from "../api/programRenstraApi";
import ProgramRenstraForm from "../components/ProgramRenstraForm";

const ProgramRenstraEditPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const { data, isLoading } = useQuery(["program-renstra", id], async () => {
    const res = await fetchProgramRenstraById(id);
    return res.data;
  });

  if (isLoading) return <div>Loading...</div>;

  return (
    <ProgramRenstraForm
      initialData={data}
      onSuccess={() => navigate("/program")}
    />
  );
};

export default ProgramRenstraEditPage;
