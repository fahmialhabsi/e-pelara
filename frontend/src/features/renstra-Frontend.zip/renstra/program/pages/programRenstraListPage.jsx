import React from "react";
import { Table, Button, Popconfirm, message } from "antd";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  fetchProgramRenstra,
  deleteProgramRenstra,
} from "../api/programRenstraApi";
import { useNavigate } from "react-router-dom";

const ProgramRenstraListPage = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data, isLoading } = useQuery(["program-renstra"], async () => {
    const res = await fetchProgramRenstra();
    return res.data;
  });

  const deleteMutation = useMutation(deleteProgramRenstra, {
    onSuccess: () => {
      message.success("Data berhasil dihapus");
      queryClient.invalidateQueries(["program-renstra"]);
    },
    onError: () => {
      message.error("Gagal menghapus data");
    },
  });

  const handleDelete = (id) => deleteMutation.mutate(id);

  const columns = [
    { title: "Kode Program", dataIndex: "kode_program", key: "kode" },
    { title: "Nama Program", dataIndex: "nama_program", key: "nama" },
    {
      title: "Aksi",
      render: (_, record) => (
        <>
          <Button
            type="link"
            onClick={() => navigate(`/program/edit/${record.id}`)}
          >
            Edit
          </Button>
          <Popconfirm
            title="Yakin hapus?"
            onConfirm={() => handleDelete(record.id)}
          >
            <Button type="link" danger>
              Hapus
            </Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        marginBottom: 16,
      }}
    >
      <Button onClick={() => navigate("/dashboard-renstra")}>
        🔙 Kembali ke Dashboard Renstra
      </Button>
      <Button type="primary" onClick={() => navigate("/program/add")}>
        ➕ Tambah Program
      </Button>
    </div>
  );
};

export default ProgramRenstraListPage;
