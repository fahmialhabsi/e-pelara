import React from "react";
import ProgramRenstraForm from "../components/ProgramRenstraForm";
import { useNavigate } from "react-router-dom";

const ProgramRenstraAddPage = () => {
  const navigate = useNavigate();
  return <ProgramRenstraForm onSuccess={() => navigate("/program")} />;
};

export default ProgramRenstraAddPage;
