import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { fetchProgramRenstraById } from "../api/programRenstraApi";
import ProgramRenstraForm from "../components/ProgramRenstraForm";
import { Spin, Alert, Empty } from "antd";

const ProgramRenstraEditPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["renstra-program", id],
    queryFn: async () => {
      const res = await fetchProgramRenstraById(id);
      return res.data;
    },
    retry: 1, // retry sekali jika gagal
    onError: (err) => {
      console.error("Gagal mengambil data:", err);
    },
  });

  if (isLoading) {
    return <Spin tip="Memuat data program renstra..." size="large" fullscreen />;
  }

  if (isError) {
    return (
      <Alert
        message="Gagal memuat data"
        description={
          error?.response?.data?.message || "Terjadi kesalahan server."
        }
        type="error"
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  if (!data) {
    return (
      <Empty description="Data tidak ditemukan" style={{ marginTop: 48 }} />
    );
  }

  return (
    <ProgramRenstraForm
      initialData={data}
      onSuccess={() => navigate("/renstra/program")}
    />
  );
};

export default ProgramRenstraEditPage;
