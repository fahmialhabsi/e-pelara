import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import api from "../../../../services/api";
import { message } from "antd";

const schema = Yup.object().shape({
  rpjmd_id: Yup.number().required("RPJMD wajib dipilih"),
  program_rpjmd_id: Yup.number().required("Program RPJMD wajib dipilih"),
  no_program: Yup.string().required("Nomor Program wajib diisi"),
  isi_program: Yup.string().required("Isi Program wajib diisi"),
  renstra_id: Yup.number().required("Renstra ID tidak ditemukan"),
});

export const useProgramRenstraForm = (
  initialData = null,
  renstraAktif,
  onSuccess
) => {
  const queryClient = useQueryClient();
  const [programPreview, setProgramPreview] = useState("");

  const form = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      rpjmd_id: "",
      program_rpjmd_id: "",
      no_program: "",
      isi_program: "",
      renstra_id: renstraAktif?.id || "",
    },
  });

  const { setValue, watch } = form;

  useEffect(() => {
    if (initialData) {
      setValue("rpjmd_id", initialData.rpjmd_id);
      setValue("program_rpjmd_id", initialData.program_rpjmd_id);
      setValue("no_program", initialData.no_program);
      setValue("isi_program", initialData.isi_program);
      setValue("renstra_id", initialData.renstra_id);
    } else if (renstraAktif) {
      setValue("renstra_id", renstraAktif.id);
    }
  }, [initialData, renstraAktif, setValue]);

  const {
    data: rpjmdOptions,
    isLoading: isLoadingRpjmd,
    isError: isErrorRpjmd,
    error: errorRpjmd,
  } = useQuery({
    queryKey: ["rpjmd-list"],
    queryFn: async () => {
      const res = await api.get("/rpjmd");
      return res.data;
    },
    retry: 1,
  });

  const {
    data: programOptions,
    isLoading: isLoadingProgram,
    isError: isErrorProgram,
    error: errorProgram,
  } = useQuery({
    queryKey: ["program-rpjmd"],
    queryFn: async () => {
      const res = await api.get("/program");
      return res.data;
    },
    retry: 1,
  });

  const mutation = useMutation({
    mutationFn: async (formData) => {
      if (initialData?.id) {
        return await api.put(`/renstra-program/${initialData.id}`, formData);
      } else {
        return await api.post("/renstra-program", formData);
      }
    },
    onSuccess: () => {
      message.success("Program Renstra berhasil disimpan");
      queryClient.invalidateQueries({ queryKey: ["renstra-program"] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      message.error(error?.response?.data?.message || "Gagal menyimpan data");
    },
  });

  const onSubmit = (formData) => {
    const payload = {
      rpjmd_id: formData.rpjmd_id,
      rpjmd_program_id: formData.program_rpjmd_id,
      no_program: formData.no_program,
      isi_program: formData.isi_program,
      renstra_id: formData.renstra_id,
    };
    mutation.mutate(payload);
  };

  // Auto generate nomor program
  const programId = watch("program_rpjmd_id");
  useEffect(() => {
    if (programId && programOptions) {
      const selected = programOptions.find((t) => t.id === programId);
      if (selected) {
        setProgramPreview(selected.isi_program);
        const match = selected.no_program.match(/^T(\d+)-(\d{2})$/);
        if (match) {
          const autoNoProgram = `TR.${match[1]}-${match[2]}`;
          setValue("no_program", autoNoProgram);
        }
      }
    }
  }, [programId, programOptions, setValue]);

  return {
    form,
    rpjmdOptions,
    programOptions,
    onSubmit,
    programPreview,
    isLoading: isLoadingRpjmd || isLoadingProgram,
    isError: isErrorRpjmd || isErrorProgram,
    error: errorRpjmd || errorProgram,
    isSubmitting: mutation.isLoading,
  };
};
