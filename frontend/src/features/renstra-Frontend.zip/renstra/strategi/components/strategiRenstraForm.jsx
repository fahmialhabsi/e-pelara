import React from "react";
import { Form, Input, Button, Card, Select, Alert, Spin } from "antd";
import { useNavigate } from "react-router-dom";
import { useWatch } from "react-hook-form";
import { useStrategiRenstraForm } from "../hooks/useStrategiRenstraForm";

const { Option } = Select;

const StrategiRenstraForm = ({ initialData = null, renstraAktif }) => {
  const navigate = useNavigate();

  const {
    form,
    rpjmdOptions,
    strategiOptions,
    onSubmit,
    strategiPreview,
    isLoading,
    isError,
    error,
    isSubmitting,
  } = useStrategiRenstraForm(initialData, renstraAktif, () =>
    navigate("/renstra/strategi")
  );

  const {
    handleSubmit,
    setValue,
    watch,
    control,
    formState: { errors },
  } = form;

  const strategiId = useWatch({ control, name: "strategi_rpjmd_id" });
  const noStrategi = useWatch({ control, name: "no_strategi" });

  if (isLoading) return <Spin tip="Memuat data..." size="large" fullscreen />;
  if (isError)
    return (
      <Alert
        type="error"
        message="Gagal memuat data"
        description={error?.message}
        showIcon
        style={{ margin: 24 }}
      />
    );

  return (
    <Card
      title={initialData ? "Edit Strategi Renstra" : "Tambah Strategi Renstra"}
    >
      <div style={{ marginBottom: 16, display: "flex", gap: 8 }}>
        <Button onClick={() => navigate("/dashboard-renstra")}>
          🔙 Kembali ke Dashboard Renstra
        </Button>
        <Button onClick={() => navigate("/renstra/strategi")}>
          📄 Lihat Daftar Strateg Renstra
        </Button>
      </div>

      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="RPJMD"
          validateStatus={errors.rpjmd_id ? "error" : ""}
          help={errors.rpjmd_id?.message}
        >
          <Select
            value={watch("rpjmd_id")}
            onChange={(val) => setValue("rpjmd_id", val)}
            placeholder="Pilih RPJMD"
          >
            {rpjmdOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.nama_rpjmd}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Strategi RPJMD"
          validateStatus={errors.strategi_rpjmd_id ? "error" : ""}
          help={errors.strategi_rpjmd_id?.message}
        >
          <Select
            value={watch("strategi_rpjmd_id")}
            onChange={(val) => setValue("strategi_rpjmd_id", val)}
            placeholder="Pilih Strategi RPJMD"
          >
            {strategiOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.no_strategi} - {item.isi_strategi.substring(0, 50)}...
              </Option>
            ))}
          </Select>
          {strategiPreview && (
            <div style={{ marginTop: 8, color: "#888" }}>{strategiPreview}</div>
          )}
        </Form.Item>

        <Form.Item label="Nomor Strategi">
          <div
            style={{
              padding: "8px 12px",
              background: "#f5f5f5",
              borderRadius: 4,
            }}
          >
            {noStrategi || "-"}
          </div>
        </Form.Item>

        <Form.Item
          label="Isi Strategi"
          validateStatus={errors.isi_strategi ? "error" : ""}
          help={errors.isi_strategi?.message}
        >
          <Input.TextArea
            rows={4}
            value={watch("isi_strategi")}
            onChange={(e) => setValue("isi_strategi", e.target.value)}
          />
        </Form.Item>

        <input type="hidden" name="no_strategi" value={noStrategi || ""} />
        <input
          type="hidden"
          name="renstra_id"
          value={watch("renstra_id") || ""}
        />

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={isSubmitting}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default StrategiRenstraForm;
