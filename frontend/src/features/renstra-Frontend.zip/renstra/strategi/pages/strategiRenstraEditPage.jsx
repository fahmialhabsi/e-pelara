import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { fetchStrategiRenstraById } from "../api/strategiRenstraApi";
import StrategiRenstraForm from "../components/StrategiRenstraForm";
import { Spin, Alert, Empty } from "antd";

const StrategiRenstraEditPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["strategi-renstra", id],
    queryFn: async () => {
      const res = await fetchStrategiRenstraById(id);
      return res.data;
    },
    retry: 1,
    onError: (err) => {
      console.error("Gagal mengambil data:", err);
    },
  });

  if (isLoading) {
    return (
      <Spin tip="Memuat data strategi renstra..." size="large" fullscreen />
    );
  }

  if (isError) {
    return (
      <Alert
        message="Gagal memuat data"
        description={
          error?.response?.data?.message || "Terjadi kesalahan server."
        }
        type="error"
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  if (!data) {
    return (
      <Empty description="Data tidak ditemukan" style={{ marginTop: 48 }} />
    );
  }

  return (
    <StrategiRenstraForm
      initialData={data}
      onSuccess={() => navigate("/strategi")}
    />
  );
};

export default StrategiRenstraEditPage;
