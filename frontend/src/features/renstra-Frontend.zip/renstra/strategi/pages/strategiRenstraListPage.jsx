import React from "react";
import { Table, Button, Popconfirm, message, Spin, Alert, Empty } from "antd";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  fetchStrategiRenstra,
  deleteStrategiRenstra,
} from "../api/strategiRenstraApi";
import { useNavigate } from "react-router-dom";

const StrategiRenstraListPage = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["strategi-renstra"],
    queryFn: async () => {
      const res = await fetchStrategiRenstra();
      console.log("DATA STRATEGI RENSTRA:", res.data);
      return res.data;
    },
    retry: 1,
    onError: (err) => console.error("Fetch error:", err),
  });

  const deleteMutation = useMutation({
    mutationFn: deleteStrategiRenstra,
    onSuccess: () => {
      message.success("Data berhasil dihapus");
      queryClient.invalidateQueries({ queryKey: ["strategi-renstra"] });
    },
    onError: () => {
      message.error("Gagal menghapus data");
    },
  });

  const handleDelete = (id) => deleteMutation.mutate(id);

  const columns = [
    {
      title: "Kode Strategi",
      dataIndex: "kode_strategi",
      key: "kode_strategi",
      render: (text) => text || "-",
    },
    {
      title: "Isi Strategi",
      dataIndex: "deskripsi", // sesuaikan dengan field DB
      key: "deskripsi",
    },
    {
      title: "Aksi",
      key: "aksi",
      render: (_, record) => (
        <>
          <Button
            type="link"
            onClick={() => navigate(`/renstra/strategi/edit/${record.id}`)}
          >
            Edit
          </Button>
          <Popconfirm
            title="Yakin hapus?"
            onConfirm={() => handleDelete(record.id)}
          >
            <Button type="link" danger>
              Hapus
            </Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  if (isLoading) {
    return (
      <Spin tip="Memuat data strategi renstra..." size="large" fullscreen />
    );
  }

  if (isError) {
    return (
      <Alert
        message="Gagal memuat data"
        description={
          error?.response?.data?.message ||
          "Terjadi kesalahan saat mengambil data."
        }
        type="error"
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  if (!data || data.length === 0) {
    return (
      <div style={{ padding: 24 }}>
        <Empty description="Belum ada data Strategi Renstra" />
        <Button
          type="primary"
          onClick={() => navigate("/strategi/add")}
          style={{ marginTop: 16 }}
        >
          Tambah Strategi
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginBottom: 16,
        }}
      >
        <Button onClick={() => navigate("/dashboard-renstra")}>
          🔙 Kembali ke Dashboard Renstra
        </Button>
        <Button type="primary" onClick={() => navigate("/strategi/add")}>
          ➕ Tambah Strategi
        </Button>
      </div>

      <Table columns={columns} dataSource={data} rowKey="id" bordered />
    </div>
  );
};

export default StrategiRenstraListPage;
