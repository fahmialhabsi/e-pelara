import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import api from "../../../../services/api";
import { message } from "antd";

const schema = Yup.object().shape({
  rpjmd_id: Yup.number().required("RPJMD wajib dipilih"),
  strategi_rpjmd_id: Yup.number().required("Strategi RPJMD wajib dipilih"),
  no_strategi: Yup.string().required("Nomor Strategi wajib diisi"),
  isi_strategi: Yup.string().required("Isi Strategi wajib diisi"),
  renstra_id: Yup.number().required("Renstra ID tidak ditemukan"),
});

export const useStrategiRenstraForm = (
  initialData = null,
  renstraAktif,
  onSuccess
) => {
  const queryClient = useQueryClient();

  const form = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      rpjmd_id: "",
      strategi_rpjmd_id: "",
      no_strategi: "",
      isi_strategi: "",
      renstra_id: renstraAktif?.id || "",
    },
  });

  const { setValue, watch } = form;

  useEffect(() => {
    if (initialData) {
      setValue("rpjmd_id", initialData.renstra?.rpjmd_id || "");
      setValue("strategi_rpjmd_id", initialData.strategi_rpjmd_id);
      setValue("no_strategi", initialData.no_strategi);
      setValue("isi_strategi", initialData.isi_strategi);
      setValue("renstra_id", initialData.renstra_id);
    } else if (renstraAktif) {
      setValue("renstra_id", renstraAktif.id);
      setValue("rpjmd_id", renstraAktif.rpjmd_id || "");
    }
  }, [initialData, renstraAktif, setValue]);

  const rpjmdOptionsQuery = useQuery({
    queryKey: ["rpjmd-list"],
    queryFn: async () => (await api.get("/rpjmd")).data,
  });

  const strategiOptionsQuery = useQuery({
    queryKey: ["strategi-rpjmd"],
    queryFn: async () => (await api.get("/strategi")).data,
  });

  const mutation = useMutation({
    mutationFn: async (formData) => {
      if (initialData?.id) {
        return await api.put(`/renstra-strategi/${initialData.id}`, formData);
      } else {
        return await api.post("/renstra-strategi", formData);
      }
    },
    onSuccess: () => {
      message.success("Strategi Renstra berhasil disimpan");
      queryClient.invalidateQueries({ queryKey: ["renstra-strategi"] });
      if (onSuccess) onSuccess(); // 🔁 Redirect dilakukan di luar
    },
    onError: (error) => {
      message.error(error?.response?.data?.message || "Gagal menyimpan data");
    },
  });

  const onSubmit = (formData) => {
    const payload = {
      rpjmd_id: formData.rpjmd_id,
      rpjmd_strategi_id: formData.strategi_rpjmd_id,
      no_strategi: formData.no_strategi,
      isi_strategi: formData.isi_strategi,
      renstra_id: formData.renstra_id,
    };
    mutation.mutate(payload);
  };

  const strategiId = watch("strategi_rpjmd_id");
  const strategiOptions = strategiOptionsQuery.data;

  useEffect(() => {
    if (strategiId && strategiOptions) {
      const selected = strategiOptions.find((s) => s.id === strategiId);
      if (selected) {
        const match = selected.no_strategi?.match(/^T(\d+)-(\d{2})$/);
        if (match) {
          const autoNo = `TR.${match[1]}-${match[2]}`;
          setValue("no_strategi", autoNo);
        }
      }
    }
  }, [strategiId, strategiOptions, setValue]);

  const selectedPreview = strategiOptions?.find((s) => s.id === strategiId);

  return {
    form,
    rpjmdOptions: rpjmdOptionsQuery.data,
    strategiOptions,
    onSubmit,
    strategiPreview: selectedPreview?.isi_strategi || "",
    isLoading: rpjmdOptionsQuery.isLoading || strategiOptionsQuery.isLoading,
    isError: rpjmdOptionsQuery.isError || strategiOptionsQuery.isError,
    error: rpjmdOptionsQuery.error || strategiOptionsQuery.error,
    isSubmitting: mutation.isLoading,
  };
};
