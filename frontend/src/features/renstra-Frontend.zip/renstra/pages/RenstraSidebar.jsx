import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Card, Accordion } from "react-bootstrap";

const babList = [
  { nomor: "I", title: "Pendahuluan" },
  { nomor: "II", title: "Gambaran Umum Dinas Pangan" },
  { nomor: "III", title: "Permasalahan & Isu Strategis" },
  { nomor: "IV", title: "Tujuan & Sasaran" },
  { nomor: "V", title: "Strategi & Kebijakan" },
  { nomor: "VI", title: "Program & Kegiatan" },
  { nomor: "VII", title: "Indikator Kinerja" },
  { nomor: "VIII", title: "Penutup" },
];

const inputActions = [
  { label: "Tujuan", to: "/renstra/tujuan/add", className: "btn-primary" },
  { label: "Sasaran", to: "/renstra/sasaran/add", className: "btn-info" },
  { label: "Strategi", to: "/renstra/strategi/add", className: "btn-warning" },
  { label: "Kebijakan", to: "/renstra/kebijakan/add", className: "btn-danger" },
  { label: "Program", to: "/renstra/program/add", className: "btn-secondary" },
  { label: "Kegiatan", to: "/renstra/kegiatan/add", className: "btn-dark" },
  {
    label: "Sub Kegiatan",
    to: "/renstra/subkegiatan/add",
    className: "btn-outline-secondary",
  },
  {
    label: "Indikator",
    to: "/renstra/indikator-umum/add",
    className: "btn-outline-primary",
  },
];

const bidangList = [
  "Sekretariat",
  "Bidang Ketersediaan dan Kerawanan Pangan",
  "Bidang Distribusi dan Cadangan Pangan",
  "Bidang Konsumsi dan Keamanan Pangan",
  "Balai Pengawasan Mutu Pangan",
];

const STORAGE_KEY = "renstraAccordionOpen";

const RenstraSidebar = () => {
  const [activeKeys, setActiveKeys] = useState(["0"]);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) setActiveKeys(parsed);
      } catch {
        // jika parsing gagal, abaikan
      }
    }
  }, []);

  const handleToggle = (key) => {
    let updatedKeys;
    if (activeKeys.includes(key)) {
      updatedKeys = activeKeys.filter((k) => k !== key);
    } else {
      updatedKeys = [...activeKeys, key];
    }
    setActiveKeys(updatedKeys);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedKeys));
  };

  return (
    <aside className="sticky-sidebar">
      <Card className="mb-4 shadow-sm border-0">
        <Card.Body>
          <Accordion activeKey={activeKeys} alwaysOpen flush>
            <Accordion.Item eventKey="0">
              <Accordion.Header onClick={() => handleToggle("0")}>
                BAB RENSTRA
              </Accordion.Header>
              <Accordion.Body>
                <ul className="mb-0 ps-3">
                  {babList.map((bab) => (
                    <li key={bab.nomor}>
                      <Link to={`/renstra/${bab.nomor}`}>
                        {bab.nomor}. {bab.title}
                      </Link>
                    </li>
                  ))}
                </ul>
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="1">
              <Accordion.Header onClick={() => handleToggle("1")}>
                Aksi Input Data Renstra
              </Accordion.Header>
              <Accordion.Body>
                <div className="d-flex flex-wrap gap-2">
                  {inputActions.map((act, idx) => (
                    <Link
                      key={idx}
                      to={act.to}
                      className={`btn btn-sm ${act.className}`}
                    >
                      {act.label}
                    </Link>
                  ))}
                </div>
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="2">
              <Accordion.Header onClick={() => handleToggle("2")}>
                Manajemen Renstra OPD
              </Accordion.Header>
              <Accordion.Body>
                <div className="d-flex flex-column gap-2">
                  <Link
                    to="/renstra-opd"
                    className="btn btn-outline-primary btn-sm"
                  >
                    📋 Lihat Daftar Renstra OPD
                  </Link>
                  <Link
                    to="/renstra-opd/new"
                    className="btn btn-outline-success btn-sm"
                  >
                    ➕ Tambah Renstra OPD
                  </Link>
                </div>
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item eventKey="3">
              <Accordion.Header onClick={() => handleToggle("3")}>
                Bidang Dinas Pangan
              </Accordion.Header>
              <Accordion.Body>
                <ul className="list-unstyled mb-0">
                  {bidangList.map((bidang, idx) => (
                    <li key={idx} className="mb-2">
                      <Link
                        to={`/renstra/bidang/${encodeURIComponent(bidang)}`}
                        className="text-decoration-none"
                      >
                        {bidang}
                      </Link>
                    </li>
                  ))}
                </ul>
              </Accordion.Body>
            </Accordion.Item>
          </Accordion>
        </Card.Body>
      </Card>
    </aside>
  );
};

export default RenstraSidebar;
