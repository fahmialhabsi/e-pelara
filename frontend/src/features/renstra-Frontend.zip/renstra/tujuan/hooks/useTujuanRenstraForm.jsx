import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import api from "../../../../services/api";
import { message } from "antd";

// Validasi schema
const schema = Yup.object().shape({
  rpjmd_id: Yup.number().required("RPJMD wajib dipilih"),
  tujuan_rpjmd_id: Yup.number().required("Tujuan RPJMD wajib dipilih"),
  no_tujuan: Yup.string().required("Nomor Tujuan wajib diisi"),
  isi_tujuan: Yup.string().required("Isi Tujuan wajib diisi"),
  renstra_id: Yup.number().required("Renstra ID tidak ditemukan"),
});

export const useTujuanRenstraForm = (
  initialData = null,
  renstraAktif,
  onSuccess
) => {
  const queryClient = useQueryClient();
  const [tujuanPreview, setTujuanPreview] = useState("");

  const form = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      rpjmd_id: undefined,
      tujuan_rpjmd_id: undefined,
      no_tujuan: "",
      isi_tujuan: "",
      renstra_id: renstraAktif?.id || "",
    },
  });

  const { setValue, watch } = form;
  const tujuanId = watch("tujuan_rpjmd_id");

  // Fetch data
  const rpjmdQuery = useQuery({
    queryKey: ["rpjmd-list"],
    queryFn: async () => (await api.get("/rpjmd")).data,
    retry: 1,
  });

  const tujuanQuery = useQuery({
    queryKey: ["tujuan-rpjmd"],
    queryFn: async () => (await api.get("/tujuan")).data,
    retry: 1,
  });

  // Set default values saat edit
  useEffect(() => {
    if (!initialData || !rpjmdQuery.data || !tujuanQuery.data) return;

    const rpjmdId = Number(initialData.renstra?.rpjmd_id || "");
    const tujuanId = Number(initialData.rpjmd_tujuan_id || "");

    setValue("rpjmd_id", rpjmdId);
    setValue("tujuan_rpjmd_id", tujuanId);
    setValue("no_tujuan", initialData.no_tujuan || "");
    setValue("isi_tujuan", initialData.isi_tujuan || "");
    setValue("renstra_id", initialData.renstra_id || "");
  }, [initialData, rpjmdQuery.data, tujuanQuery.data, setValue]);

  // Set default saat tambah baru
  useEffect(() => {
    if (!initialData && renstraAktif) {
      setValue("renstra_id", renstraAktif.id);
      setValue("rpjmd_id", renstraAktif.rpjmd_id || undefined);
    }
  }, [initialData, renstraAktif, setValue]);

  // Auto generate nomor tujuan dari Tujuan RPJMD
  useEffect(() => {
    if (!tujuanId || !tujuanQuery.data) return;

    const selected = tujuanQuery.data.find((item) => item.id === tujuanId);
    if (!selected) return;

    setTujuanPreview(selected.isi_tujuan);

    const match = selected.no_tujuan.match(
      /^T(\d+)-(\d{2})(?:-(\d{2}))?(?:\.(\d{2}))?$/
    );
    if (match) {
      const bagian1 = match[1]; // 3
      const bagian2 = match[2]; // 01
      const bagian3 = match[3] || "01";
      const bagian4 = match[4] || "01";
      const formatted = `TR${bagian1}-${bagian2}-${bagian3}.${bagian4}`;
      setValue("no_tujuan", formatted);
    } else {
      setValue("no_tujuan", "TRX-XX-XX.XX");
    }
  }, [tujuanId, tujuanQuery.data, setValue]);

  // Handle submit
  const mutation = useMutation({
    mutationFn: async (formData) => {
      return initialData?.id
        ? await api.put(`/renstra-tujuan/${initialData.id}`, formData)
        : await api.post("/renstra-tujuan", formData);
    },
    onSuccess: () => {
      message.success("Tujuan Renstra berhasil disimpan");
      queryClient.invalidateQueries({ queryKey: ["renstra-tujuan"] });
      if (onSuccess) onSuccess();
    },
    onError: (err) => {
      message.error(err?.response?.data?.message || "Gagal menyimpan data");
    },
  });

  const onSubmit = (formData) => {
    const payload = {
      rpjmd_id: formData.rpjmd_id,
      rpjmd_tujuan_id: formData.tujuan_rpjmd_id,
      no_tujuan: formData.no_tujuan,
      isi_tujuan: formData.isi_tujuan,
      renstra_id: formData.renstra_id,
    };
    mutation.mutate(payload);
  };

  return {
    form,
    rpjmdOptions: rpjmdQuery.data,
    tujuanOptions: tujuanQuery.data,
    onSubmit,
    tujuanPreview,
    isLoading: rpjmdQuery.isLoading || tujuanQuery.isLoading,
    isError: rpjmdQuery.isError || tujuanQuery.isError,
    error: rpjmdQuery.error || tujuanQuery.error,
    isSubmitting: mutation.isLoading,
  };
};
