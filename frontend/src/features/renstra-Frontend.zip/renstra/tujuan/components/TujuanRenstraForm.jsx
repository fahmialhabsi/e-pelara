import React from "react";
import { Form, Input, Button, Card, Select, Alert, Spin } from "antd";
import { useNavigate } from "react-router-dom";
import { useTujuanRenstraForm } from "../hooks/useTujuanRenstraForm";

const { Option } = Select;

const TujuanRenstraForm = ({ initialData = null, onSuccess, renstraAktif }) => {
  const navigate = useNavigate();
  const {
    form,
    rpjmdOptions,
    tujuanOptions,
    onSubmit,
    tujuanPreview,
    isLoading,
    isError,
    error,
    isSubmitting,
  } = useTujuanRenstraForm(initialData, renstraAktif, onSuccess);

  const {
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = form;

  if (isLoading) {
    return <Spin tip="Memuat data..." size="large" fullscreen />;
  }

  if (isError) {
    return (
      <Alert
        type="error"
        message="Gagal memuat data referensi"
        description={error?.response?.data?.message || "Silakan coba lagi."}
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  return (
    <Card title={initialData ? "Edit Tujuan Renstra" : "Tambah Tujuan Renstra"}>
      {/* Navigasi Buttons */}
      <div style={{ marginBottom: 16, display: "flex", gap: 8 }}>
        <Button onClick={() => navigate("/dashboard-renstra")}>
          🔙 Kembali ke Dashboard Renstra
        </Button>
        <Button onClick={() => navigate("/renstra/tujuan")}>
          📄 Lihat Daftar Tujuan Renstra
        </Button>
      </div>

      {/* Form Start */}
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="RPJMD"
          validateStatus={errors.rpjmd_id ? "error" : ""}
          help={errors.rpjmd_id?.message}
        >
          <Select
            value={watch("rpjmd_id") || undefined}
            onChange={(val) => setValue("rpjmd_id", val)}
            placeholder="Pilih RPJMD"
            loading={!rpjmdOptions}
          >
            {rpjmdOptions?.map((item) => (
              <Option key={item.id} value={Number(item.id)}>
                {" "}
                {/* <<< UBAH DI SINI */}
                {item.nama_rpjmd}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Tujuan RPJMD"
          validateStatus={errors.tujuan_rpjmd_id ? "error" : ""}
          help={errors.tujuan_rpjmd_id?.message}
        >
          <Select
            value={watch("tujuan_rpjmd_id") || undefined}
            onChange={(val) => setValue("tujuan_rpjmd_id", val)}
            placeholder="Pilih Tujuan RPJMD"
            loading={!tujuanOptions}
          >
            {tujuanOptions?.map((item) => (
              <Option key={item.id} value={Number(item.id)}>
                {" "}
                {/* <<< UBAH DI SINI */}[{item.no_tujuan}]{" "}
                {item.isi_tujuan.substring(0, 50)}...
              </Option>
            ))}
          </Select>
          {tujuanPreview && (
            <div style={{ marginTop: 8, color: "#888" }}>{tujuanPreview}</div>
          )}
        </Form.Item>

        <Form.Item
          label="Nomor Tujuan"
          validateStatus={errors.no_tujuan ? "error" : ""}
          help={errors.no_tujuan?.message}
        >
          <Input value={watch("no_tujuan") || ""} disabled />
        </Form.Item>

        <Form.Item
          label="Isi Tujuan"
          validateStatus={errors.isi_tujuan ? "error" : ""}
          help={errors.isi_tujuan?.message}
        >
          <Input.TextArea
            rows={4}
            value={watch("isi_tujuan") || ""}
            onChange={(e) => setValue("isi_tujuan", e.target.value)}
          />
        </Form.Item>

        {/* Hidden field */}
        <Form.Item style={{ display: "none" }}>
          <Input value={watch("renstra_id") || ""} />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={isSubmitting}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default TujuanRenstraForm;
