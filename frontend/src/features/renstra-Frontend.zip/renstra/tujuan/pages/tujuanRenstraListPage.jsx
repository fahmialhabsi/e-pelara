import React from "react";
import { Table, Button, Popconfirm, message, Spin, Alert, Empty } from "antd";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  fetchTujuanRenstra,
  deleteTujuanRenstra,
} from "../api/tujuanRenstraApi";
import { useNavigate } from "react-router-dom";

const TujuanRenstraListPage = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["renstra-tujuan"],
    queryFn: async () => {
      const res = await fetchTujuanRenstra();
      return res.data;
    },
    retry: 1,
    onError: (err) => console.error("Fetch error:", err),
  });

  const deleteMutation = useMutation({
    mutationFn: deleteTujuanRenstra,
    onSuccess: () => {
      message.success("Data berhasil dihapus");
      queryClient.invalidateQueries({ queryKey: ["renstra-tujuan"] });
    },
    onError: () => {
      message.error("Gagal menghapus data");
    },
  });

  const handleDelete = (id) => deleteMutation.mutate(id);

  const columns = [
    { title: "No", dataIndex: "no_tujuan", key: "no" },
    { title: "Isi Tujuan", dataIndex: "isi_tujuan", key: "isi" },
    {
      title: "Aksi",
      render: (_, record) => (
        <>
          <Button
            type="link"
            onClick={() => navigate(`/renstra/tujuan/edit/${record.id}`)}
          >
            Edit
          </Button>
          <Popconfirm
            title="Yakin hapus?"
            onConfirm={() => handleDelete(record.id)}
          >
            <Button type="link" danger>
              Hapus
            </Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  if (isLoading) {
    return (
      <Spin tip="Memuat daftar tujuan renstra..." size="large" fullscreen />
    );
  }

  if (isError) {
    return (
      <Alert
        message="Gagal memuat data"
        description={
          error?.response?.data?.message ||
          "Terjadi kesalahan saat mengambil data."
        }
        type="error"
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  if (!data || data.length === 0) {
    return (
      <div style={{ padding: 24 }}>
        <Empty description="Belum ada data Tujuan Renstra" />
        <Button
          type="primary"
          onClick={() => navigate("/renstra/tujuan/add")}
          style={{ marginTop: 16 }}
        >
          ➕ Tambah Tujuan
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginBottom: 16,
        }}
      >
        <Button onClick={() => navigate("/dashboard-renstra")}>
          🔙 Kembali ke Dashboard Renstra
        </Button>
        <Button type="primary" onClick={() => navigate("/renstra/tujuan/add")}>
          ➕ Tambah Tujuan
        </Button>
      </div>

      <Table columns={columns} dataSource={data} rowKey="id" bordered />
    </div>
  );
};

export default TujuanRenstraListPage;
