import React, { useEffect, useState } from "react";
import { Form, Input, Button, Card, Select, Alert, Spin } from "antd";
import { useNavigate } from "react-router-dom";
import { useSasaranRenstraForm } from "../hooks/useSasaranRenstraForm";
import { useWatch } from "react-hook-form";
import api from "../../../../services/api";

const { Option } = Select;

const SasaranRenstraForm = ({
  initialData = null,
  onSuccess,
  renstraAktif,
}) => {
  const navigate = useNavigate();
  const [sasaranPreview, setSasaranPreview] = useState("");
  const [existingRenstraSasaranList, setExistingRenstraSasaranList] = useState(
    []
  );

  const {
    form,
    rpjmdOptions,
    sasaranOptions,
    tujuanOptions,
    onSubmit,
    isLoading,
    isError,
    error,
    isSubmitting,
  } = useSasaranRenstraForm(initialData, renstraAktif, onSuccess);

  const {
    handleSubmit,
    watch,
    setValue,
    control,
    formState: { errors },
  } = form;

  const selectedSasaranId = useWatch({ control, name: "sasaran_rpjmd_id" });
  const noSasaran = useWatch({ control, name: "no_sasaran" });
  const noRpjmd = useWatch({ control, name: "no_rpjmd" });
  const isiRpjmd = useWatch({ control, name: "isi_sasaran_rpjmd" });

  useEffect(() => {
    const fetchExisting = async () => {
      if (!renstraAktif?.id) return;
      try {
        const res = await api.get("/renstra-sasaran", {
          params: { renstra_id: renstraAktif.id },
        });
        setExistingRenstraSasaranList(res.data);
      } catch (err) {
        console.error("Gagal mengambil daftar sasaran renstra:", err);
      }
    };
    fetchExisting();
  }, [renstraAktif]);

  useEffect(() => {
    if (selectedSasaranId && sasaranOptions?.length) {
      const selected = sasaranOptions.find(
        (item) => item.id === selectedSasaranId
      );
      if (selected) {
        const match = selected.nomor?.match(/(\d+-\d+-\d+)/);
        const baseNumber = match ? match[1] : "XX-XX-XX";
        const baseCode = `SR${baseNumber}`;
        const sameGroupCount = existingRenstraSasaranList.filter((item) =>
          item.nomor?.startsWith(baseCode)
        ).length;
        const nextIndex = sameGroupCount + 1;
        const paddedIndex = String(nextIndex).padStart(2, "0");
        const formattedNoSasaran = `${baseCode}.${paddedIndex}`;

        setValue("no_sasaran", formattedNoSasaran);
        setValue("no_rpjmd", selected.nomor || "");
        setValue("isi_sasaran_rpjmd", selected.isi_sasaran || "");
        setSasaranPreview(selected.isi_sasaran || "");
      } else {
        setValue("no_sasaran", "");
        setValue("no_rpjmd", "");
        setValue("isi_sasaran_rpjmd", "");
        setSasaranPreview("");
      }
    }
  }, [selectedSasaranId, sasaranOptions, existingRenstraSasaranList, setValue]);

  if (isLoading) return <Spin tip="Memuat data..." size="large" fullscreen />;
  if (isError)
    return (
      <Alert
        type="error"
        message="Gagal memuat data"
        description={error?.message}
        showIcon
        style={{ margin: 24 }}
      />
    );

  return (
    <Card
      title={initialData ? "Edit Sasaran Renstra" : "Tambah Sasaran Renstra"}
    >
      <div style={{ marginBottom: 16, display: "flex", gap: 8 }}>
        <Button onClick={() => navigate("/dashboard-renstra")}>
          🔙 Kembali ke Dashboard Renstra
        </Button>
        <Button onClick={() => navigate("/renstra/sasaran")}>
          📄 Lihat Daftar Sasaran Renstra
        </Button>
      </div>

      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="RPJMD"
          validateStatus={errors.rpjmd_id ? "error" : ""}
          help={errors.rpjmd_id?.message}
        >
          <Select
            value={watch("rpjmd_id")}
            onChange={(val) => setValue("rpjmd_id", val)}
            placeholder="Pilih RPJMD"
          >
            {rpjmdOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.nama_rpjmd}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Tujuan"
          validateStatus={errors.tujuan_id ? "error" : ""}
          help={errors.tujuan_id?.message}
        >
          <Select
            value={watch("tujuan_id")}
            onChange={(val) => setValue("tujuan_id", val)}
            placeholder="Pilih Tujuan"
          >
            {tujuanOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.no_tujuan}. {item.isi_tujuan}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Sasaran RPJMD"
          validateStatus={errors.sasaran_rpjmd_id ? "error" : ""}
          help={errors.sasaran_rpjmd_id?.message}
        >
          <Select
            value={selectedSasaranId}
            onChange={(val) => setValue("sasaran_rpjmd_id", val)}
            placeholder="Pilih Sasaran RPJMD"
            showSearch
          >
            {sasaranOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.nomor}. {item.isi_sasaran}
              </Option>
            ))}
          </Select>
          {sasaranPreview && (
            <div style={{ marginTop: 8, color: "#888" }}>{sasaranPreview}</div>
          )}
        </Form.Item>

        <Form.Item label="Nomor Sasaran">
          <div
            style={{
              padding: "8px 12px",
              background: "#f5f5f5",
              borderRadius: 4,
            }}
          >
            {noSasaran || "-"}
          </div>
        </Form.Item>

        <Form.Item
          label="Isi Sasaran"
          validateStatus={errors.isi_sasaran ? "error" : ""}
          help={errors.isi_sasaran?.message}
        >
          <Input.TextArea
            rows={4}
            value={watch("isi_sasaran")}
            onChange={(e) => setValue("isi_sasaran", e.target.value)}
          />
        </Form.Item>

        {/* Hidden fields */}
        <input type="hidden" name="no_sasaran" value={noSasaran || ""} />
        <input
          type="hidden"
          name="renstra_id"
          value={watch("renstra_id") || ""}
        />

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={isSubmitting}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default SasaranRenstraForm;
