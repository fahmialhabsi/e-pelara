import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import api from "../../../../services/api";
import { message } from "antd";

const schema = Yup.object().shape({
  rpjmd_id: Yup.number().required("RPJMD wajib dipilih"),
  sasaran_rpjmd_id: Yup.number().required("Sasaran RPJMD wajib dipilih"),
  tujuan_id: Yup.number().required("Tujuan wajib dipilih"),
  no_sasaran: Yup.string().required("Nomor Sasaran wajib diisi"),
  isi_sasaran: Yup.string().required("Isi Sasaran wajib diisi"),
  renstra_id: Yup.number().required("Renstra ID tidak ditemukan"),
});

export const useSasaranRenstraForm = (
  initialData = null,
  renstraAktif,
  onSuccess
) => {
  const queryClient = useQueryClient();

  const form = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      rpjmd_id: "",
      sasaran_rpjmd_id: "",
      no_sasaran: "",
      isi_sasaran: "",
      tujuan_id: "",
      renstra_id: renstraAktif?.id || "",
      no_rpjmd: "",
      isi_sasaran_rpjmd: "",
    },
  });

  const { setValue, watch } = form;

  useEffect(() => {
    if (initialData) {
      // Ambil rpjmd_id dari relasi "renstra"
      setValue("rpjmd_id", initialData.renstra?.rpjmd_id || "");

      setValue("sasaran_rpjmd_id", initialData.rpjmd_sasaran_id);
      setValue("no_sasaran", initialData.no_sasaran);
      setValue("isi_sasaran", initialData.isi_sasaran);
      setValue("renstra_id", initialData.renstra_id);
      setValue("tujuan_id", initialData.tujuan_id);
      setValue("no_rpjmd", initialData.no_rpjmd || "");
      setValue("isi_sasaran_rpjmd", initialData.isi_sasaran_rpjmd || "");
    } else if (renstraAktif) {
      setValue("renstra_id", renstraAktif.id);
      setValue("rpjmd_id", renstraAktif.rpjmd_id || "");
    }
  }, [initialData, renstraAktif, setValue]);

  const rpjmdOptions = useQuery({
    queryKey: ["rpjmd-list"],
    queryFn: async () => (await api.get("/rpjmd")).data,
  });

  const sasaranOptions = useQuery({
    queryKey: ["sasaran-rpjmd"],
    queryFn: async () => (await api.get("/sasaran")).data,
  });

  const tujuanOptionsQuery = useQuery({
    queryKey: ["tujuan-rpjmd"],
    queryFn: async () => (await api.get("/tujuan")).data,
  });

  const mutation = useMutation({
    mutationFn: async (formData) => {
      if (initialData?.id) {
        return await api.put(`/renstra-sasaran/${initialData.id}`, formData);
      } else {
        return await api.post("/renstra-sasaran", formData);
      }
    },
    onSuccess: () => {
      message.success("Sasaran Renstra berhasil disimpan");
      queryClient.invalidateQueries({ queryKey: ["renstra-sasaran"] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      message.error(error?.response?.data?.message || "Gagal menyimpan data");
    },
  });

  const onSubmit = (formData) => {
    const payload = {
      rpjmd_id: formData.rpjmd_id,
      rpjmd_sasaran_id: formData.sasaran_rpjmd_id,
      tujuan_id: formData.tujuan_id,
      no_sasaran: formData.no_sasaran,
      nomor: formData.no_sasaran, // untuk field `nomor` di DB
      isi_sasaran: formData.isi_sasaran,
      renstra_id: formData.renstra_id,
      no_rpjmd: formData.no_rpjmd || null,
      isi_sasaran_rpjmd: formData.isi_sasaran_rpjmd || null,
    };
    mutation.mutate(payload);
  };

  return {
    form,
    rpjmdOptions: rpjmdOptions.data,
    sasaranOptions: sasaranOptions.data,
    tujuanOptions: tujuanOptionsQuery.data,
    onSubmit,
    isLoading:
      rpjmdOptions.isLoading ||
      sasaranOptions.isLoading ||
      tujuanOptionsQuery.isLoading,
    isError:
      rpjmdOptions.isError ||
      sasaranOptions.isError ||
      tujuanOptionsQuery.isError,
    error:
      rpjmdOptions.error || sasaranOptions.error || tujuanOptionsQuery.error,
    isSubmitting: mutation.isLoading,
  };
};
