import React from "react";
import SasaranRenstraForm from "../components/SasaranRenstraForm";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import api from "../../../../services/api";
import { Spin, Alert } from "antd";

const SasaranRenstraAddPage = () => {
  const navigate = useNavigate();

  const {
    data: renstraAktif,
    isLoading,
    isError,
    error,
  } = useQuery({
    queryKey: ["renstra-opd-aktif"],
    queryFn: async () => {
      const res = await api.get("/renstra-opd");
      return res.data.find((item) => item.is_aktif === true) || null;
    },
    retry: 1,
    onError: (err) => {
      console.error("Gagal fetch Renstra OPD aktif:", err);
    },
  });

  if (isLoading) {
    return <Spin tip="Memuat data Renstra aktif..." size="large" fullscreen />;
  }

  if (isError) {
    return (
      <Alert
        type="error"
        message="Gagal memuat data Renstra OPD"
        description={
          error?.response?.data?.message ||
          "Terjadi kesalahan saat memuat data Renstra aktif."
        }
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  if (!renstraAktif) {
    return (
      <Alert
        type="warning"
        message="Tidak ada RENSTRA OPD yang aktif"
        description="Silakan aktifkan satu Renstra OPD terlebih dahulu sebelum menambah Sasaran Renstra."
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  return (
    <SasaranRenstraForm
      onSuccess={() => navigate("/renstra/sasaran")}
      renstraAktif={renstraAktif}
    />
  );
};

export default SasaranRenstraAddPage;
