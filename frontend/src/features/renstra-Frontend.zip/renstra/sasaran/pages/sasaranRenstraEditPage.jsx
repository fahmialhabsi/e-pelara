import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { fetchSasaranRenstraById } from "../api/sasaranRenstraApi";
import SasaranRenstraForm from "../components/SasaranRenstraForm";
import { Spin, Alert, Empty } from "antd";

const SasaranRenstraEditPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["renstra-sasaran", id],
    queryFn: async () => {
      const res = await fetchSasaranRenstraById(id);
      return res.data;
    },
    retry: 1, // retry sekali jika gagal
    onError: (err) => {
      console.error("Gagal mengambil data:", err);
    },
  });

  if (isLoading) {
    return <Spin tip="Memuat data sasaran renstra..." size="large" fullscreen />;
  }

  if (isError) {
    return (
      <Alert
        message="Gagal memuat data"
        description={
          error?.response?.data?.message || "Terjadi kesalahan server."
        }
        type="error"
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  if (!data) {
    return (
      <Empty description="Data tidak ditemukan" style={{ marginTop: 48 }} />
    );
  }

  return (
    <SasaranRenstraForm
      initialData={data}
      onSuccess={() => navigate("/renstra/sasaran")}
    />
  );
};

export default SasaranRenstraEditPage;
