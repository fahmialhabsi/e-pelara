import React from "react";
import { Table, Button, Popconfirm, message, Spin, Alert, Empty } from "antd";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  fetchSasaranRenstra,
  deleteSasaranRenstra,
} from "../api/sasaranRenstraApi";
import { useNavigate } from "react-router-dom";

const SasaranRenstraListPage = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["renstra-sasaran"],
    queryFn: async () => {
      const res = await fetchSasaranRenstra();
      return res.data;
    },
    retry: 1,
    onError: (err) => console.error("Fetch error:", err),
  });

  const deleteMutation = useMutation({
    mutationFn: deleteSasaranRenstra,
    onSuccess: () => {
      message.success("Data berhasil dihapus");
      queryClient.invalidateQueries({ queryKey: ["renstra-sasaran"] });
    },
    onError: () => {
      message.error("Gagal menghapus data");
    },
  });

  const handleDelete = (id) => deleteMutation.mutate(id);

  const columns = [
    {
      title: "No",
      dataIndex: "nomor", // SESUAI dengan field di database
      key: "nomor",
      render: (text) => text || "-", // tampilkan "-" jika kosong
    },
    {
      title: "Isi Sasaran",
      dataIndex: "isi_sasaran",
      key: "isi_sasaran",
    },
    {
      title: "Aksi",
      key: "aksi",
      render: (_, record) => (
        <>
          <Button
            type="link"
            onClick={() => navigate(`/renstra/sasaran/edit/${record.id}`)}
          >
            Edit
          </Button>
          <Popconfirm
            title="Yakin hapus?"
            onConfirm={() => handleDelete(record.id)}
          >
            <Button type="link" danger>
              Hapus
            </Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  if (isLoading) {
    return (
      <Spin tip="Memuat daftar sasaran renstra..." size="large" fullscreen />
    );
  }

  if (isError) {
    return (
      <Alert
        message="Gagal memuat data"
        description={
          error?.response?.data?.message ||
          "Terjadi kesalahan saat mengambil data."
        }
        type="error"
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  if (!data || data.length === 0) {
    return (
      <div style={{ padding: 24 }}>
        <Empty description="Belum ada data Sasaran Renstra" />
        <Button
          type="primary"
          onClick={() => navigate("/renstra/sasaran/add")}
          style={{ marginTop: 16 }}
        >
          Tambah Sasaran
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginBottom: 16,
        }}
      >
        <Button onClick={() => navigate("/dashboard-renstra")}>
          🔙 Kembali ke Dashboard Renstra
        </Button>
        <Button type="primary" onClick={() => navigate("/renstra/sasaran/add")}>
          ➕ Tambah Sasaran
        </Button>
      </div>

      <Table columns={columns} dataSource={data} rowKey="id" bordered />
    </div>
  );
};

export default SasaranRenstraListPage;
