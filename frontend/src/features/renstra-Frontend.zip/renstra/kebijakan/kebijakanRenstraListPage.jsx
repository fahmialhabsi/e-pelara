import React from "react";
import { Table, Button, Popconfirm, message, Spin, Alert, Empty } from "antd";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  fetchKebijakanRenstra,
  deleteKebijakanRenstra,
} from "../api/kebijakanRenstraApi";
import { useNavigate } from "react-router-dom";

const KebijakanRenstraListPage = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["renstra-kebijakan"],
    queryFn: async () => {
      const res = await fetchKebijakanRenstra();
      return res.data;
    },
    retry: 1,
    onError: (err) => console.error("Fetch error:", err),
  });

  const deleteMutation = useMutation({
    mutationFn: deleteKebijakanRenstra,
    onSuccess: () => {
      message.success("Data berhasil dihapus");
      queryClient.invalidateQueries({ queryKey: ["renstra-kebijakan"] });
    },
    onError: () => {
      message.error("Gagal menghapus data");
    },
  });

  const handleDelete = (id) => deleteMutation.mutate(id);

  const columns = [
    { title: "No", dataIndex: "no_kebijakan", key: "no" },
    { title: "Isi Kebijakan", dataIndex: "isi_kebijakan", key: "isi" },
    {
      title: "Aksi",
      render: (_, record) => (
        <>
          <Button
            type="link"
            onClick={() => navigate(`/renstra/kebijakan/edit/${record.id}`)}
          >
            Edit
          </Button>
          <Popconfirm
            title="Yakin hapus?"
            onConfirm={() => handleDelete(record.id)}
          >
            <Button type="link" danger>
              Hapus
            </Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  if (isLoading) {
    return (
      <Spin tip="Memuat daftar kebijakan renstra..." size="large" fullscreen />
    );
  }

  if (isError) {
    return (
      <Alert
        message="Gagal memuat data"
        description={
          error?.response?.data?.message ||
          "Terjadi kesalahan saat mengambil data."
        }
        type="error"
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  if (!data || data.length === 0) {
    return (
      <div style={{ padding: 24 }}>
        <Empty description="Belum ada data Kebijakan Renstra" />
        <Button
          type="primary"
          onClick={() => navigate("/renstra/kebijakan/add")}
          style={{ marginTop: 16 }}
        >
          Tambah Kebijakan
        </Button>
      </div>
    );
  }

  return (
    <div>
      <Button
        type="primary"
        onClick={() => navigate("/renstra/kebijakan/add")}
        style={{ marginBottom: 16 }}
      >
        Tambah Kebijakan
      </Button>
      <Table columns={columns} dataSource={data} rowKey="id" bordered />
    </div>
  );
};

export default KebijakanRenstraListPage;
