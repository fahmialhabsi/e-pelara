import React, { useEffect, useState } from "react";
import { Form, Input, Button, Card, Select, message } from "antd";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm, useWatch } from "react-hook-form";
import api from "../../../../services/api";
import { generateKode } from "@/utils/kodeUtils";

const { Option } = Select;

const schema = Yup.object().shape({
  strategi_renstra_id: Yup.number().required("Strategi Renstra wajib dipilih"),
  arah_kebijakan_rpjmd_id: Yup.number().required(
    "Arah Kebijakan RPJMD wajib dipilih"
  ),
  no_kebijakan: Yup.string().required("Nomor Kebijakan wajib diisi"),
  isi_kebijakan: Yup.string().required("Isi Kebijakan wajib diisi"),
});

const KebijakanRenstraForm = ({ initialData = null, onSuccess }) => {
  const queryClient = useQueryClient();
  const [previewKebijakan, setPreviewKebijakan] = useState("");
  const [existingList, setExistingList] = useState([]);

  const {
    handleSubmit,
    setValue,
    watch,
    control,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      strategi_renstra_id: "",
      arah_kebijakan_rpjmd_id: "",
      no_kebijakan: "",
      isi_kebijakan: "",
    },
  });

  const selectedArahId = useWatch({ control, name: "arah_kebijakan_rpjmd_id" });

  useEffect(() => {
    const fetchExisting = async () => {
      const res = await api.get("/kebijakan-renstra");
      setExistingList(res.data);
    };
    fetchExisting();
  }, []);

  const { data: strategiRenstraOptions } = useQuery({
    queryKey: ["strategi-renstra"],
    queryFn: async () => {
      const res = await api.get("/strategi-renstra");
      return res.data;
    },
  });

  const { data: arahKebijakanRpjmdOptions } = useQuery({
    queryKey: ["arah-kebijakan-rpjmd"],
    queryFn: async () => {
      const res = await api.get("/arah-kebijakan-rpjmd");
      return res.data;
    },
  });

  useEffect(() => {
    if (selectedArahId && arahKebijakanRpjmdOptions) {
      const found = arahKebijakanRpjmdOptions.find(
        (a) => a.id === selectedArahId
      );
      if (found) {
        setPreviewKebijakan(found.deskripsi);

        const prefix = `KB${found.kode_arah}`;
        const kode = generateKode({
          prefix,
          dataList: existingList,
          field: "no_kebijakan",
          padding: 2,
        });

        setValue("no_kebijakan", kode);
      }
    }
  }, [selectedArahId, arahKebijakanRpjmdOptions, existingList, setValue]);

  const mutation = useMutation({
    mutationFn: async (formData) => {
      if (initialData?.id) {
        return await api.put(`/kebijakan-renstra/${initialData.id}`, formData);
      } else {
        return await api.post("/kebijakan-renstra", formData);
      }
    },
    onSuccess: () => {
      message.success("Kebijakan Renstra berhasil disimpan");
      queryClient.invalidateQueries({ queryKey: ["kebijakan-renstra"] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      message.error(error?.response?.data?.message || "Gagal menyimpan data");
    },
  });

  const onSubmit = (data) => mutation.mutate(data);

  return (
    <Card
      title={
        initialData ? "Edit Kebijakan Renstra" : "Tambah Kebijakan Renstra"
      }
    >
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="Strategi Renstra"
          validateStatus={errors.strategi_renstra_id ? "error" : ""}
          help={errors.strategi_renstra_id?.message}
        >
          <Select
            value={watch("strategi_renstra_id")}
            onChange={(value) => setValue("strategi_renstra_id", value)}
          >
            {strategiRenstraOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.no_strategi} - {item.isi_strategi.substring(0, 50)}...
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Arah Kebijakan RPJMD"
          validateStatus={errors.arah_kebijakan_rpjmd_id ? "error" : ""}
          help={errors.arah_kebijakan_rpjmd_id?.message}
        >
          <Select
            value={watch("arah_kebijakan_rpjmd_id")}
            onChange={(value) => setValue("arah_kebijakan_rpjmd_id", value)}
          >
            {arahKebijakanRpjmdOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.kode_arah} - {item.deskripsi.substring(0, 50)}...
              </Option>
            ))}
          </Select>
          {previewKebijakan && (
            <div style={{ marginTop: 8, color: "#888" }}>
              {previewKebijakan}
            </div>
          )}
        </Form.Item>

        <Form.Item label="Nomor Kebijakan">
          <div
            style={{
              padding: "8px 12px",
              background: "#f5f5f5",
              borderRadius: 4,
            }}
          >
            {watch("no_kebijakan") || "-"}
          </div>
        </Form.Item>

        <Form.Item
          label="Isi Kebijakan"
          validateStatus={errors.isi_kebijakan ? "error" : ""}
          help={errors.isi_kebijakan?.message}
        >
          <Input.TextArea
            rows={4}
            value={watch("isi_kebijakan")}
            onChange={(e) => setValue("isi_kebijakan", e.target.value)}
          />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={mutation.isLoading}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default KebijakanRenstraForm;
