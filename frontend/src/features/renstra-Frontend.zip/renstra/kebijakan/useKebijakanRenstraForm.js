import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import api from "../../../../services/api";
import { message } from "antd";

const schema = Yup.object().shape({
  rpjmd_id: Yup.number().required("RPJMD wajib dipilih"),
  kebijakan_rpjmd_id: Yup.number().required("Kebijakan RPJMD wajib dipilih"),
  no_kebijakan: Yup.string().required("Nomor Kebijakan wajib diisi"),
  isi_kebijakan: Yup.string().required("Isi Kebijakan wajib diisi"),
  renstra_id: Yup.number().required("Renstra ID tidak ditemukan"),
});

export const useKebijakanRenstraForm = (
  initialData = null,
  renstraAktif,
  onSuccess
) => {
  const queryClient = useQueryClient();
  const [kebijakanPreview, setKebijakanPreview] = useState("");

  const form = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      rpjmd_id: "",
      kebijakan_rpjmd_id: "",
      no_kebijakan: "",
      isi_kebijakan: "",
      renstra_id: renstraAktif?.id || "",
    },
  });

  const { setValue, watch } = form;

  useEffect(() => {
    if (initialData) {
      setValue("rpjmd_id", initialData.rpjmd_id);
      setValue("kebijakan_rpjmd_id", initialData.kebijakan_rpjmd_id);
      setValue("no_kebijakan", initialData.no_kebijakan);
      setValue("isi_kebijakan", initialData.isi_kebijakan);
      setValue("renstra_id", initialData.renstra_id);
    } else if (renstraAktif) {
      setValue("renstra_id", renstraAktif.id);
    }
  }, [initialData, renstraAktif, setValue]);

  const {
    data: rpjmdOptions,
    isLoading: isLoadingRpjmd,
    isError: isErrorRpjmd,
    error: errorRpjmd,
  } = useQuery({
    queryKey: ["rpjmd-list"],
    queryFn: async () => {
      const res = await api.get("/rpjmd");
      return res.data;
    },
    retry: 1,
  });

  const {
    data: kebijakanOptions,
    isLoading: isLoadingKebijakan,
    isError: isErrorKebijakan,
    error: errorKebijakan,
  } = useQuery({
    queryKey: ["kebijakan-rpjmd"],
    queryFn: async () => {
      const res = await api.get("/kebijakan");
      return res.data;
    },
    retry: 1,
  });

  const mutation = useMutation({
    mutationFn: async (formData) => {
      if (initialData?.id) {
        return await api.put(`/renstra-kebijakan/${initialData.id}`, formData);
      } else {
        return await api.post("/renstra-kebijakan", formData);
      }
    },
    onSuccess: () => {
      message.success("Kebijakan Renstra berhasil disimpan");
      queryClient.invalidateQueries({ queryKey: ["renstra-kebijakan"] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      message.error(error?.response?.data?.message || "Gagal menyimpan data");
    },
  });

  const onSubmit = (formData) => {
    const payload = {
      rpjmd_id: formData.rpjmd_id,
      rpjmd_kebijakan_id: formData.kebijakan_rpjmd_id,
      no_kebijakan: formData.no_kebijakan,
      isi_kebijakan: formData.isi_kebijakan,
      renstra_id: formData.renstra_id,
    };
    mutation.mutate(payload);
  };

  // Auto generate nomor kebijakan
  const kebijakanId = watch("kebijakan_rpjmd_id");
  useEffect(() => {
    if (kebijakanId && kebijakanOptions) {
      const selected = kebijakanOptions.find((t) => t.id === kebijakanId);
      if (selected) {
        setKebijakanPreview(selected.isi_kebijakan);
        const match = selected.no_kebijakan.match(/^T(\d+)-(\d{2})$/);
        if (match) {
          const autoNoKebijakan = `TR.${match[1]}-${match[2]}`;
          setValue("no_kebijakan", autoNoKebijakan);
        }
      }
    }
  }, [kebijakanId, kebijakanOptions, setValue]);

  return {
    form,
    rpjmdOptions,
    kebijakanOptions,
    onSubmit,
    kebijakanPreview,
    isLoading: isLoadingRpjmd || isLoadingKebijakan,
    isError: isErrorRpjmd || isErrorKebijakan,
    error: errorRpjmd || errorKebijakan,
    isSubmitting: mutation.isLoading,
  };
};
