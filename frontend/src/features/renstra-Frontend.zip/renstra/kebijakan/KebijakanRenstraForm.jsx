import React from "react";
import {
  Form,
  Input,
  Button,
  Card,
  Select,
  Alert,
  Spin,
  Popconfirm,
  message,
} from "antd";
import { useNavigate } from "react-router-dom";
import { useKebijakanRenstraForm } from "../hooks/useKebijakanRenstraForm";

const { Option } = Select;

const KebijakanRenstraForm = ({ initialData = null, onSuccess, renstraAktif }) => {
  const navigate = useNavigate();
  const {
    form,
    rpjmdOptions,
    kebijakanOptions,
    onSubmit,
    kebijakanPreview,
    isLoading,
    isError,
    error,
    isSubmitting,
  } = useKebijakanRenstraForm(initialData, renstraAktif, onSuccess);

  const {
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = form;

  if (isLoading) {
    return <Spin tip="Memuat data..." size="large" fullscreen />;
  }

  if (isError) {
    return (
      <Alert
        type="error"
        message="Gagal memuat data referensi"
        description={error?.response?.data?.message || "Silakan coba lagi."}
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  return (
    <Card title={initialData ? "Edit Kebijakan Renstra" : "Tambah Kebijakan Renstra"}>
      {/* Navigasi Buttons */}
      <div style={{ marginBottom: 16, display: "flex", gap: 8 }}>
        <Button onClick={() => navigate("/dashboard-renstra")}>
          🔙 Kembali ke Dashboard Renstra
        </Button>
        <Button onClick={() => navigate("/renstra/kebijakan")}>
          📄 Lihat Daftar Kebijakan Renstra
        </Button>
      </div>

      {/* Form Start */}
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="RPJMD"
          validateStatus={errors.rpjmd_id ? "error" : ""}
          help={errors.rpjmd_id?.message}
        >
          <Select
            value={watch("rpjmd_id")}
            onChange={(val) => setValue("rpjmd_id", val)}
          >
            {rpjmdOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.nama_rpjmd}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Kebijakan RPJMD"
          validateStatus={errors.kebijakan_rpjmd_id ? "error" : ""}
          help={errors.kebijakan_rpjmd_id?.message}
        >
          <Select
            value={watch("kebijakan_rpjmd_id")}
            onChange={(val) => setValue("kebijakan_rpjmd_id", val)}
          >
            {kebijakanOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                [{item.no_kebijakan}] {item.isi_kebijakan.substring(0, 50)}...
              </Option>
            ))}
          </Select>
          {kebijakanPreview && (
            <div style={{ marginTop: 8, color: "#888" }}>{kebijakanPreview}</div>
          )}
        </Form.Item>

        <Form.Item
          label="Nomor Kebijakan"
          validateStatus={errors.no_kebijakan ? "error" : ""}
          help={errors.no_kebijakan?.message}
        >
          <Input value={watch("no_kebijakan")} disabled />
        </Form.Item>

        <Form.Item
          label="Isi Kebijakan"
          validateStatus={errors.isi_kebijakan ? "error" : ""}
          help={errors.isi_kebijakan?.message}
        >
          <Input.TextArea
            rows={4}
            value={watch("isi_kebijakan")}
            onChange={(e) => setValue("isi_kebijakan", e.target.value)}
          />
        </Form.Item>

        {/* Hidden field */}
        <Form.Item style={{ display: "none" }}>
          <Input value={watch("renstra_id")} />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={isSubmitting}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default KebijakanRenstraForm;
