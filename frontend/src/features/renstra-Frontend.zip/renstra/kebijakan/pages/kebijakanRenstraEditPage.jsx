import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { fetchKebijakanRenstraById } from "../api/kebijakanRenstraApi";
import KebijakanRenstraForm from "../components/KebijakanRenstraForm";

const KebijakanRenstraEditPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const { data, isLoading } = useQuery(["kebijakan-renstra", id], async () => {
    const res = await fetchKebijakanRenstraById(id);
    return res.data;
  });

  if (isLoading) return <div>Loading...</div>;

  return (
    <KebijakanRenstraForm
      initialData={data}
      onSuccess={() => navigate("/kebijakan")}
    />
  );
};

export default KebijakanRenstraEditPage;
