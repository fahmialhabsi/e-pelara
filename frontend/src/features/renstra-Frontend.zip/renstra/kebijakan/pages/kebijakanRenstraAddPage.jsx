import React from "react";
import KebijakanRenstraForm from "../components/KebijakanRenstraForm";
import { useNavigate } from "react-router-dom";

const KebijakanRenstraAddPage = () => {
  const navigate = useNavigate();
  return <KebijakanRenstraForm onSuccess={() => navigate("/kebijakan")} />;
};

export default KebijakanRenstraAddPage;
