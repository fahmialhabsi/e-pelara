import React from "react";
import { Table, Button, Popconfirm, message } from "antd";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  fetchKebijakanRenstra,
  deleteKebijakanRenstra,
} from "../api/kebijakanRenstraApi";
import { useNavigate } from "react-router-dom";

const KebijakanRenstraListPage = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data, isLoading } = useQuery(["kebijakan-renstra"], async () => {
    const res = await fetchKebijakanRenstra();
    return res.data;
  });

  const deleteMutation = useMutation(deleteKebijakanRenstra, {
    onSuccess: () => {
      message.success("Data berhasil dihapus");
      queryClient.invalidateQueries(["kebijakan-renstra"]);
    },
    onError: () => {
      message.error("Gagal menghapus data");
    },
  });

  const handleDelete = (id) => deleteMutation.mutate(id);

  const columns = [
    { title: "No", dataIndex: "no_kebijakan", key: "no" },
    { title: "Isi Kebijakan", dataIndex: "isi_kebijakan", key: "isi" },
    {
      title: "Aksi",
      render: (_, record) => (
        <>
          <Button
            type="link"
            onClick={() => navigate(`/kebijakan/edit/${record.id}`)}
          >
            Edit
          </Button>
          <Popconfirm
            title="Yakin hapus?"
            onConfirm={() => handleDelete(record.id)}
          >
            <Button type="link" danger>
              Hapus
            </Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        marginBottom: 16,
      }}
    >
      <Button onClick={() => navigate("/dashboard-renstra")}>
        🔙 Kembali ke Dashboard Renstra
      </Button>
      <Button type="primary" onClick={() => navigate("/kebijakan/add")}>
        ➕ Tambah Kebijakan
      </Button>
    </div>
  );
};

export default KebijakanRenstraListPage;
