import api from "../../../../services/api";

export const fetchKebijakanRenstra = () => api.get("/renstra-kebijakan");
export const fetchKebijakanRenstraById = (id) => api.get(`/renstra-kebijakan/${id}`);
export const createKebijakanRenstra = (data) => api.post("/renstra-kebijakan", data);
export const updateKebijakanRenstra = (id, data) =>
  api.put(`/renstra-kebijakan/${id}`, data);
export const deleteKebijakanRenstra = (id) => api.delete(`/renstra-kebijakan/${id}`);
