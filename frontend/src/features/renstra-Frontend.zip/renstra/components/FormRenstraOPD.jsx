import React, { useEffect } from "react";
import { Form, Input, Button, Card, Select, message } from "antd";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import api from "../../../services/api";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";

const { Option } = Select;

const schema = Yup.object().shape({
  opd_id: Yup.number().required("OPD wajib dipilih"),
  bidang_opd: Yup.string().required("Bidang OPD wajib dipilih"),
  sub_bidang_opd: Yup.string().required("Sub Bidang OPD wajib diisi"),
  rpjmd_id: Yup.number().required("RPJMD wajib dipilih"),
  tahun_mulai: Yup.number().required("Tahun Mulai wajib dipilih"),
  tahun_akhir: Yup.number().required("Tahun Akhir wajib dipilih"),
  keterangan: Yup.string(),
});

const FormRenstraOPD = ({ initialData = null, onSuccess }) => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const {
    handleSubmit,
    setValue,
    reset,
    watch,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      opd_id: "",
      bidang_opd: "",
      sub_bidang_opd: "",
      rpjmd_id: "",
      tahun_mulai: "",
      tahun_akhir: "",
      keterangan: "",
    },
  });

  useEffect(() => {
    if (initialData) {
      reset(initialData); // gunakan reset untuk set semua nilai sekaligus
    }
  }, [initialData, reset]);

  const { data: opdOptions = [] } = useQuery({
    queryKey: ["opd-penanggung-jawab"],
    queryFn: async () => {
      const res = await api.get("/opd-penanggung-jawab");
      return res.data.data || [];
    },
  });

  const { data: rpjmdOptions } = useQuery({
    queryKey: ["rpjmd"],
    queryFn: async () => {
      const res = await api.get("/rpjmd");
      return res.data;
    },
  });

  const { data: periodeOptions } = useQuery({
    queryKey: ["periode-rpjmd"],
    queryFn: async () => {
      const res = await api.get("/periode-rpjmd");
      return res.data;
    },
  });

  const mutation = useMutation({
    mutationFn: async (data) => {
      const payload = { ...data, is_aktif: 1 };
      if (initialData?.id) {
        return await api.put(`/renstra-opd/${initialData.id}`, payload);
      } else {
        return await api.post("/renstra-opd", payload);
      }
    },
    onSuccess: () => {
      message.success("Data berhasil disimpan!");
      queryClient.invalidateQueries(["renstra-opd"]);
      if (initialData) {
        navigate("/dashboard-renstra");
      } else {
        reset(); // Kosongkan form jika tambah baru
      }
      if (onSuccess) onSuccess();
    },
    onError: (err) => {
      message.error(err?.response?.data?.message || "Gagal menyimpan data.");
    },
  });

  return (
    <Card
      title={initialData ? "Edit Renstra OPD" : "Tambah Renstra OPD"}
      extra={
        <Button onClick={() => navigate("/dashboard-renstra")}>
          Kembali ke Dashboard
        </Button>
      }
    >
      <Form layout="vertical" onFinish={handleSubmit(mutation.mutate)}>
        <Form.Item
          label="OPD"
          validateStatus={errors.opd_id ? "error" : ""}
          help={errors.opd_id?.message}
        >
          <Select
            value={watch("opd_id")}
            onChange={(value) => setValue("opd_id", value)}
          >
            {opdOptions?.map((opd) => (
              <Option key={opd.id} value={opd.id}>
                {opd.nama_opd}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Bidang OPD"
          validateStatus={errors.bidang_opd ? "error" : ""}
          help={errors.bidang_opd?.message}
        >
          <Select
            value={watch("bidang_opd")}
            onChange={(value) => setValue("bidang_opd", value)}
          >
            {opdOptions?.map((opd) => (
              <Option
                key={`${opd.id}-${opd.nama_bidang_opd}`}
                value={opd.nama_bidang_opd}
              >
                {opd.nama_bidang_opd}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Sub Bidang OPD"
          validateStatus={errors.sub_bidang_opd ? "error" : ""}
          help={errors.sub_bidang_opd?.message}
        >
          <Input
            value={watch("sub_bidang_opd")}
            onChange={(e) => setValue("sub_bidang_opd", e.target.value)}
          />
        </Form.Item>

        <Form.Item
          label="RPJMD"
          validateStatus={errors.rpjmd_id ? "error" : ""}
          help={errors.rpjmd_id?.message}
        >
          <Select
            value={watch("rpjmd_id")}
            onChange={(value) => setValue("rpjmd_id", value)}
          >
            {rpjmdOptions?.map((rpjmd) => (
              <Option key={rpjmd.id} value={rpjmd.id}>
                {rpjmd.nama_rpjmd}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Tahun Mulai"
          validateStatus={errors.tahun_mulai ? "error" : ""}
          help={errors.tahun_mulai?.message}
        >
          <Select
            value={watch("tahun_mulai")}
            onChange={(val) => setValue("tahun_mulai", val)}
          >
            {periodeOptions?.map((p) => (
              <Option key={p.tahun_awal} value={p.tahun_awal}>
                {p.nama} ({p.tahun_awal})
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Tahun Akhir"
          validateStatus={errors.tahun_akhir ? "error" : ""}
          help={errors.tahun_akhir?.message}
        >
          <Select
            value={watch("tahun_akhir")}
            onChange={(val) => setValue("tahun_akhir", val)}
          >
            {periodeOptions?.map((p) => (
              <Option key={p.tahun_akhir} value={p.tahun_akhir}>
                {p.nama} ({p.tahun_akhir})
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item label="Keterangan">
          <Input.TextArea
            rows={3}
            value={watch("keterangan")}
            onChange={(e) => setValue("keterangan", e.target.value)}
          />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={mutation.isLoading}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default FormRenstraOPD;
