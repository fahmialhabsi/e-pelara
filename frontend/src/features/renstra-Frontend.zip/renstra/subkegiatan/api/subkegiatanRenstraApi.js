import api from "../../../../services/api";

export const fetchSubkegiatanRenstra = () => api.get("/subkegiatan-renstra");
export const fetchSubkegiatanRenstraById = (id) =>
  api.get(`/subkegiatan-renstra/${id}`);
export const createSubkegiatanRenstra = (data) =>
  api.post("/subkegiatan-renstra", data);
export const updateSubkegiatanRenstra = (id, data) =>
  api.put(`/subkegiatan-renstra/${id}`, data);
export const deleteSubkegiatanRenstra = (id) =>
  api.delete(`/subkegiatan-renstra/${id}`);
