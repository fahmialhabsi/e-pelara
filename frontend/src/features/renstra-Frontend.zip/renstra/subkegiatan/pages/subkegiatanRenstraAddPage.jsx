import React from "react";
import SubkegiatanRenstraForm from "../components/SubkegiatanRenstraForm";
import { useNavigate } from "react-router-dom";

const SubkegiatanRenstraAddPage = () => {
  const navigate = useNavigate();
  return <SubkegiatanRenstraForm onSuccess={() => navigate("/subkegiatan")} />;
};

export default SubkegiatanRenstraAddPage;
