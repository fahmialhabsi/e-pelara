import React from "react";
import { Table, Button, Popconfirm, message } from "antd";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  fetchSubkegiatanRenstra,
  deleteSubkegiatanRenstra,
} from "../api/subkegiatanRenstraApi";
import { useNavigate } from "react-router-dom";

const SubkegiatanRenstraListPage = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data, isLoading } = useQuery(["subkegiatan-renstra"], async () => {
    const res = await fetchSubkegiatanRenstra();
    return res.data;
  });

  const deleteMutation = useMutation(deleteSubkegiatanRenstra, {
    onSuccess: () => {
      message.success("Data berhasil dihapus");
      queryClient.invalidateQueries(["subkegiatan-renstra"]);
    },
    onError: () => {
      message.error("Gagal menghapus data");
    },
  });

  const handleDelete = (id) => deleteMutation.mutate(id);

  const columns = [
    { title: "Kode Subkegiatan", dataIndex: "kode_subkegiatan", key: "kode" },
    { title: "Nama Subkegiatan", dataIndex: "nama_subkegiatan", key: "nama" },
    {
      title: "Aksi",
      render: (_, record) => (
        <>
          <Button
            type="link"
            onClick={() => navigate(`/subkegiatan/edit/${record.id}`)}
          >
            Edit
          </Button>
          <Popconfirm
            title="Yakin hapus?"
            onConfirm={() => handleDelete(record.id)}
          >
            <Button type="link" danger>
              Hapus
            </Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        marginBottom: 16,
      }}
    >
      <Button onClick={() => navigate("/dashboard-renstra")}>
        🔙 Kembali ke Dashboard Renstra
      </Button>
      <Button type="primary" onClick={() => navigate("/subkegiatan/add")}>
        ➕ Tambah Subkegiatan
      </Button>
    </div>
  );
};

export default SubkegiatanRenstraListPage;
