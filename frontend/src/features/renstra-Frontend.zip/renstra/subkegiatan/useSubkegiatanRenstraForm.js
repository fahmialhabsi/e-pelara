import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import api from "../../../../services/api";
import { message } from "antd";

const schema = Yup.object().shape({
  rpjmd_id: Yup.number().required("RPJMD wajib dipilih"),
  subkegiatan_rpjmd_id: Yup.number().required("Subkegiatan RPJMD wajib dipilih"),
  no_subkegiatan: Yup.string().required("Nomor Subkegiatan wajib diisi"),
  isi_subkegiatan: Yup.string().required("Isi Subkegiatan wajib diisi"),
  renstra_id: Yup.number().required("Renstra ID tidak ditemukan"),
});

export const useSubkegiatanRenstraForm = (
  initialData = null,
  renstraAktif,
  onSuccess
) => {
  const queryClient = useQueryClient();
  const [subkegiatanPreview, setSubkegiatanPreview] = useState("");

  const form = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      rpjmd_id: "",
      subkegiatan_rpjmd_id: "",
      no_subkegiatan: "",
      isi_subkegiatan: "",
      renstra_id: renstraAktif?.id || "",
    },
  });

  const { setValue, watch } = form;

  useEffect(() => {
    if (initialData) {
      setValue("rpjmd_id", initialData.rpjmd_id);
      setValue("subkegiatan_rpjmd_id", initialData.subkegiatan_rpjmd_id);
      setValue("no_subkegiatan", initialData.no_subkegiatan);
      setValue("isi_subkegiatan", initialData.isi_subkegiatan);
      setValue("renstra_id", initialData.renstra_id);
    } else if (renstraAktif) {
      setValue("renstra_id", renstraAktif.id);
    }
  }, [initialData, renstraAktif, setValue]);

  const {
    data: rpjmdOptions,
    isLoading: isLoadingRpjmd,
    isError: isErrorRpjmd,
    error: errorRpjmd,
  } = useQuery({
    queryKey: ["rpjmd-list"],
    queryFn: async () => {
      const res = await api.get("/rpjmd");
      return res.data;
    },
    retry: 1,
  });

  const {
    data: subkegiatanOptions,
    isLoading: isLoadingSubkegiatan,
    isError: isErrorSubkegiatan,
    error: errorSubkegiatan,
  } = useQuery({
    queryKey: ["subkegiatan-rpjmd"],
    queryFn: async () => {
      const res = await api.get("/subkegiatan");
      return res.data;
    },
    retry: 1,
  });

  const mutation = useMutation({
    mutationFn: async (formData) => {
      if (initialData?.id) {
        return await api.put(`/renstra-subkegiatan/${initialData.id}`, formData);
      } else {
        return await api.post("/renstra-subkegiatan", formData);
      }
    },
    onSuccess: () => {
      message.success("Subkegiatan Renstra berhasil disimpan");
      queryClient.invalidateQueries({ queryKey: ["renstra-subkegiatan"] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      message.error(error?.response?.data?.message || "Gagal menyimpan data");
    },
  });

  const onSubmit = (formData) => {
    const payload = {
      rpjmd_id: formData.rpjmd_id,
      rpjmd_subkegiatan_id: formData.subkegiatan_rpjmd_id,
      no_subkegiatan: formData.no_subkegiatan,
      isi_subkegiatan: formData.isi_subkegiatan,
      renstra_id: formData.renstra_id,
    };
    mutation.mutate(payload);
  };

  // Auto generate nomor subkegiatan
  const subkegiatanId = watch("subkegiatan_rpjmd_id");
  useEffect(() => {
    if (subkegiatanId && subkegiatanOptions) {
      const selected = subkegiatanOptions.find((t) => t.id === subkegiatanId);
      if (selected) {
        setSubkegiatanPreview(selected.isi_subkegiatan);
        const match = selected.no_subkegiatan.match(/^T(\d+)-(\d{2})$/);
        if (match) {
          const autoNoSubkegiatan = `TR.${match[1]}-${match[2]}`;
          setValue("no_subkegiatan", autoNoSubkegiatan);
        }
      }
    }
  }, [subkegiatanId, subkegiatanOptions, setValue]);

  return {
    form,
    rpjmdOptions,
    subkegiatanOptions,
    onSubmit,
    subkegiatanPreview,
    isLoading: isLoadingRpjmd || isLoadingSubkegiatan,
    isError: isErrorRpjmd || isErrorSubkegiatan,
    error: errorRpjmd || errorSubkegiatan,
    isSubmitting: mutation.isLoading,
  };
};
