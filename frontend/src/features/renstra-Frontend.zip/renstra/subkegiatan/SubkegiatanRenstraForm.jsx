import React from "react";
import {
  Form,
  Input,
  Button,
  Card,
  Select,
  Alert,
  Spin,
  Popconfirm,
  message,
} from "antd";
import { useNavigate } from "react-router-dom";
import { useSubkegiatanRenstraForm } from "../hooks/useSubkegiatanRenstraForm";

const { Option } = Select;

const SubkegiatanRenstraForm = ({ initialData = null, onSuccess, renstraAktif }) => {
  const navigate = useNavigate();
  const {
    form,
    rpjmdOptions,
    subkegiatanOptions,
    onSubmit,
    subkegiatanPreview,
    isLoading,
    isError,
    error,
    isSubmitting,
  } = useSubkegiatanRenstraForm(initialData, renstraAktif, onSuccess);

  const {
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = form;

  if (isLoading) {
    return <Spin tip="Memuat data..." size="large" fullscreen />;
  }

  if (isError) {
    return (
      <Alert
        type="error"
        message="Gagal memuat data referensi"
        description={error?.response?.data?.message || "Silakan coba lagi."}
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  return (
    <Card title={initialData ? "Edit Subkegiatan Renstra" : "Tambah Subkegiatan Renstra"}>
      {/* Navigasi Buttons */}
      <div style={{ marginBottom: 16, display: "flex", gap: 8 }}>
        <Button onClick={() => navigate("/dashboard-renstra")}>
          🔙 Kembali ke Dashboard Renstra
        </Button>
        <Button onClick={() => navigate("/renstra/subkegiatan")}>
          📄 Lihat Daftar Subkegiatan Renstra
        </Button>
      </div>

      {/* Form Start */}
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="RPJMD"
          validateStatus={errors.rpjmd_id ? "error" : ""}
          help={errors.rpjmd_id?.message}
        >
          <Select
            value={watch("rpjmd_id")}
            onChange={(val) => setValue("rpjmd_id", val)}
          >
            {rpjmdOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.nama_rpjmd}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Subkegiatan RPJMD"
          validateStatus={errors.subkegiatan_rpjmd_id ? "error" : ""}
          help={errors.subkegiatan_rpjmd_id?.message}
        >
          <Select
            value={watch("subkegiatan_rpjmd_id")}
            onChange={(val) => setValue("subkegiatan_rpjmd_id", val)}
          >
            {subkegiatanOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                [{item.no_subkegiatan}] {item.isi_subkegiatan.substring(0, 50)}...
              </Option>
            ))}
          </Select>
          {subkegiatanPreview && (
            <div style={{ marginTop: 8, color: "#888" }}>{subkegiatanPreview}</div>
          )}
        </Form.Item>

        <Form.Item
          label="Nomor Subkegiatan"
          validateStatus={errors.no_subkegiatan ? "error" : ""}
          help={errors.no_subkegiatan?.message}
        >
          <Input value={watch("no_subkegiatan")} disabled />
        </Form.Item>

        <Form.Item
          label="Isi Subkegiatan"
          validateStatus={errors.isi_subkegiatan ? "error" : ""}
          help={errors.isi_subkegiatan?.message}
        >
          <Input.TextArea
            rows={4}
            value={watch("isi_subkegiatan")}
            onChange={(e) => setValue("isi_subkegiatan", e.target.value)}
          />
        </Form.Item>

        {/* Hidden field */}
        <Form.Item style={{ display: "none" }}>
          <Input value={watch("renstra_id")} />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={isSubmitting}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default SubkegiatanRenstraForm;
