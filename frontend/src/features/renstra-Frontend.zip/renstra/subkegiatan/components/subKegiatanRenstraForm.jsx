import React, { useEffect, useState } from "react";
import { Form, Input, Button, Card, Select, message } from "antd";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm, useWatch } from "react-hook-form";
import api from "../../../../services/api";
import { generateKode } from "@/utils/kodeUtils";

const { Option } = Select;

const schema = Yup.object().shape({
  kegiatan_renstra_id: Yup.number().required("Kegiatan Renstra wajib dipilih"),
  subkegiatan_rpjmd_id: Yup.number().required(
    "Sub Kegiatan RPJMD wajib dipilih"
  ),
  no_subkegiatan: Yup.string().required("Nomor Sub Kegiatan wajib diisi"),
  isi_subkegiatan: Yup.string().required("Isi Sub Kegiatan wajib diisi"),
});

const SubKegiatanRenstraForm = ({ initialData = null, onSuccess }) => {
  const queryClient = useQueryClient();
  const [previewSub, setPreviewSub] = useState("");
  const [existingList, setExistingList] = useState([]);

  const {
    handleSubmit,
    setValue,
    watch,
    control,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      kegiatan_renstra_id: "",
      subkegiatan_rpjmd_id: "",
      no_subkegiatan: "",
      isi_subkegiatan: "",
    },
  });

  useEffect(() => {
    if (initialData) {
      setValue("kegiatan_renstra_id", initialData.kegiatan_renstra_id);
      setValue("subkegiatan_rpjmd_id", initialData.subkegiatan_rpjmd_id);
      setValue("no_subkegiatan", initialData.no_subkegiatan);
      setValue("isi_subkegiatan", initialData.isi_subkegiatan);
    }
  }, [initialData, setValue]);

  const { data: kegiatanRenstraOptions } = useQuery({
    queryKey: ["kegiatan-renstra"],
    queryFn: async () => {
      const res = await api.get("/kegiatan-renstra");
      return res.data;
    },
  });

  const { data: subkegiatanRpjmdOptions } = useQuery({
    queryKey: ["subkegiatan-rpjmd"],
    queryFn: async () => {
      const res = await api.get("/subkegiatan-rpjmd");
      return res.data;
    },
  });

  useEffect(() => {
    const fetchExisting = async () => {
      const res = await api.get("/subkegiatan-renstra");
      setExistingList(res.data);
    };
    fetchExisting();
  }, []);

  const selectedSubId = useWatch({ control, name: "subkegiatan_rpjmd_id" });

  useEffect(() => {
    if (selectedSubId && subkegiatanRpjmdOptions) {
      const found = subkegiatanRpjmdOptions.find((s) => s.id === selectedSubId);
      if (found) {
        setPreviewSub(found.nama_sub_kegiatan);

        const prefix = `SB${found.kode_sub_kegiatan}`;
        const kode = generateKode({
          prefix,
          dataList: existingList,
          field: "no_subkegiatan",
          padding: 2,
        });

        setValue("no_subkegiatan", kode);
      }
    }
  }, [selectedSubId, subkegiatanRpjmdOptions, existingList, setValue]);

  const mutation = useMutation({
    mutationFn: async (formData) => {
      if (initialData?.id) {
        return await api.put(
          `/subkegiatan-renstra/${initialData.id}`,
          formData
        );
      } else {
        return await api.post("/subkegiatan-renstra", formData);
      }
    },
    onSuccess: () => {
      message.success("Sub Kegiatan Renstra berhasil disimpan");
      queryClient.invalidateQueries({ queryKey: ["subkegiatan-renstra"] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      message.error(error?.response?.data?.message || "Gagal menyimpan data");
    },
  });

  const onSubmit = (data) => mutation.mutate(data);

  return (
    <Card
      title={
        initialData
          ? "Edit Sub Kegiatan Renstra"
          : "Tambah Sub Kegiatan Renstra"
      }
    >
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="Kegiatan Renstra"
          validateStatus={errors.kegiatan_renstra_id ? "error" : ""}
          help={errors.kegiatan_renstra_id?.message}
        >
          <Select
            value={watch("kegiatan_renstra_id")}
            onChange={(value) => setValue("kegiatan_renstra_id", value)}
          >
            {kegiatanRenstraOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.no_kegiatan} - {item.isi_kegiatan.substring(0, 50)}...
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Sub Kegiatan RPJMD"
          validateStatus={errors.subkegiatan_rpjmd_id ? "error" : ""}
          help={errors.subkegiatan_rpjmd_id?.message}
        >
          <Select
            value={watch("subkegiatan_rpjmd_id")}
            onChange={(value) => setValue("subkegiatan_rpjmd_id", value)}
          >
            {subkegiatanRpjmdOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.kode_sub_kegiatan} -{" "}
                {item.nama_sub_kegiatan.substring(0, 50)}...
              </Option>
            ))}
          </Select>
          {previewSub && (
            <div style={{ marginTop: 8, color: "#888" }}>{previewSub}</div>
          )}
        </Form.Item>

        <Form.Item label="Nomor Sub Kegiatan">
          <div
            style={{
              padding: "8px 12px",
              background: "#f5f5f5",
              borderRadius: 4,
            }}
          >
            {watch("no_subkegiatan") || "-"}
          </div>
        </Form.Item>

        <Form.Item
          label="Isi Sub Kegiatan"
          validateStatus={errors.isi_subkegiatan ? "error" : ""}
          help={errors.isi_subkegiatan?.message}
        >
          <Input.TextArea
            rows={4}
            value={watch("isi_subkegiatan")}
            onChange={(e) => setValue("isi_subkegiatan", e.target.value)}
          />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={mutation.isLoading}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default SubKegiatanRenstraForm;
