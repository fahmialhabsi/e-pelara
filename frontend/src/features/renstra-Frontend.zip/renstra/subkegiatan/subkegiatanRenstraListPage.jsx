import React from "react";
import { Table, Button, Popconfirm, message, Spin, Alert, Empty } from "antd";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  fetchSubkegiatanRenstra,
  deleteSubkegiatanRenstra,
} from "../api/subkegiatanRenstraApi";
import { useNavigate } from "react-router-dom";

const SubkegiatanRenstraListPage = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["renstra-subkegiatan"],
    queryFn: async () => {
      const res = await fetchSubkegiatanRenstra();
      return res.data;
    },
    retry: 1,
    onError: (err) => console.error("Fetch error:", err),
  });

  const deleteMutation = useMutation({
    mutationFn: deleteSubkegiatanRenstra,
    onSuccess: () => {
      message.success("Data berhasil dihapus");
      queryClient.invalidateQueries({ queryKey: ["renstra-subkegiatan"] });
    },
    onError: () => {
      message.error("Gagal menghapus data");
    },
  });

  const handleDelete = (id) => deleteMutation.mutate(id);

  const columns = [
    { title: "No", dataIndex: "no_subkegiatan", key: "no" },
    { title: "Isi Subkegiatan", dataIndex: "isi_subkegiatan", key: "isi" },
    {
      title: "Aksi",
      render: (_, record) => (
        <>
          <Button
            type="link"
            onClick={() => navigate(`/renstra/subkegiatan/edit/${record.id}`)}
          >
            Edit
          </Button>
          <Popconfirm
            title="Yakin hapus?"
            onConfirm={() => handleDelete(record.id)}
          >
            <Button type="link" danger>
              Hapus
            </Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  if (isLoading) {
    return (
      <Spin tip="Memuat daftar subkegiatan renstra..." size="large" fullscreen />
    );
  }

  if (isError) {
    return (
      <Alert
        message="Gagal memuat data"
        description={
          error?.response?.data?.message ||
          "Terjadi kesalahan saat mengambil data."
        }
        type="error"
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  if (!data || data.length === 0) {
    return (
      <div style={{ padding: 24 }}>
        <Empty description="Belum ada data Subkegiatan Renstra" />
        <Button
          type="primary"
          onClick={() => navigate("/renstra/subkegiatan/add")}
          style={{ marginTop: 16 }}
        >
          Tambah Subkegiatan
        </Button>
      </div>
    );
  }

  return (
    <div>
      <Button
        type="primary"
        onClick={() => navigate("/renstra/subkegiatan/add")}
        style={{ marginBottom: 16 }}
      >
        Tambah Subkegiatan
      </Button>
      <Table columns={columns} dataSource={data} rowKey="id" bordered />
    </div>
  );
};

export default SubkegiatanRenstraListPage;
