import React from "react";
import IndikatorSubkegiatanRenstraForm from "../components/IndikatorSubkegiatanRenstraForm";
import { useNavigate } from "react-router-dom";

const IndikatorSubkegiatanRenstraAddPage = () => {
  const navigate = useNavigate();
  return <IndikatorSubkegiatanRenstraForm onSuccess={() => navigate("/indikator")} />;
};

export default IndikatorSubkegiatanRenstraAddPage;
