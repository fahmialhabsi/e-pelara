import React from "react";
import {
  Form,
  Input,
  Button,
  Card,
  Select,
  Alert,
  Spin,
  Popconfirm,
  message,
} from "antd";
import { useNavigate } from "react-router-dom";
import { useIndikatorRenstraForm } from "../hooks/useIndikatorRenstraForm";

const { Option } = Select;

const IndikatorRenstraForm = ({ initialData = null, onSuccess, renstraAktif }) => {
  const navigate = useNavigate();
  const {
    form,
    rpjmdOptions,
    indikatorOptions,
    onSubmit,
    indikatorPreview,
    isLoading,
    isError,
    error,
    isSubmitting,
  } = useIndikatorRenstraForm(initialData, renstraAktif, onSuccess);

  const {
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = form;

  if (isLoading) {
    return <Spin tip="Memuat data..." size="large" fullscreen />;
  }

  if (isError) {
    return (
      <Alert
        type="error"
        message="Gagal memuat data referensi"
        description={error?.response?.data?.message || "Silakan coba lagi."}
        showIcon
        style={{ margin: 24 }}
      />
    );
  }

  return (
    <Card title={initialData ? "Edit Indikator Renstra" : "Tambah Indikator Renstra"}>
      {/* Navigasi Buttons */}
      <div style={{ marginBottom: 16, display: "flex", gap: 8 }}>
        <Button onClick={() => navigate("/dashboard-renstra")}>
          🔙 Kembali ke Dashboard Renstra
        </Button>
        <Button onClick={() => navigate("/renstra/indikator")}>
          📄 Lihat Daftar Indikator Renstra
        </Button>
      </div>

      {/* Form Start */}
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="RPJMD"
          validateStatus={errors.rpjmd_id ? "error" : ""}
          help={errors.rpjmd_id?.message}
        >
          <Select
            value={watch("rpjmd_id")}
            onChange={(val) => setValue("rpjmd_id", val)}
          >
            {rpjmdOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.nama_rpjmd}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          label="Indikator RPJMD"
          validateStatus={errors.indikator_rpjmd_id ? "error" : ""}
          help={errors.indikator_rpjmd_id?.message}
        >
          <Select
            value={watch("indikator_rpjmd_id")}
            onChange={(val) => setValue("indikator_rpjmd_id", val)}
          >
            {indikatorOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                [{item.no_indikator}] {item.isi_indikator.substring(0, 50)}...
              </Option>
            ))}
          </Select>
          {indikatorPreview && (
            <div style={{ marginTop: 8, color: "#888" }}>{indikatorPreview}</div>
          )}
        </Form.Item>

        <Form.Item
          label="Nomor Indikator"
          validateStatus={errors.no_indikator ? "error" : ""}
          help={errors.no_indikator?.message}
        >
          <Input value={watch("no_indikator")} disabled />
        </Form.Item>

        <Form.Item
          label="Isi Indikator"
          validateStatus={errors.isi_indikator ? "error" : ""}
          help={errors.isi_indikator?.message}
        >
          <Input.TextArea
            rows={4}
            value={watch("isi_indikator")}
            onChange={(e) => setValue("isi_indikator", e.target.value)}
          />
        </Form.Item>

        {/* Hidden field */}
        <Form.Item style={{ display: "none" }}>
          <Input value={watch("renstra_id")} />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={isSubmitting}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default IndikatorRenstraForm;
