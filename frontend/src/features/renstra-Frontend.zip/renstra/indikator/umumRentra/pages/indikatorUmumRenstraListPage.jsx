import React from "react";

const IndikatorUmumRenstraListPage = () => {
  return <div>Indikator Umum Renstra List Page</div>;
};

export default IndikatorUmumRenstraListPage;
