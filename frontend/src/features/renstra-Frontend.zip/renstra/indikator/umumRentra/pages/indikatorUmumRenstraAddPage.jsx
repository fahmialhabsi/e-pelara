import React from "react";
import IndikatorUmumRenstraForm from "../components/IndikatorUmumRenstraForm";
import { useNavigate } from "react-router-dom";

const IndikatorUmumRenstraAddPage = () => {
  const navigate = useNavigate();
  return <IndikatorUmumRenstraForm onSuccess={() => navigate("/indikator")} />;
};

export default IndikatorUmumRenstraAddPage;
