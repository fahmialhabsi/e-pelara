import React from "react";
import IndikatorIndikatorRenstraForm from "../components/IndikatorIndikatorRenstraForm";
import { useNavigate } from "react-router-dom";

const IndikatorIndikatorRenstraAddPage = () => {
  const navigate = useNavigate();
  return <IndikatorIndikatorRenstraForm onSuccess={() => navigate("/indikator")} />;
};

export default IndikatorIndikatorRenstraAddPage;
