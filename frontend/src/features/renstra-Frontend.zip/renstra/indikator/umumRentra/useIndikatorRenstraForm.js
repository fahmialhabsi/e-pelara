import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import api from "../../../../services/api";
import { message } from "antd";

const schema = Yup.object().shape({
  rpjmd_id: Yup.number().required("RPJMD wajib dipilih"),
  indikator_rpjmd_id: Yup.number().required("Indikator RPJMD wajib dipilih"),
  no_indikator: Yup.string().required("Nomor Indikator wajib diisi"),
  isi_indikator: Yup.string().required("Isi Indikator wajib diisi"),
  renstra_id: Yup.number().required("Renstra ID tidak ditemukan"),
});

export const useIndikatorRenstraForm = (
  initialData = null,
  renstraAktif,
  onSuccess
) => {
  const queryClient = useQueryClient();
  const [indikatorPreview, setIndikatorPreview] = useState("");

  const form = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      rpjmd_id: "",
      indikator_rpjmd_id: "",
      no_indikator: "",
      isi_indikator: "",
      renstra_id: renstraAktif?.id || "",
    },
  });

  const { setValue, watch } = form;

  useEffect(() => {
    if (initialData) {
      setValue("rpjmd_id", initialData.rpjmd_id);
      setValue("indikator_rpjmd_id", initialData.indikator_rpjmd_id);
      setValue("no_indikator", initialData.no_indikator);
      setValue("isi_indikator", initialData.isi_indikator);
      setValue("renstra_id", initialData.renstra_id);
    } else if (renstraAktif) {
      setValue("renstra_id", renstraAktif.id);
    }
  }, [initialData, renstraAktif, setValue]);

  const {
    data: rpjmdOptions,
    isLoading: isLoadingRpjmd,
    isError: isErrorRpjmd,
    error: errorRpjmd,
  } = useQuery({
    queryKey: ["rpjmd-list"],
    queryFn: async () => {
      const res = await api.get("/rpjmd");
      return res.data;
    },
    retry: 1,
  });

  const {
    data: indikatorOptions,
    isLoading: isLoadingIndikator,
    isError: isErrorIndikator,
    error: errorIndikator,
  } = useQuery({
    queryKey: ["indikator-rpjmd"],
    queryFn: async () => {
      const res = await api.get("/indikator");
      return res.data;
    },
    retry: 1,
  });

  const mutation = useMutation({
    mutationFn: async (formData) => {
      if (initialData?.id) {
        return await api.put(`/renstra-indikator/${initialData.id}`, formData);
      } else {
        return await api.post("/renstra-indikator", formData);
      }
    },
    onSuccess: () => {
      message.success("Indikator Renstra berhasil disimpan");
      queryClient.invalidateQueries({ queryKey: ["renstra-indikator"] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      message.error(error?.response?.data?.message || "Gagal menyimpan data");
    },
  });

  const onSubmit = (formData) => {
    const payload = {
      rpjmd_id: formData.rpjmd_id,
      rpjmd_indikator_id: formData.indikator_rpjmd_id,
      no_indikator: formData.no_indikator,
      isi_indikator: formData.isi_indikator,
      renstra_id: formData.renstra_id,
    };
    mutation.mutate(payload);
  };

  // Auto generate nomor indikator
  const indikatorId = watch("indikator_rpjmd_id");
  useEffect(() => {
    if (indikatorId && indikatorOptions) {
      const selected = indikatorOptions.find((t) => t.id === indikatorId);
      if (selected) {
        setIndikatorPreview(selected.isi_indikator);
        const match = selected.no_indikator.match(/^T(\d+)-(\d{2})$/);
        if (match) {
          const autoNoIndikator = `TR.${match[1]}-${match[2]}`;
          setValue("no_indikator", autoNoIndikator);
        }
      }
    }
  }, [indikatorId, indikatorOptions, setValue]);

  return {
    form,
    rpjmdOptions,
    indikatorOptions,
    onSubmit,
    indikatorPreview,
    isLoading: isLoadingRpjmd || isLoadingIndikator,
    isError: isErrorRpjmd || isErrorIndikator,
    error: errorRpjmd || errorIndikator,
    isSubmitting: mutation.isLoading,
  };
};
