import api from "../../../../services/api";

export const fetchIndikatorRenstra = () => api.get("/renstra-indikator");
export const fetchIndikatorRenstraById = (id) => api.get(`/renstra-indikator/${id}`);
export const createIndikatorRenstra = (data) => api.post("/renstra-indikator", data);
export const updateIndikatorRenstra = (id, data) =>
  api.put(`/renstra-indikator/${id}`, data);
export const deleteIndikatorRenstra = (id) => api.delete(`/renstra-indikator/${id}`);
