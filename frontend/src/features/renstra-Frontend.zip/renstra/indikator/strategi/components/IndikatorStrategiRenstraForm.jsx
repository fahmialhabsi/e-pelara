import React, { useEffect, useState } from "react";
import { Form, Input, Button, Card, Select, message } from "antd";
import { useForm, useWatch } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import axios from "axios";

const { Option } = Select;

const schema = Yup.object().shape({
  strategi_renstra_id: Yup.number().required("Strategi Renstra wajib dipilih"),
  kode_indikator: Yup.string().required("Kode indikator wajib diisi"),
  nama_indikator: Yup.string().required("Nama indikator wajib diisi"),
  satuan: Yup.string().required("Satuan wajib diisi"),
  target_tahun_1: Yup.string().required("Target tahun 1 wajib diisi"),
});

const IndikatorStrategiRenstraForm = ({ initialData = null, onSuccess }) => {
  const queryClient = useQueryClient();
  const [existingList, setExistingList] = useState([]);

  const {
    handleSubmit,
    setValue,
    watch,
    control,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      strategi_renstra_id: "",
      kode_indikator: "",
      nama_indikator: "",
      satuan: "",
      target_tahun_1: "",
    },
  });

  const selectedStrategiId = useWatch({ control, name: "strategi_renstra_id" });

  useEffect(() => {
    const fetchExisting = async () => {
      const res = await axios.get("/api/indikator-strategi-renstra");
      setExistingList(res.data);
    };
    fetchExisting();
  }, []);

  const { data: strategiRenstraOptions } = useQuery(
    ["strategi-renstra"],
    async () => {
      const res = await axios.get("/api/strategi-renstra");
      return res.data;
    }
  );

  useEffect(() => {
    if (selectedStrategiId && strategiRenstraOptions) {
      const selected = strategiRenstraOptions.find(
        (s) => s.id === selectedStrategiId
      );
      if (selected) {
        const baseCode = `IS${selected.kode_strategi}`;
        const count = existingList.filter((item) =>
          item.kode_indikator?.startsWith(baseCode)
        ).length;
        const padded = String(count + 1).padStart(2, "0");
        const kodeIndikator = `${baseCode}.${padded}`;
        setValue("kode_indikator", kodeIndikator);
      }
    }
  }, [selectedStrategiId, strategiRenstraOptions, existingList, setValue]);

  const mutation = useMutation(
    async (formData) => {
      if (initialData?.id) {
        return await axios.put(
          `/api/indikator-strategi-renstra/${initialData.id}`,
          formData
        );
      } else {
        return await axios.post("/api/indikator-strategi-renstra", formData);
      }
    },
    {
      onSuccess: () => {
        message.success("Indikator Strategi Renstra berhasil disimpan");
        queryClient.invalidateQueries(["indikator-strategi-renstra"]);
        if (onSuccess) onSuccess();
      },
      onError: (error) => {
        message.error(error?.response?.data?.message || "Gagal menyimpan data");
      },
    }
  );

  const onSubmit = (data) => mutation.mutate(data);

  return (
    <Card
      title={
        initialData
          ? "Edit Indikator Strategi Renstra"
          : "Tambah Indikator Strategi Renstra"
      }
    >
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="Strategi Renstra"
          validateStatus={errors.strategi_renstra_id ? "error" : ""}
          help={errors.strategi_renstra_id?.message}
        >
          <Select
            value={watch("strategi_renstra_id")}
            onChange={(val) => setValue("strategi_renstra_id", val)}
          >
            {strategiRenstraOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.kode_strategi} - {item.nama_strategi}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item label="Kode Indikator">
          <div
            style={{
              padding: "8px 12px",
              background: "#f5f5f5",
              borderRadius: 4,
            }}
          >
            {watch("kode_indikator") || "-"}
          </div>
        </Form.Item>

        <Form.Item
          label="Nama Indikator"
          validateStatus={errors.nama_indikator ? "error" : ""}
          help={errors.nama_indikator?.message}
        >
          <Input.TextArea
            rows={3}
            value={watch("nama_indikator")}
            onChange={(e) => setValue("nama_indikator", e.target.value)}
          />
        </Form.Item>

        <Form.Item
          label="Satuan"
          validateStatus={errors.satuan ? "error" : ""}
          help={errors.satuan?.message}
        >
          <Input
            value={watch("satuan")}
            onChange={(e) => setValue("satuan", e.target.value)}
          />
        </Form.Item>

        <Form.Item
          label="Target Tahun 1"
          validateStatus={errors.target_tahun_1 ? "error" : ""}
          help={errors.target_tahun_1?.message}
        >
          <Input
            value={watch("target_tahun_1")}
            onChange={(e) => setValue("target_tahun_1", e.target.value)}
          />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={mutation.isLoading}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default IndikatorStrategiRenstraForm;
