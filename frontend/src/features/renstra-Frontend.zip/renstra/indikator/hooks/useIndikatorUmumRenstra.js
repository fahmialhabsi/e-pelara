// src/features/renstra/indikator/hooks/useIndikatorUmumRenstra.js
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  fetchIndikatorRenstra,
  createIndikatorRenstra,
  updateIndikatorRenstra,
  deleteIndikatorRenstra,
} from "../api/indikatorUmumRenstraApi";

export const useIndikatorRenstra = (params) => {
  return useQuery({
    queryKey: ["indikator-renstra", params],
    queryFn: () => fetchIndikatorRenstra(params),
  });
};

export const useCreateIndikatorRenstra = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: createIndikatorRenstra,
    onSuccess: () => queryClient.invalidateQueries(["indikator-renstra"]),
  });
};

export const useUpdateIndikatorRenstra = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: updateIndikatorRenstra,
    onSuccess: () => queryClient.invalidateQueries(["indikator-renstra"]),
  });
};

export const useDeleteIndikatorRenstra = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: deleteIndikatorRenstra,
    onSuccess: () => queryClient.invalidateQueries(["indikator-renstra"]),
  });
};
