import React, { useEffect, useState } from "react";
import { Form, Input, Button, Card, Select, message } from "antd";
import { useForm, useWatch } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import axios from "axios";
import { generateKode } from "@/utils/kodeUtils";

const { Option } = Select;

const schema = Yup.object().shape({
  sasaran_renstra_id: Yup.number().required("Sasaran Renstra wajib dipilih"),
  kode_indikator: Yup.string().required("Kode indikator wajib diisi"),
  nama_indikator: Yup.string().required("Nama indikator wajib diisi"),
  satuan: Yup.string().required("Satuan wajib diisi"),
  target_tahun_1: Yup.string().required("Target tahun 1 wajib diisi"),
});

const IndikatorSasaranRenstraForm = ({ initialData = null, onSuccess }) => {
  const queryClient = useQueryClient();
  const [existingList, setExistingList] = useState([]);

  const {
    handleSubmit,
    setValue,
    watch,
    control,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      sasaran_renstra_id: "",
      kode_indikator: "",
      nama_indikator: "",
      satuan: "",
      target_tahun_1: "",
    },
  });

  const selectedSasaranId = useWatch({ control, name: "sasaran_renstra_id" });

  useEffect(() => {
    const fetchExisting = async () => {
      const res = await axios.get("/api/indikator-sasaran-renstra");
      setExistingList(res.data);
    };
    fetchExisting();
  }, []);

  const { data: sasaranRenstraOptions } = useQuery(
    ["sasaran-renstra"],
    async () => {
      const res = await axios.get("/api/sasaran-renstra");
      return res.data;
    }
  );

  useEffect(() => {
    if (selectedSasaranId && sasaranRenstraOptions) {
      const selected = sasaranRenstraOptions.find(
        (x) => x.id === selectedSasaranId
      );
      if (selected) {
        const prefix = `ISA${selected.kode_sasaran}`;
        const kode = generateKode({
          prefix,
          dataList: existingList,
          field: "kode_indikator",
          padding: 2,
        });
        setValue("kode_indikator", kode);
      }
    }
  }, [selectedSasaranId, sasaranRenstraOptions, existingList, setValue]);

  const mutation = useMutation(
    async (formData) => {
      if (initialData?.id) {
        return await axios.put(
          `/api/indikator-sasaran-renstra/${initialData.id}`,
          formData
        );
      } else {
        return await axios.post("/api/indikator-sasaran-renstra", formData);
      }
    },
    {
      onSuccess: () => {
        message.success("Indikator Sasaran Renstra berhasil disimpan");
        queryClient.invalidateQueries(["indikator-sasaran-renstra"]);
        if (onSuccess) onSuccess();
      },
      onError: (error) => {
        message.error(error?.response?.data?.message || "Gagal menyimpan data");
      },
    }
  );

  const onSubmit = (data) => mutation.mutate(data);

  return (
    <Card
      title={
        initialData
          ? "Edit Indikator Sasaran Renstra"
          : "Tambah Indikator Sasaran Renstra"
      }
    >
      <Form layout="vertical" onFinish={handleSubmit(onSubmit)}>
        <Form.Item
          label="Sasaran Renstra"
          validateStatus={errors.sasaran_renstra_id ? "error" : ""}
          help={errors.sasaran_renstra_id?.message}
        >
          <Select
            value={watch("sasaran_renstra_id")}
            onChange={(val) => setValue("sasaran_renstra_id", val)}
          >
            {sasaranRenstraOptions?.map((item) => (
              <Option key={item.id} value={item.id}>
                {item.kode_sasaran} - {item.nama_sasaran}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item label="Kode Indikator">
          <div
            style={{
              padding: "8px 12px",
              background: "#f5f5f5",
              borderRadius: 4,
            }}
          >
            {watch("kode_indikator") || "-"}
          </div>
        </Form.Item>

        <Form.Item
          label="Nama Indikator"
          validateStatus={errors.nama_indikator ? "error" : ""}
          help={errors.nama_indikator?.message}
        >
          <Input.TextArea
            rows={3}
            value={watch("nama_indikator")}
            onChange={(e) => setValue("nama_indikator", e.target.value)}
          />
        </Form.Item>

        <Form.Item
          label="Satuan"
          validateStatus={errors.satuan ? "error" : ""}
          help={errors.satuan?.message}
        >
          <Input
            value={watch("satuan")}
            onChange={(e) => setValue("satuan", e.target.value)}
          />
        </Form.Item>

        <Form.Item
          label="Target Tahun 1"
          validateStatus={errors.target_tahun_1 ? "error" : ""}
          help={errors.target_tahun_1?.message}
        >
          <Input
            value={watch("target_tahun_1")}
            onChange={(e) => setValue("target_tahun_1", e.target.value)}
          />
        </Form.Item>

        <Form.Item>
          <Button type="primary" htmlType="submit" loading={mutation.isLoading}>
            {initialData ? "Update" : "Simpan"}
          </Button>
        </Form.Item>
      </Form>
    </Card>
  );
};

export default IndikatorSasaranRenstraForm;
