const { RenstraStrategi, RenstraOPD, Strategi } = require("../models");

exports.create = async (req, res) => {
  try {
    const {
      no_strategi, // bisa dari frontend
      deskripsi,
      sasaran_id,
      rpjmd_strategi_id,
      renstra_id,
      no_rpjmd,
      isi_strategi_rpjmd,
    } = req.body;

    const data = await RenstraStrategi.create({
      kode_strategi: no_strategi, // pastikan field diisi
      deskripsi,
      sasaran_id,
      rpjmd_strategi_id,
      renstra_id,
      no_rpjmd,
      isi_strategi_rpjmd,
    });

    res.status(201).json(data);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.findAll = async (req, res) => {
  try {
    const { renstra_id, tahun_mulai } = req.query;

    const whereClause = {};
    if (renstra_id) whereClause.renstra_id = renstra_id;

    const data = await RenstraStrategi.findAll({
      where: whereClause,
      include: [
        {
          model: RenstraOPD,
          as: "renstra",
          attributes: ["id", "bidang_opd", "sub_bidang_opd"],
          ...(tahun_mulai && {
            where: { tahun_mulai: parseInt(tahun_mulai, 10) },
          }),
        },
      ],
    });

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.findOne = async (req, res) => {
  try {
    const data = await RenstraStrategi.findByPk(req.params.id, {
      include: [
        {
          model: RenstraOPD,
          as: "renstra",
          attributes: ["id", "bidang_opd", "sub_bidang_opd"],
        },
        {
          model: Strategi,
          as: "strategi_rpjmd",
          attributes: ["id", "kode_strategi", "deskripsi"],
        },
      ],
    });

    if (!data) return res.status(404).json({ message: "Data not found" });

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const [updated] = await RenstraStrategi.update(req.body, { where: { id } });
    if (!updated) return res.status(404).json({ message: "Data not found" });

    const updatedData = await RenstraStrategi.findByPk(id, {
      include: [
        {
          model: RenstraOPD,
          as: "renstra",
          attributes: ["id", "bidang_opd", "sub_bidang_opd"],
        },
      ],
    });

    res.json(updatedData); // ✅ ini yang perlu ditambahkan
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.delete = async (req, res) => {
  try {
    const id = req.params.id;
    const deleted = await RenstraStrategi.destroy({ where: { id } });
    if (!deleted) return res.status(404).json({ message: "Data not found" });
    res.json({ message: "Deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
