const {
  RenstraSasaran,
  RenstraOPD,
  Sasaran,
  RenstraTujuan,
  RenstraStrategi,
  RenstraKebijakan,
  RenstraProgram,
  RenstraKegiatan,
  RenstraSubkegiatan,
} = require("../models");

exports.create = async (req, res) => {
  try {
    const data = await RenstraSasaran.create(req.body);
    res.status(201).json(data);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.findAll = async (req, res) => {
  try {
    const data = await RenstraSasaran.findAll({
      include: [
        {
          model: RenstraOPD,
          as: "renstra",
          attributes: ["id", "bidang_opd", "sub_bidang_opd"],
        },
        {
          model: Sasaran,
          as: "sasaran_rpjmd",
          attributes: ["id", "isi_sasaran", "nomor"],
        },
        {
          model: RenstraTujuan,
          as: "tujuan",
          attributes: ["id", "isi_tujuan"],
        },
        {
          model: RenstraKebijakan,
          as: "kebijakan",
          attributes: ["id", "deskripsi", "kode_arah", "prioritas"],
        },
        {
          model: RenstraStrategi,
          as: "strategi",
          attributes: ["id", "deskripsi", "kode_strategi"],
        },
        {
          model: RenstraProgram,
          as: "program",
          attributes: [
            "id",
            "nama_program",
            "kode_program",
            "indikator_program",
          ],
        },
        {
          model: RenstraKegiatan,
          as: "kegiatan",
          attributes: ["id", "nama_kegiatan", "kode_kegiatan"],
        },
        {
          model: RenstraSubkegiatan,
          as: "subkegiatan",
          attributes: [
            "id",
            "nama_sub_kegiatan",
            "kode_sub_kegiatan",
            "deskripsi",
          ],
        },
      ],
    });

    res.json(data);
  } catch (err) {
    console.error("ERROR:", err);
    res.status(500).json({ error: err.message });
  }
};

exports.findOne = async (req, res) => {
  try {
    const data = await RenstraSasaran.findByPk(req.params.id, {
      include: [
        {
          model: RenstraOPD,
          as: "renstra",
          attributes: ["id", "bidang_opd", "sub_bidang_opd", "rpjmd_id"],
        },
        {
          model: Sasaran,
          as: "sasaran_rpjmd",
          attributes: ["id", "nomor", "isi_sasaran"],
        },
        {
          model: RenstraTujuan,
          as: "tujuan",
          attributes: ["id", "isi_tujuan"],
        },
        {
          model: RenstraKebijakan,
          as: "kebijakan",
          attributes: ["id", "deskripsi", "kode_arah", "prioritas"],
        },
        {
          model: RenstraStrategi,
          as: "strategi",
          attributes: ["id", "deskripsi", "kode_strategi"],
        },
        {
          model: RenstraProgram,
          as: "program",
          attributes: [
            "id",
            "nama_program",
            "kode_program",
            "indikator_program",
          ],
        },
        {
          model: RenstraKegiatan,
          as: "kegiatan",
          attributes: ["id", "nama_kegiatan", "kode_kegiatan"],
        },
        {
          model: RenstraSubkegiatan,
          as: "subkegiatan",
          attributes: [
            "id",
            "nama_sub_kegiatan",
            "kode_sub_kegiatan",
            "deskripsi",
          ],
        },
      ],
    });

    if (!data) {
      return res.status(404).json({ message: "Data not found" });
    }

    res.json(data);
  } catch (err) {
    console.error("ERROR:", err);
    res.status(500).json({ error: err.message });
  }
};

exports.update = async (req, res) => {
  try {
    const id = req.params.id;
    const [updated] = await RenstraSasaran.update(req.body, { where: { id } });
    if (!updated) return res.status(404).json({ message: "Data not found" });
    const updatedData = await RenstraSasaran.findByPk(id);
    res.json(updatedData);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.delete = async (req, res) => {
  try {
    const id = req.params.id;
    const deleted = await RenstraSasaran.destroy({ where: { id } });
    if (!deleted) return res.status(404).json({ message: "Data not found" });
    res.json({ message: "Deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
