"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraKebijakan extends Model {
    static associate(models) {
      RenstraKebijakan.belongsTo(models.RenstraOPD, {
        foreignKey: "renstra_id",
        targetKey: "id",
        as: "renstra",
      });

      RenstraKebijakan.hasMany(models.RenstraSasaran, {
        foreignKey: "kebijakan_id",
        as: "sasarans",
      });

      RenstraKebijakan.belongsTo(models.ArahKebijakan, {
        foreignKey: "rpjmd_kebijakan_id",
        targetKey: "id",
        as: "arah_kebijakan_rpjmd",
      });
    }
  }

  RenstraKebijakan.init(
    {
      renstra_id: DataTypes.INTEGER,
      rpjmd_kebijakan_id: DataTypes.UUID,
      misi_id: DataTypes.INTEGER,
      no_kebijakan: DataTypes.STRING,
      isi_kebijakan: DataTypes.TEXT,
      no_rpjmd: DataTypes.STRING,
      isi_kebijakan_rpjmd: DataTypes.TEXT,
    },
    {
      sequelize,
      modelName: "RenstraKebijakan",
      tableName: "renstra_kebijakan",
      underscored: true,
      timestamps: false,
    }
  );

  return RenstraKebijakan;
};
