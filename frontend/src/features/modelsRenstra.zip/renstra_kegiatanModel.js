"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraKegiatan extends Model {
    static associate(models) {
      RenstraKegiatan.belongsTo(models.RenstraOPD, {
        foreignKey: "renstra_id",
        targetKey: "id",
        as: "renstra",
      });

      RenstraKegiatan.hasMany(models.RenstraSasaran, {
        foreignKey: "kegiatan_id",
        as: "sasarans",
      });

      RenstraKegiatan.belongsTo(models.Kegiatan, {
        foreignKey: "rpjmd_kegiatan_id",
        targetKey: "id",
        as: "kegiatan_rpjmd",
      });
    }
  }

  RenstraKegiatan.init(
    {
      renstra_id: DataTypes.INTEGER,
      program_id: DataTypes.INTEGER,
      kode_kegiatan: DataTypes.STRING,
      nama_kegiatan: DataTypes.STRING,
      bidang_opd: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "RenstraKegiatan",
      tableName: "renstra_kegiatan",
      underscored: true,
      timestamps: false,
    }
  );

  return RenstraKegiatan;
};
