"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraIndikator extends Model {
    static associate(models) {
      RenstraIndikator.belongsTo(models.RenstraOPD, {
        foreignKey: "renstra_id",
        targetKey: "id",
        as: "renstra",
      });

      RenstraIndikator.belongsTo(models.Indikator, {
        foreignKey: "rpjmd_indikator_id",
        targetKey: "id",
        as: "indikator_rpjmd",
      });
    }
  }

  RenstraIndikator.init(
    {
      renstra_id: DataTypes.INTEGER,
      rpjmd_indikator_id: DataTypes.UUID,
      misi_id: DataTypes.INTEGER,
      no_indikator: DataTypes.STRING,
      isi_indikator: DataTypes.TEXT,
      no_rpjmd: DataTypes.STRING,
      isi_indikator_rpjmd: DataTypes.TEXT,
    },
    {
      sequelize,
      modelName: "RenstraIndikator",
      tableName: "renstra_indikator",
      underscored: true,
      timestamps: false,
    }
  );

  return RenstraIndikator;
};
