"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraSasaran extends Model {
    static associate(models) {
      RenstraSasaran.belongsTo(models.RenstraTujuan, {
        foreignKey: "tujuan_id",
        targetKey: "id",
        as: "tujuan",
      });

      RenstraSasaran.belongsTo(models.RenstraOPD, {
        foreignKey: "renstra_id",
        targetKey: "id",
        as: "renstra",
      });

      RenstraSasaran.belongsTo(models.Sasaran, {
        foreignKey: "rpjmd_sasaran_id",
        targetKey: "id",
        as: "sasaran_rpjmd",
      });

      RenstraSasaran.belongsTo(models.RenstraKebijakan, {
        foreignKey: "kebijakan_id",
        targetKey: "id",
        as: "kebijakan",
      });

      RenstraSasaran.belongsTo(models.RenstraStrategi, {
        foreignKey: "strategi_id",
        targetKey: "id",
        as: "strategi",
      });

      RenstraSasaran.belongsTo(models.RenstraProgram, {
        foreignKey: "program_id",
        targetKey: "id",
        as: "program",
      });

      RenstraSasaran.belongsTo(models.RenstraKegiatan, {
        foreignKey: "kegiatan_id",
        targetKey: "id",
        as: "kegiatan",
      });

      RenstraSasaran.belongsTo(models.RenstraSubkegiatan, {
        foreignKey: "subkegiatan_id",
        targetKey: "id",
        as: "subkegiatan",
      });
    }
  }

  RenstraSasaran.init(
    {
      renstra_id: DataTypes.INTEGER,
      rpjmd_sasaran_id: DataTypes.INTEGER,
      nomor: DataTypes.STRING,
      isi_sasaran: DataTypes.TEXT,
      no_rpjmd: DataTypes.STRING,
      isi_sasaran_rpjmd: DataTypes.TEXT,
      tujuan_id: DataTypes.INTEGER,
      kebijakan_id: DataTypes.INTEGER,
      strategi_id: DataTypes.INTEGER,
      program_id: DataTypes.INTEGER,
      kegiatan_id: DataTypes.INTEGER,
      subkegiatan_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "RenstraSasaran",
      tableName: "renstra_sasaran",
      underscored: true,
      freezeTableName: true,
      timestamps: false,
    }
  );

  return RenstraSasaran;
};
