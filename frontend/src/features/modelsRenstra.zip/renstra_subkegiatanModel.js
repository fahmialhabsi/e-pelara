"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class RenstraSubkegiatan extends Model {
    static associate(models) {
      RenstraSubkegiatan.belongsTo(models.RenstraOPD, {
        foreignKey: "renstra_id",
        targetKey: "id",
        as: "renstra",
      });

      RenstraSubkegiatan.hasMany(models.RenstraSasaran, {
        foreignKey: "subkegiatan_id",
        as: "sasarans",
      });

      RenstraSubkegiatan.belongsTo(models.SubKegiatan, {
        foreignKey: "rpjmd_subkegiatan_id",
        targetKey: "id",
        as: "subkegiatan_rpjmd",
      });
    }
  }

  RenstraSubkegiatan.init(
    {
      renstra_id: DataTypes.INTEGER,
      kegiatan_id: DataTypes.INTEGER,
      kode_sub_kegiatan: DataTypes.STRING,
      nama_sub_kegiatan: DataTypes.STRING,
      deskripsi: DataTypes.TEXT,
    },
    {
      sequelize,
      modelName: "RenstraSubkegiatan",
      tableName: "renstra_subkegiatan",
      underscored: true,
      timestamps: false,
    }
  );

  return RenstraSubkegiatan;
};
